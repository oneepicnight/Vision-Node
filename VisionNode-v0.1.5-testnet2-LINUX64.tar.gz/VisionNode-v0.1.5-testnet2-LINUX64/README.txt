Vision Node v0.1.5 - Linux Testnet Release
============================================

SYSTEM REQUIREMENTS:
- Linux x86_64 (Ubuntu 20.04+ / Debian 11+ / Fedora 35+)
- 4GB RAM minimum
- Rust 1.75+ (for building from source)

QUICK START:

1. Install Rust (if not already installed):
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   source $HOME/.cargo/env

2. Build the node:
   ./build.sh

3. Run the node:
   ./START-VISION-NODE.sh

4. Access the interfaces:
   - Wallet: http://127.0.0.1:7070/app
   - Miner Panel: http://127.0.0.1:7070/panel.html
   - Dashboard: http://127.0.0.1:7070/dashboard.html

FEATURES IN v0.1.5:
- Perfectly centered landing page with 3D Earth globe
- S-tier Vault with glowing effects and health bar
- LAND-based trading pairs (CASH/BTC/BCH/DOGE)
- Working dashboard with recent blocks display
- Rig health monitoring (CPU/Memory usage)
- Integrated wallet and miner control panel

CONFIGURATION:
- Edit .env file to configure node settings
- Default port: 7070
- Data directory: vision_data_7070/

MINING:
- Miner auto-starts with 1 thread by default
- Adjust threads via miner panel or API
- Default rewards go to Treasury wallet

API ENDPOINTS:
- /api/status - Node status
- /api/blocks - Recent blocks
- /api/miner/status - Miner status
- /api/metrics/health - System health

SUPPORT:
- GitHub: https://github.com/oneepicnight/Vision-Node
- Discord: [Your Discord Link]
- Documentation: See docs/ folder

Built with 🦀 Rust | 🔗 Blockchain for Vision World
