//! Active mining module
//!
//! Provides worker thread management and block production for VisionX PoW.

pub mod manager;

pub use manager::ActiveMiner;
