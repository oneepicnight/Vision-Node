use anyhow::Result;
use sled::{Db, Tree};

/// Tree names (adjust if you use different ones)
const TREE_LAND_OWNERS: &str = "land_owners"; // key: parcel_id -> val: owner_addr
const TREE_OWNER_WEIGHTS: &str = "owner_weights"; // key: owner_addr -> val: u128 weight

/// Multiplier for each parcel (env optional). Default = 1.
fn parcel_weight_multiplier() -> u128 {
    std::env::var("VISION_PARCEL_WEIGHT_MULT")
        .ok()
        .and_then(|s| s.parse::<u128>().ok())
        .unwrap_or(1)
}

/// Rebuild owner -> weight map by scanning all parcels.
/// Call this anytime land ownership changes a lot.
pub fn rebuild_owner_weights(db: &Db) -> Result<()> {
    let owners: Tree = db.open_tree(TREE_LAND_OWNERS)?;
    let weights: Tree = db.open_tree(TREE_OWNER_WEIGHTS)?;
    // Clear weights
    weights.clear()?;

    let mult = parcel_weight_multiplier();

    // Count parcels per owner
    for kv in owners.iter() {
        let (_parcel_id, ivec_owner) = kv?;
        let owner = ivec_owner.as_ref(); // raw bytes of address
                                         // Read current
        let cur = read_u128_le(&weights, owner).unwrap_or(0);
        // Add parcel*mult
        let newv = cur.saturating_add(mult);
        write_u128_le(&weights, owner, newv)?;
    }

    Ok(())
}

/// Return the staking weight for a single address.
pub fn stake_weight(db: &Db, addr: &str) -> u128 {
    let weights = db.open_tree(TREE_OWNER_WEIGHTS).ok();
    if let Some(tree) = weights {
        read_u128_le(&tree, addr.as_bytes()).unwrap_or(0)
    } else {
        0
    }
}

/// Sum of all weights (denominator for payouts)
pub fn total_weight(db: &Db) -> u128 {
    let Ok(tree) = db.open_tree(TREE_OWNER_WEIGHTS) else {
        return 0;
    };
    let mut sum: u128 = 0;
    for (_k, v) in tree.iter().flatten() {
        sum = sum.saturating_add(decode_u128_le(v.as_ref()));
    }
    sum
}

// --- sled helpers ---

fn write_u128_le(tree: &Tree, key: &[u8], v: u128) -> anyhow::Result<()> {
    tree.insert(key, v.to_le_bytes().to_vec())?;
    Ok(())
}
fn read_u128_le(tree: &Tree, key: &[u8]) -> anyhow::Result<u128> {
    if let Some(ivec) = tree.get(key)? {
        Ok(decode_u128_le(ivec.as_ref()))
    } else {
        Ok(0)
    }
}
fn decode_u128_le(bytes: &[u8]) -> u128 {
    let mut buf = [0u8; 16];
    let take = bytes.len().min(16);
    buf[..take].copy_from_slice(&bytes[..take]);
    u128::from_le_bytes(buf)
}
