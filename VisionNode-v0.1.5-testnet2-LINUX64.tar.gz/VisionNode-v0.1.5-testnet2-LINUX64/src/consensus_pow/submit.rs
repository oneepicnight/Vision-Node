//! Block submission and validation
//!
//! Handles mined block submission, validation, and broadcasting.

use crate::consensus_pow::block_builder::MineableBlock;
use crate::pow::{U256, visionx};
use std::sync::{Arc, Mutex};
use std::collections::VecDeque;

/// Result of block submission
#[derive(Debug, Clone)]
pub enum SubmitResult {
    Accepted { height: u64, hash: [u8; 32] },
    Rejected { reason: String },
    Duplicate,
}

/// Statistics for mining
#[derive(Debug, Clone, Default)]
pub struct MiningStats {
    pub blocks_found: u64,
    pub blocks_accepted: u64,
    pub blocks_rejected: u64,
    pub last_block_time: Option<u64>,
    pub last_block_height: Option<u64>,
    pub total_rewards: u64,
    pub recent_blocks: VecDeque<BlockInfo>,
}

#[derive(Debug, Clone)]
pub struct BlockInfo {
    pub height: u64,
    pub timestamp: u64,
    pub reward: u64,
    pub hash: [u8; 32],
}

/// Block submission handler
pub struct BlockSubmitter {
    stats: Arc<Mutex<MiningStats>>,
    visionx_params: visionx::VisionXParams,
    found_block_callback: Option<tokio::sync::mpsc::UnboundedSender<MineableBlock>>,
}

impl BlockSubmitter {
    pub fn new(
        visionx_params: visionx::VisionXParams,
        found_block_callback: Option<tokio::sync::mpsc::UnboundedSender<MineableBlock>>,
    ) -> Self {
        Self {
            stats: Arc::new(Mutex::new(MiningStats::default())),
            visionx_params,
            found_block_callback,
        }
    }
    
    /// Submit a mined block for validation and acceptance
    pub fn submit_block(&self, block: MineableBlock, solution_digest: U256, target: U256, epoch_seed: [u8; 32]) -> SubmitResult {
        // Validate the block
        match self.validate_block(&block, &solution_digest, &target, &epoch_seed) {
            Ok(_) => {
                // Calculate block reward (simplified)
                let reward = self.calculate_reward(block.header.height);
                
                // Update statistics
                let mut stats = self.stats.lock().unwrap();
                stats.blocks_found += 1;
                stats.blocks_accepted += 1;
                stats.last_block_time = Some(block.header.timestamp);
                stats.last_block_height = Some(block.header.height);
                stats.total_rewards += reward;
                
                // Record block info
                let block_info = BlockInfo {
                    height: block.header.height,
                    timestamp: block.header.timestamp,
                    reward,
                    hash: block.header.hash(),
                };
                
                stats.recent_blocks.push_back(block_info.clone());
                if stats.recent_blocks.len() > 100 {
                    stats.recent_blocks.pop_front();
                }
                
                drop(stats);
                
                eprintln!(
                    "✅ Block #{} mined! Hash: {:02x}{:02x}..., Reward: {} LAND",
                    block.header.height,
                    block_info.hash[0],
                    block_info.hash[1],
                    reward / 1_000_000 // Convert from micro-LAND to LAND
                );
                
                // Send block to main chain integrator via callback
                if let Some(ref tx) = self.found_block_callback {
                    let _ = tx.send(block.clone());
                }
                
                SubmitResult::Accepted {
                    height: block.header.height,
                    hash: block_info.hash,
                }
            }
            Err(reason) => {
                let mut stats = self.stats.lock().unwrap();
                stats.blocks_found += 1;
                stats.blocks_rejected += 1;
                
                eprintln!("❌ Block rejected: {}", reason);
                
                SubmitResult::Rejected { reason }
            }
        }
    }
    
    /// Validate a mined block
    fn validate_block(&self, block: &MineableBlock, solution_digest: &U256, target: &U256, epoch_seed: &[u8; 32]) -> Result<(), String> {
        // Check if nonce is set
        if block.header.nonce == 0 {
            return Err("Invalid nonce (zero)".to_string());
        }
        
        // Verify solution meets target (use the actual target that was used during mining)
        if !crate::pow::u256_leq(solution_digest, target) {
            return Err(format!(
                "Solution does not meet target difficulty {}",
                block.header.difficulty
            ));
        }
        
        // Verify VisionX PoW (re-hash to ensure correctness)
        let epoch = block.header.height / self.visionx_params.epoch_blocks as u64;
        let header_bytes = block.header.to_bytes();
        let nonce_offset = 4 + 8 + 32 + 8 + 8; // version + height + prev_hash + timestamp + difficulty
        
        eprintln!("🔍 Verifying block #{} with epoch_seed={:02x}{:02x}..., epoch={}", 
            block.header.height, epoch_seed[0], epoch_seed[1], epoch);
        
        // Use the same epoch seed that was used during mining
        let is_valid = visionx::verify(
            &self.visionx_params,
            epoch_seed,
            epoch,
            &header_bytes,
            nonce_offset,
            target,
        );
        
        if !is_valid {
            eprintln!("❌ VisionX verification failed for block #{}: epoch_seed={:02x}{:02x}..., epoch={}", 
                block.header.height, epoch_seed[0], epoch_seed[1], epoch);
            return Err("VisionX PoW verification failed".to_string());
        } else {
            eprintln!("✅ VisionX verification passed for block #{}", block.header.height);
        }
        
        // Additional validations
        if block.header.version != 1 {
            return Err(format!("Unsupported block version: {}", block.header.version));
        }
        
        if block.header.timestamp == 0 {
            return Err("Invalid timestamp (zero)".to_string());
        }
        
        // TODO: Validate transactions
        // TODO: Check prev_hash matches chain tip
        // TODO: Check height is next in sequence
        
        Ok(())
    }
    
    /// Calculate block reward based on height
    fn calculate_reward(&self, height: u64) -> u64 {
        // 5-year mining schedule with yearly halvings to reach 1 billion LAND total
        // Block time: 2 seconds (30 blocks/min, 1800 blocks/hour)
        // Blocks per year: 15,768,000 (30 * 60 * 24 * 365)
        // Total blocks in 5 years: 78,840,000
        //
        // Halving schedule (yearly):
        // Year 1 (0-15,767,999):       32.73 LAND = ~516M LAND
        // Year 2 (15,768,000-31,535,999): 16.365 LAND = ~258M LAND
        // Year 3 (31,536,000-47,303,999): 8.1825 LAND = ~129M LAND
        // Year 4 (47,304,000-63,071,999): 4.09125 LAND = ~64.5M LAND
        // Year 5 (63,072,000-78,839,999): 2.045625 LAND = ~32.25M LAND
        // After block 78,840,000: 0 LAND (mining ends, vault takes over)
        //
        // Total distributed: ~1 billion LAND
        
        const BLOCKS_PER_YEAR: u64 = 15_768_000; // 2-second blocks
        const INITIAL_REWARD: u64 = 32_730_000; // 32.73 LAND (6 decimals)
        const MAX_YEARS: u64 = 5;
        
        let year = height / BLOCKS_PER_YEAR;
        
        if year >= MAX_YEARS {
            return 0; // Mining ends after 5 years, vault rewards begin
        }
        
        INITIAL_REWARD >> year // Divide by 2^year (halve each year)
    }
    
    /// Get current mining statistics
    pub fn stats(&self) -> MiningStats {
        self.stats.lock().unwrap().clone()
    }
    
    /// Get stats handle for sharing
    pub fn stats_handle(&self) -> Arc<Mutex<MiningStats>> {
        self.stats.clone()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::consensus_pow::block_builder::{BlockBuilder, Transaction};
    
    #[test]
    fn test_calculate_reward() {
        let params = visionx::VisionXParams::default();
        let submitter = BlockSubmitter::new(params, None);
        
        // 5-year yearly halving schedule with 2-second blocks (15,768,000 blocks/year)
        
        // Year 1 (0-15,767,999): 32.73 LAND
        assert_eq!(submitter.calculate_reward(0), 32_730_000);
        assert_eq!(submitter.calculate_reward(1_000_000), 32_730_000);
        assert_eq!(submitter.calculate_reward(15_767_999), 32_730_000);
        
        // Year 2 (15,768,000-31,535,999): 16.365 LAND
        assert_eq!(submitter.calculate_reward(15_768_000), 16_365_000);
        assert_eq!(submitter.calculate_reward(20_000_000), 16_365_000);
        
        // Year 3 (31,536,000-47,303,999): 8.1825 LAND
        assert_eq!(submitter.calculate_reward(31_536_000), 8_182_500);
        
        // Year 4 (47,304,000-63,071,999): 4.09125 LAND
        assert_eq!(submitter.calculate_reward(47_304_000), 4_091_250);
        
        // Year 5 (63,072,000-78,839,999): 2.045625 LAND
        assert_eq!(submitter.calculate_reward(63_072_000), 2_045_625);
        assert_eq!(submitter.calculate_reward(78_839_999), 2_045_625);
        
        // After 5 years (78,840,000+): Mining ends, vault takes over
        assert_eq!(submitter.calculate_reward(78_840_000), 0);
        assert_eq!(submitter.calculate_reward(100_000_000), 0);
    }
    
    #[test]
    fn test_total_supply_approximation() {
        let params = visionx::VisionXParams::default();
        let submitter = BlockSubmitter::new(params, None);
        
        const BLOCKS_PER_YEAR: u64 = 15_768_000;
        let mut total: u128 = 0;
        
        // Calculate total supply distributed over 5 years (yearly halvings)
        for year in 0..5 {
            let height = year * BLOCKS_PER_YEAR;
            let reward = submitter.calculate_reward(height);
            let blocks_in_year = BLOCKS_PER_YEAR;
            total += reward as u128 * blocks_in_year as u128;
        }
        
        // Should be approximately 1 billion LAND (1,000,000,000,000,000 micro-LAND)
        let one_billion = 1_000_000_000_000_000u128;
        let tolerance = one_billion / 20; // Allow 5% tolerance
        
        assert!(total >= one_billion - tolerance, "Total supply too low: {}", total);
        assert!(total <= one_billion + tolerance, "Total supply too high: {}", total);
    }
    
    #[test]
    fn test_stats_tracking() {
        let params = visionx::VisionXParams::default();
        let submitter = BlockSubmitter::new(params, None);
        
        let stats = submitter.stats();
        assert_eq!(stats.blocks_found, 0);
        assert_eq!(stats.blocks_accepted, 0);
        assert_eq!(stats.total_rewards, 0);
    }
    
    #[test]
    fn test_validation_checks_nonce() {
        let params = visionx::VisionXParams::default();
        let submitter = BlockSubmitter::new(params, None);
        
        let builder = BlockBuilder::new();
        let block = builder.build_block(1, [0u8; 32], 1000, vec![]);
        
        // Block with nonce=0 should fail
        let epoch_seed = [0u8; 32];
        let result = submitter.validate_block(&block, &[0u8; 32], &epoch_seed);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("nonce"));
    }
}
