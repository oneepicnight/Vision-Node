use std::sync::Arc;

use axum::http::{HeaderValue, StatusCode};
use axum::response::IntoResponse;
use prometheus::{opts, Encoder, IntCounter, IntGauge, Registry, TextEncoder};

/// Wrapper around the sled database for shared access
#[derive(Clone)]
pub struct DbCtx {
    pub db: sled::Db,
}

/// Public handle you'll keep in AppState
#[derive(Clone)]
pub struct Metrics {
    pub registry: Registry,

    // Tokenomics
    pub tok_supply: IntGauge,
    pub tok_burned: IntGauge,
    pub tok_vault: IntGauge,
    pub tok_fund: IntGauge,
    pub tok_treasury: IntGauge,

    // Ops/health
    pub blocks_height: IntGauge,
    pub mempool_len: IntGauge,
    pub peers_connected: IntGauge,
    
    // Difficulty/Mining metrics
    pub diff_current: IntGauge,
    pub diff_block_time_ms: IntGauge,
    pub diff_avg_block_time_ms: IntGauge,
    pub diff_window_size: IntGauge,

    // Wallet operations
    pub wallet_transfers_total: IntCounter,
    pub wallet_transfer_volume: IntCounter,
    pub wallet_fees_collected: IntCounter,
    pub wallet_receipts_written: IntCounter,
}

impl Metrics {
    pub fn new() -> Self {
        let registry =
            Registry::new_custom(Some("vision".to_string()), None).expect("metrics registry");

        // --- Tokenomics gauges ---
        let tok_supply =
            IntGauge::with_opts(opts!("tok_supply", "Current total token supply")).unwrap();
        let tok_burned =
            IntGauge::with_opts(opts!("tok_burned_total", "Cumulative burned tokens")).unwrap();
        let tok_vault =
            IntGauge::with_opts(opts!("tok_vault_total", "Vault (staking) balance")).unwrap();
        let tok_fund =
            IntGauge::with_opts(opts!("tok_fund_total", "Ecosystem/Fund balance")).unwrap();
        let tok_treasury =
            IntGauge::with_opts(opts!("tok_treasury_total", "Treasury (founders) balance"))
                .unwrap();

        // --- Ops gauges ---
        let blocks_height =
            IntGauge::with_opts(opts!("blocks_height", "Best chain height")).unwrap();
        let mempool_len =
            IntGauge::with_opts(opts!("mempool_len", "Current mempool length")).unwrap();
        let peers_connected =
            IntGauge::with_opts(opts!("peers_connected", "Connected peers")).unwrap();
        
        // --- Difficulty/Mining gauges ---
        let diff_current =
            IntGauge::with_opts(opts!("diff_current", "Current mining difficulty")).unwrap();
        let diff_block_time_ms =
            IntGauge::with_opts(opts!("diff_block_time_ms", "Last block time in milliseconds")).unwrap();
        let diff_avg_block_time_ms =
            IntGauge::with_opts(opts!("diff_avg_block_time_ms", "Average block time over window (ms)")).unwrap();
        let diff_window_size =
            IntGauge::with_opts(opts!("diff_window_size", "LWMA window size in blocks")).unwrap();

        // --- Wallet counters ---
        let wallet_transfers_total = IntCounter::with_opts(opts!(
            "wallet_transfers_total",
            "Total number of wallet transfers"
        ))
        .unwrap();
        let wallet_transfer_volume = IntCounter::with_opts(opts!(
            "wallet_transfer_volume",
            "Total volume of tokens transferred"
        ))
        .unwrap();
        let wallet_fees_collected = IntCounter::with_opts(opts!(
            "wallet_fees_collected",
            "Total fees collected from transfers"
        ))
        .unwrap();
        let wallet_receipts_written =
            IntCounter::with_opts(opts!("wallet_receipts_written", "Total receipts written"))
                .unwrap();

        for m in [
            &tok_supply,
            &tok_burned,
            &tok_vault,
            &tok_fund,
            &tok_treasury,
            &blocks_height,
            &mempool_len,
            &peers_connected,
            &diff_current,
            &diff_block_time_ms,
            &diff_avg_block_time_ms,
            &diff_window_size,
        ] {
            registry.register(Box::new(m.clone())).unwrap();
        }

        // Register wallet counters
        registry
            .register(Box::new(wallet_transfers_total.clone()))
            .unwrap();
        registry
            .register(Box::new(wallet_transfer_volume.clone()))
            .unwrap();
        registry
            .register(Box::new(wallet_fees_collected.clone()))
            .unwrap();
        registry
            .register(Box::new(wallet_receipts_written.clone()))
            .unwrap();

        Self {
            registry,
            tok_supply,
            tok_burned,
            tok_vault,
            tok_fund,
            tok_treasury,
            blocks_height,
            mempool_len,
            peers_connected,
            diff_current,
            diff_block_time_ms,
            diff_avg_block_time_ms,
            diff_window_size,
            wallet_transfers_total,
            wallet_transfer_volume,
            wallet_fees_collected,
            wallet_receipts_written,
        }
    }

    // Lightweight setters you can call from engine/mempool/peer code
    pub fn set_height(&self, h: u64) {
        self.blocks_height.set(h as i64);
    }
    pub fn set_mempool_len(&self, n: usize) {
        self.mempool_len.set(n as i64);
    }
    pub fn set_peers(&self, n: usize) {
        self.peers_connected.set(n as i64);
    }
}

/// GET /metrics — Prometheus text exposition
pub async fn metrics_handler(db: sled::Db, metrics: Arc<Metrics>) -> impl IntoResponse {
    // Try to refresh gauges from DB before encoding.
    // If anything fails, we still render existing values.
    if let Err(e) = refresh_tokenomics_from_db(&db, &metrics) {
        // We DO NOT JSON-error here (Prometheus expects text/plain).
        // If you want to log:
        eprintln!("[metrics] refresh_tokenomics_from_db error: {e}");
    }

    let metric_families = metrics.registry.gather();
    let mut buf = Vec::with_capacity(8 * 1024);
    let encoder = TextEncoder::new();
    if let Err(e) = encoder.encode(&metric_families, &mut buf) {
        // On encoder failure, return 500 with a tiny text body (still text/plain)
        let mut resp = (StatusCode::INTERNAL_SERVER_ERROR, "metrics encode error").into_response();
        resp.headers_mut().insert(
            axum::http::header::CONTENT_TYPE,
            HeaderValue::from_static("text/plain; charset=utf-8"),
        );
        return resp;
    }

    let body = match String::from_utf8(buf) {
        Ok(s) => s,
        Err(_) => String::from("# encoding error\n"),
    };

    let mut resp = (StatusCode::OK, body).into_response();
    resp.headers_mut().insert(
        axum::http::header::CONTENT_TYPE,
        HeaderValue::from_static("text/plain; version=0.0.4; charset=utf-8"),
    );
    resp
}

/// Pull current balances/supply from sled and set gauges.
/// This function is intentionally forgiving: missing keys default to 0.
fn refresh_tokenomics_from_db(db: &sled::Db, metrics: &Metrics) -> anyhow::Result<()> {
    // Preferred tree/key layout (adjust to your actual schema):
    //   Tree "tokenomics":
    //     "supply"           -> u128 LE
    //     "burned_total"     -> u128 LE
    //     "vault_total"      -> u128 LE
    //     "fund_total"       -> u128 LE
    //     "treasury_total"   -> u128 LE
    //
    // If you have per-account trees, you can sum them here instead.
    let t = db.open_tree("tokenomics")?;

    let supply = read_u128_le(&t, b"supply").unwrap_or(0);
    let burned = read_u128_le(&t, b"burned_total").unwrap_or(0);
    let vault = read_u128_le(&t, b"vault_total").unwrap_or(0);
    let fund = read_u128_le(&t, b"fund_total").unwrap_or(0);
    let treasury = read_u128_le(&t, b"treasury_total").unwrap_or(0);

    // Convert to i64 safely (cap if you exceed i64::MAX)
    metrics.tok_supply.set(int_cap_i64(supply));
    metrics.tok_burned.set(int_cap_i64(burned));
    metrics.tok_vault.set(int_cap_i64(vault));
    metrics.tok_fund.set(int_cap_i64(fund));
    metrics.tok_treasury.set(int_cap_i64(treasury));

    Ok(())
}

fn int_cap_i64(v: u128) -> i64 {
    if v > i64::MAX as u128 {
        i64::MAX
    } else {
        v as i64
    }
}

fn read_u128_le(tree: &sled::Tree, key: &[u8]) -> anyhow::Result<u128> {
    if let Some(ivec) = tree.get(key)? {
        let bytes = ivec.as_ref();
        // Accept 16-byte LE; accept shorter lengths as little-endian padded
        let mut buf = [0u8; 16];
        let take = bytes.len().min(16);
        buf[..take].copy_from_slice(&bytes[..take]);
        Ok(u128::from_le_bytes(buf))
    } else {
        Ok(0)
    }
}
