//! P2P HTTP Routes for Headers-First Sync

use axum::{
    extract::Json,
    http::StatusCode,
    routing::{get, post},
    Router,
};
use once_cell::sync::Lazy;
use parking_lot::Mutex;
use std::sync::Arc;

use super::protocol::*;
use super::orphans::{OrphanPool, SeenFilters};
use super::sync::build_block_locator;

/// Global orphan pool
static ORPHAN_POOL: Lazy<Arc<Mutex<OrphanPool>>> = Lazy::new(|| {
    Arc::new(Mutex::new(OrphanPool::new(512)))
});

/// Global seen filters
static SEEN_FILTERS: Lazy<Arc<Mutex<SeenFilters>>> = Lazy::new(|| {
    Arc::new(Mutex::new(SeenFilters::new(8192)))
});

/// Create P2P router
pub fn p2p_router() -> Router {
    Router::new()
        // Headers-first sync (Phase 1)
        .route("/p2p/announce", post(handle_announce))
        .route("/p2p/get_headers", post(handle_get_headers))
        .route("/p2p/headers", get(handle_headers_endpoint))
        .route("/p2p/get_blocks", post(handle_get_blocks))
        .route("/p2p/blocks", get(handle_blocks_endpoint))
        // INV/GETDATA protocol (Phase 2)
        .route("/p2p/inv", post(handle_inv))
        .route("/p2p/getdata", post(handle_getdata))
        // Compact blocks (Phase 2)
        .route("/p2p/compact_block", post(handle_compact_block))
        .route("/p2p/get_block_txs", post(handle_get_block_txs))
        // Direct tx/block send
        .route("/p2p/tx", post(handle_tx))
        .route("/p2p/block", post(handle_block))
}

/// Handle block announcement (lightweight tip notification)
async fn handle_announce(
    Json(announce): Json<AnnounceBlock>,
) -> (StatusCode, Json<serde_json::Value>) {
    // Check if already seen
    let mut filters = SEEN_FILTERS.lock();
    if filters.mark_header_seen(&announce.hash) {
        // Already seen, drop silently and increment dupe counter
        crate::PROM_P2P_DUPES_DROPPED.inc();
        return (StatusCode::OK, Json(serde_json::json!({ "status": "duplicate" })));
    }
    drop(filters);
    
    // Update P2P metrics
    crate::PROM_P2P_ANNOUNCES_RECEIVED.inc();
    
    // Enqueue for header/block sync (don't pull full block yet)
    // This is handled by the sync task
    eprintln!("📡 Received block announcement: height={}, hash={}", 
              announce.height, &announce.hash[..8]);
    
    (StatusCode::OK, Json(serde_json::json!({ "status": "queued" })))
}

/// Handle headers request
async fn handle_get_headers(
    Json(req): Json<GetHeaders>,
) -> (StatusCode, Json<Headers>) {
    let g = crate::CHAIN.lock();
    
    // Find first common block from locator
    let mut start_height = 0;
    for locator_hash in &req.locator {
        // Find this hash in our chain
        if let Some(pos) = g.blocks.iter().position(|b| &b.header.pow_hash == locator_hash) {
            start_height = pos + 1; // Start from next block
            break;
        }
    }
    
    // Collect headers starting from start_height
    let mut headers = Vec::new();
    let max_headers = req.max.min(2000);
    
    for i in start_height..g.blocks.len() {
        if headers.len() >= max_headers {
            break;
        }
        
        let block = &g.blocks[i];
        
        // Validate header before sending
        if let Err(e) = validate_header_for_send(block, i, &g) {
            eprintln!("⚠️ Skipping invalid header at height {}: {}", i, e);
            continue;
        }
        
        headers.push(LiteHeader::from_block(block));
        
        // Stop at requested hash
        if let Some(stop_hash) = &req.stop {
            if &block.header.pow_hash == stop_hash {
                break;
            }
        }
    }
    
    drop(g);
    
    eprintln!("📤 Sending {} headers starting from height {}", headers.len(), start_height);
    
    // Update metrics
    crate::PROM_P2P_HEADERS_SENT.inc_by(headers.len() as u64);
    
    (StatusCode::OK, Json(Headers { headers }))
}

/// Validate header integrity for P2P transmission
fn validate_header_for_send(block: &crate::Block, height: usize, chain: &crate::Chain) -> Result<(), String> {
    // Check height monotonicity
    if block.header.number != height as u64 {
        return Err(format!("Height mismatch: block says {}, position is {}", block.header.number, height));
    }
    
    // Check parent linkage (except genesis)
    if height > 0 {
        if let Some(parent) = chain.blocks.get(height - 1) {
            if block.header.parent_hash != parent.header.pow_hash {
                return Err("Parent hash mismatch".to_string());
            }
        }
    }
    
    // Check timestamp sanity
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_secs();
    
    // Not too far in future (allow 10s clock drift)
    if block.header.timestamp > now + 10 {
        return Err(format!("Timestamp too far in future: {} vs now {}", block.header.timestamp, now));
    }
    
    // Check against median of last 11 blocks
    if height >= 11 {
        let mut recent_times: Vec<u64> = chain.blocks[height.saturating_sub(11)..height]
            .iter()
            .map(|b| b.header.timestamp)
            .collect();
        recent_times.sort_unstable();
        let median = recent_times[recent_times.len() / 2];
        
        if block.header.timestamp < median {
            return Err(format!("Timestamp below median: {} < {}", block.header.timestamp, median));
        }
    }
    
    // Target bounds check (ensure difficulty is reasonable)
    if block.header.difficulty == 0 {
        return Err("Zero difficulty".to_string());
    }
    
    Ok(())
}

/// Placeholder endpoint (actual responses via POST /p2p/get_headers)
async fn handle_headers_endpoint() -> (StatusCode, Json<serde_json::Value>) {
    (StatusCode::OK, Json(serde_json::json!({
        "info": "Use POST /p2p/get_headers to request headers"
    })))
}

/// Handle block batch request
async fn handle_get_blocks(
    Json(req): Json<GetBlocks>,
) -> (StatusCode, Json<Blocks>) {
    let g = crate::CHAIN.lock();
    let mut blocks = Vec::new();
    
    for hash in &req.hashes {
        // Find block by hash
        if let Some(block) = g.blocks.iter().find(|b| &b.header.pow_hash == hash) {
            // Serialize block to JSON then base64
            if let Ok(json) = serde_json::to_string(block) {
                use base64::{Engine as _, engine::general_purpose};
                let raw = general_purpose::STANDARD.encode(json.as_bytes());
                blocks.push(BlockEnvelope {
                    hash: hash.clone(),
                    raw,
                });
            }
        }
    }
    
    drop(g);
    
    eprintln!("📤 Sending {} blocks", blocks.len());
    
    // Update metrics
    crate::PROM_P2P_BLOCKS_SENT.inc_by(blocks.len() as u64);
    
    (StatusCode::OK, Json(Blocks { blocks }))
}

/// Placeholder endpoint
async fn handle_blocks_endpoint() -> (StatusCode, Json<serde_json::Value>) {
    (StatusCode::OK, Json(serde_json::json!({
        "info": "Use POST /p2p/get_blocks to request blocks"
    })))
}

/// Helper: Build and send block announcement to peers
pub async fn announce_block_to_peers(block: &crate::Block) {
    let announce = AnnounceBlock {
        height: block.header.number,
        hash: block.header.pow_hash.clone(),
        prev: block.header.parent_hash.clone(),
    };
    
    let peers: Vec<String> = {
        let g = crate::CHAIN.lock();
        g.peers.iter().cloned().collect()
    };
    
    for peer in peers {
        let url = format!("{}/p2p/announce", peer.trim_end_matches('/'));
        let announce_clone = announce.clone();
        
        tokio::spawn(async move {
            let _ = crate::HTTP
                .post(&url)
                .json(&announce_clone)
                .timeout(std::time::Duration::from_secs(3))
                .send()
                .await;
        });
    }
    
    crate::PROM_P2P_ANNOUNCES_SENT.inc();
}

/// Helper: Fetch headers from peer
pub async fn fetch_headers_from_peer(
    peer_url: &str,
    locator: Vec<String>,
) -> Result<Vec<LiteHeader>, String> {
    let req = GetHeaders::new(locator);
    let url = format!("{}/p2p/get_headers", peer_url.trim_end_matches('/'));
    
    let start = std::time::Instant::now();
    let response = crate::HTTP
        .post(&url)
        .json(&req)
        .timeout(std::time::Duration::from_secs(3))
        .send()
        .await
        .map_err(|e| format!("Request failed: {}", e))?;
    
    let rtt_ms = start.elapsed().as_millis() as f64;
    
    if !response.status().is_success() {
        return Err(format!("HTTP {}", response.status()));
    }
    
    let headers_resp: Headers = response
        .json()
        .await
        .map_err(|e| format!("Parse failed: {}", e))?;
    
    eprintln!("📥 Received {} headers from {} (RTT: {:.0}ms)", 
              headers_resp.headers.len(), peer_url, rtt_ms);
    
    crate::PROM_P2P_HEADERS_RECEIVED.inc_by(headers_resp.headers.len() as u64);
    
    Ok(headers_resp.headers)
}

/// Helper: Fetch blocks from peer (windowed)
pub async fn fetch_blocks_from_peer(
    peer_url: &str,
    hashes: Vec<String>,
) -> Result<Vec<BlockEnvelope>, String> {
    let req = GetBlocks { hashes: hashes.clone() };
    let url = format!("{}/p2p/get_blocks", peer_url.trim_end_matches('/'));
    
    let start = std::time::Instant::now();
    let response = crate::HTTP
        .post(&url)
        .json(&req)
        .timeout(std::time::Duration::from_secs(5))
        .send()
        .await
        .map_err(|e| format!("Request failed: {}", e))?;
    
    let rtt_ms = start.elapsed().as_millis() as f64;
    
    if !response.status().is_success() {
        return Err(format!("HTTP {}", response.status()));
    }
    
    let blocks_resp: Blocks = response
        .json()
        .await
        .map_err(|e| format!("Parse failed: {}", e))?;
    
    eprintln!("📥 Received {} blocks from {} (RTT: {:.0}ms)", 
              blocks_resp.blocks.len(), peer_url, rtt_ms);
    
    crate::PROM_P2P_BLOCKS_RECEIVED.inc_by(blocks_resp.blocks.len() as u64);
    
    Ok(blocks_resp.blocks)
}

// ============================================================================
// Phase 2: INV/GETDATA Protocol + Compact Blocks
// ============================================================================

/// Handle INV message (inventory announcement)
async fn handle_inv(
    Json(inv): Json<super::tx_relay::Inv>,
) -> (StatusCode, Json<serde_json::Value>) {
    use crate::{PROM_TX_INV_RECEIVED};
    
    tracing::debug!(
        target: "p2p::inv",
        count = inv.objects.len(),
        "Received INV message"
    );
    
    // Track metrics for tx INV messages
    if inv.objects.iter().any(|item| matches!(item.inv_type, super::tx_relay::InvType::Tx)) {
        PROM_TX_INV_RECEIVED.inc();
    }
    
    // Get peer from request (in real implementation, extract from headers)
    let peer = "http://localhost:7000".to_string();
    
    // Process INV in background
    tokio::spawn(async move {
        super::tx_relay::handle_inv(peer, inv).await;
    });
    
    (StatusCode::OK, Json(serde_json::json!({ "status": "processing" })))
}

/// Handle GETDATA request (request for specific inventory items)
async fn handle_getdata(
    Json(getdata): Json<super::tx_relay::GetData>,
) -> (StatusCode, Json<serde_json::Value>) {
    tracing::debug!(
        target: "p2p::getdata",
        count = getdata.objects.len(),
        "Received GETDATA request"
    );
    
    let peer = "http://localhost:7000".to_string();
    
    // Process GETDATA in background
    tokio::spawn(async move {
        super::tx_relay::handle_getdata(peer, getdata).await;
    });
    
    (StatusCode::OK, Json(serde_json::json!({ "status": "processing" })))
}

/// Handle compact block reception
async fn handle_compact_block(
    Json(compact): Json<super::compact::CompactBlock>,
) -> (StatusCode, Json<serde_json::Value>) {
    tracing::info!(
        target: "p2p::compact",
        hash = %compact.header.hash,
        height = compact.header.height,
        tx_count = compact.short_tx_ids.len(),
        prefilled = compact.prefilled_txs.len(),
        "Received compact block"
    );
    
    // Update metrics
    crate::PROM_COMPACT_BLOCKS_RECEIVED.inc();
    
    // Try to reconstruct the block from mempool
    match super::mempool_sync::reconstruct_block(&compact) {
        super::mempool_sync::ReconstructResult::Complete(block) => {
            use super::reorg::{handle_reorg, ReorgResult};
            
            tracing::info!(
                target: "p2p::compact",
                hash = %block.header.pow_hash,
                "Successfully reconstructed block from compact representation"
            );
            
            crate::PROM_COMPACT_BLOCK_RECONSTRUCTIONS.inc();
            
            // Check if block extends current tip or requires reorg
            let current_tip = {
                let g = crate::CHAIN.lock();
                g.blocks.last().map(|b| b.header.pow_hash.clone())
            };
            
            match current_tip {
                Some(tip_hash) if block.header.parent_hash == tip_hash => {
                    // Block extends current tip
                    let mut g = crate::CHAIN.lock();
                    g.blocks.push(block.clone());
                    drop(g);
                    
                    (StatusCode::OK, Json(serde_json::json!({ 
                        "status": "accepted",
                        "hash": block.header.pow_hash,
                        "extended_tip": true
                    })))
                }
                Some(_) => {
                    // Check for reorg
                    match handle_reorg(&block) {
                        ReorgResult::Success { old_tip, new_tip, blocks_rolled_back, blocks_applied } => {
                            tracing::warn!(
                                target: "p2p::reorg",
                                old_tip = %old_tip,
                                new_tip = %new_tip,
                                "Reorg triggered by compact block"
                            );
                            
                            (StatusCode::OK, Json(serde_json::json!({ 
                                "status": "reorg",
                                "hash": new_tip
                            })))
                        }
                        ReorgResult::NotNeeded => {
                            // Add to orphan pool
                            let orphan_pool_arc = orphan_pool();
                            let mut pool = orphan_pool_arc.lock();
                            pool.add_orphan(block.clone());
                            
                            (StatusCode::OK, Json(serde_json::json!({ 
                                "status": "orphaned",
                                "hash": block.header.pow_hash
                            })))
                        }
                        ReorgResult::Failed(reason) => {
                            (StatusCode::BAD_REQUEST, Json(serde_json::json!({ 
                                "error": "reorg_failed",
                                "reason": reason
                            })))
                        }
                    }
                }
                None => {
                    // Empty chain
                    let mut g = crate::CHAIN.lock();
                    g.blocks.push(block.clone());
                    drop(g);
                    
                    (StatusCode::OK, Json(serde_json::json!({ 
                        "status": "accepted",
                        "hash": block.header.pow_hash
                    })))
                }
            }
        }
        super::mempool_sync::ReconstructResult::NeedTxs(indices) => {
            tracing::debug!(
                target: "p2p::compact",
                missing_count = indices.len(),
                "Need to fetch missing transactions"
            );
            
            // TODO: Fetch missing txs from peer
            (StatusCode::ACCEPTED, Json(serde_json::json!({ 
                "status": "need_txs",
                "missing_indices": indices 
            })))
        }
        super::mempool_sync::ReconstructResult::Failed(err) => {
            tracing::warn!(
                target: "p2p::compact",
                error = %err,
                "Failed to reconstruct block"
            );
            
            crate::PROM_COMPACT_BLOCK_RECONSTRUCTION_FAILURES.inc();
            
            (StatusCode::BAD_REQUEST, Json(serde_json::json!({ 
                "status": "failed",
                "error": err 
            })))
        }
    }
}

/// Handle request for missing block transactions
async fn handle_get_block_txs(
    Json(req): Json<super::compact::GetBlockTxns>,
) -> (StatusCode, Json<super::compact::BlockTxns>) {
    tracing::debug!(
        target: "p2p::compact",
        block = %req.block_hash,
        count = req.tx_indices.len(),
        "Received GetBlockTxns request"
    );
    
    // Find the block
    let g = crate::CHAIN.lock();
    let block = g.blocks.iter()
        .find(|b| b.header.pow_hash == req.block_hash);
    
    if let Some(block) = block {
        // Extract requested transactions
        let mut txs = Vec::new();
        for &idx in &req.tx_indices {
            if idx < block.txs.len() {
                txs.push(block.txs[idx].clone());
            }
        }
        
        drop(g);
        
        tracing::debug!(
            target: "p2p::compact",
            found = txs.len(),
            "Sending missing transactions"
        );
        
        (StatusCode::OK, Json(super::compact::BlockTxns {
            block_hash: req.block_hash,
            txs,
        }))
    } else {
        drop(g);
        
        tracing::warn!(
            target: "p2p::compact",
            block = %req.block_hash,
            "Block not found for GetBlockTxns"
        );
        
        (StatusCode::NOT_FOUND, Json(super::compact::BlockTxns {
            block_hash: req.block_hash,
            txs: vec![],
        }))
    }
}

/// Handle direct transaction send
async fn handle_tx(
    Json(tx): Json<crate::Tx>,
) -> (StatusCode, Json<serde_json::Value>) {
    use crate::{tx_hash, verify_tx, PROM_TX_GOSSIP_RECEIVED, PROM_TX_GOSSIP_DUPLICATES, CHAIN};
    
    let tx_hash = hex::encode(tx_hash(&tx));
    
    tracing::debug!(
        target: "p2p::tx",
        tx_hash = %tx_hash,
        from = %tx.sender_pubkey,
        "Received transaction via gossip"
    );
    
    // Update metrics
    PROM_TX_GOSSIP_RECEIVED.inc();
    
    // Check if we already have this transaction
    let already_have = {
        let g = CHAIN.lock();
        g.seen_txs.contains(&tx_hash)
    };
    
    if already_have {
        tracing::debug!(
            target: "p2p::tx",
            tx_hash = %tx_hash,
            "Already have transaction, skipping"
        );
        PROM_TX_GOSSIP_DUPLICATES.inc();
        return (StatusCode::OK, Json(serde_json::json!({ 
            "status": "duplicate",
            "tx_hash": tx_hash 
        })));
    }
    
    // Verify transaction signature
    if let Err(e) = verify_tx(&tx) {
        tracing::warn!(
            target: "p2p::tx",
            tx_hash = %tx_hash,
            error = ?e,
            "Invalid transaction signature"
        );
        return (StatusCode::BAD_REQUEST, Json(serde_json::json!({ 
            "error": "invalid_signature" 
        })));
    }
    
    // Add to mempool
    let mut g = CHAIN.lock();
    
    // Mark as seen
    g.seen_txs.insert(tx_hash.clone());
    
    // Determine lane based on tip
    let critical_threshold = 1000;
    if tx.tip >= critical_threshold {
        g.mempool_critical.push_back(tx.clone());
        tracing::debug!(
            target: "p2p::tx",
            tx_hash = %tx_hash,
            tip = tx.tip,
            "Added to critical mempool lane"
        );
    } else {
        g.mempool_bulk.push_back(tx.clone());
        tracing::debug!(
            target: "p2p::tx",
            tx_hash = %tx_hash,
            tip = tx.tip,
            "Added to bulk mempool lane"
        );
    }
    
    // Track timestamps
    g.mempool_ts.insert(tx_hash.clone(), crate::now_ts());
    
    // Track block height when transaction enters mempool
    let current_height = g.blocks.last().map(|b| b.header.number);
    if let Some(height) = current_height {
        g.mempool_height.insert(tx_hash.clone(), height);
    }
    
    drop(g);
    
    // Propagate to other peers (avoid re-announcing to sender)
    let tx_hash_for_propagation = tx_hash.clone();
    tokio::spawn(async move {
        announce_tx_to_peers(tx_hash_for_propagation).await;
    });
    
    tracing::info!(
        target: "p2p::tx",
        tx_hash = %tx_hash,
        "Transaction accepted and propagated"
    );
    
    (StatusCode::OK, Json(serde_json::json!({ 
        "status": "accepted",
        "tx_hash": tx_hash 
    })))
}

/// Handle direct block send
async fn handle_block(
    Json(block): Json<crate::Block>,
) -> (StatusCode, Json<serde_json::Value>) {
    use super::reorg::{handle_reorg, ReorgResult};
    
    tracing::info!(
        target: "p2p::block",
        hash = %block.header.pow_hash,
        height = block.header.number,
        txs = block.txs.len(),
        "Received full block via P2P"
    );
    
    // Update metrics
    crate::PROM_P2P_BLOCKS_RECEIVED.inc();
    
    // Check if block extends current tip or requires reorg
    let current_tip = {
        let g = crate::CHAIN.lock();
        g.blocks.last().map(|b| b.header.pow_hash.clone())
    };
    
    match current_tip {
        Some(tip_hash) if block.header.parent_hash == tip_hash => {
            // Block extends current tip - normal case
            tracing::debug!(
                target: "p2p::block",
                hash = %block.header.pow_hash,
                "Block extends current tip"
            );
            
            // TODO: Validate block before adding
            let mut g = crate::CHAIN.lock();
            g.blocks.push(block.clone());
            drop(g);
            
            (StatusCode::OK, Json(serde_json::json!({ 
                "status": "accepted",
                "hash": block.header.pow_hash,
                "extended_tip": true
            })))
        }
        Some(_) => {
            // Block doesn't extend tip - check for reorg
            tracing::debug!(
                target: "p2p::block",
                hash = %block.header.pow_hash,
                parent = %block.header.parent_hash,
                "Block does not extend tip, checking for reorg"
            );
            
            match handle_reorg(&block) {
                ReorgResult::Success { old_tip, new_tip, blocks_rolled_back, blocks_applied } => {
                    tracing::warn!(
                        target: "p2p::reorg",
                        old_tip = %old_tip,
                        new_tip = %new_tip,
                        rolled_back = blocks_rolled_back,
                        applied = blocks_applied,
                        "Chain reorganization completed"
                    );
                    
                    (StatusCode::OK, Json(serde_json::json!({ 
                        "status": "reorg",
                        "old_tip": old_tip,
                        "new_tip": new_tip,
                        "blocks_rolled_back": blocks_rolled_back,
                        "blocks_applied": blocks_applied
                    })))
                }
                ReorgResult::NotNeeded => {
                    // Block is orphaned or fork doesn't have more work
                    tracing::debug!(
                        target: "p2p::block",
                        hash = %block.header.pow_hash,
                        "Block added to orphan pool (no reorg needed)"
                    );
                    
                    // Add to orphan pool
                    let orphan_pool_arc = orphan_pool();
                    let mut pool = orphan_pool_arc.lock();
                    pool.add_orphan(block.clone());
                    
                    (StatusCode::OK, Json(serde_json::json!({ 
                        "status": "orphaned",
                        "hash": block.header.pow_hash
                    })))
                }
                ReorgResult::Failed(reason) => {
                    tracing::warn!(
                        target: "p2p::reorg",
                        hash = %block.header.pow_hash,
                        reason = %reason,
                        "Reorg failed"
                    );
                    
                    (StatusCode::BAD_REQUEST, Json(serde_json::json!({ 
                        "error": "reorg_failed",
                        "reason": reason
                    })))
                }
            }
        }
        None => {
            // Empty chain - this is genesis block
            tracing::info!(
                target: "p2p::block",
                hash = %block.header.pow_hash,
                "Received block for empty chain"
            );
            
            let mut g = crate::CHAIN.lock();
            g.blocks.push(block.clone());
            drop(g);
            
            (StatusCode::OK, Json(serde_json::json!({ 
                "status": "accepted",
                "hash": block.header.pow_hash,
                "genesis": true
            })))
        }
    }
}

/// Send compact block to a specific peer
pub async fn send_compact_block_to_peer(peer: &str, compact: &super::compact::CompactBlock) -> Result<(), String> {
    let url = format!("{}/p2p/compact_block", peer.trim_end_matches('/'));
    
    tracing::debug!(
        target: "p2p::compact",
        peer = %peer,
        hash = %compact.header.hash,
        "Sending compact block"
    );
    
    let response = crate::HTTP
        .post(&url)
        .json(compact)
        .timeout(std::time::Duration::from_secs(5))
        .send()
        .await
        .map_err(|e| format!("Failed to send compact block: {}", e))?;
    
    if response.status().is_success() {
        crate::PROM_COMPACT_BLOCKS_SENT.inc();
        Ok(())
    } else {
        Err(format!("Peer returned error: {}", response.status()))
    }
}

/// Announce compact block to all peers
pub async fn announce_compact_block_to_peers(block: &crate::Block) {
    // Generate compact block
    let compact = super::compact::CompactBlock::from_block_auto(block);
    
    // Get list of connected peers
    let peers: Vec<String> = {
        let g = crate::CHAIN.lock();
        g.peers.iter().cloned().collect()
    };
    
    tracing::info!(
        target: "p2p::compact",
        hash = %block.header.pow_hash,
        height = block.header.number,
        peers = peers.len(),
        compact_size = compact.size_bytes(),
        "Announcing compact block to peers"
    );
    
    // Send to each peer in parallel
    let mut tasks = Vec::new();
    for peer in peers {
        let compact_clone = compact.clone();
        let peer_clone = peer.clone();
        
        let task = tokio::spawn(async move {
            if let Err(e) = send_compact_block_to_peer(&peer_clone, &compact_clone).await {
                tracing::warn!(
                    target: "p2p::compact",
                    peer = %peer_clone,
                    error = %e,
                    "Failed to send compact block"
                );
            }
        });
        
        tasks.push(task);
    }
    
    // Wait for all sends to complete
    for task in tasks {
        let _ = task.await;
    }
}

/// Announce transaction to all peers via INV
pub async fn announce_tx_to_peers(tx_hash: String) {
    use crate::{PROM_TX_INV_SENT, CHAIN};
    
    let peers: Vec<String> = {
        let g = CHAIN.lock();
        g.peers.iter().cloned().collect()
    };
    
    if peers.is_empty() {
        tracing::debug!(
            target: "p2p::tx",
            "No peers to announce tx to"
        );
        return;
    }
    
    tracing::info!(
        target: "p2p::tx",
        tx_hash = %tx_hash,
        peer_count = peers.len(),
        "Announcing transaction to peers"
    );
    
    let inv = super::tx_relay::Inv {
        objects: vec![super::tx_relay::InventoryItem {
            inv_type: super::tx_relay::InvType::Tx,
            hash: tx_hash,
        }],
    };
    
    // Track INV sent metric
    PROM_TX_INV_SENT.inc();
    
    // Spawn tasks to announce to all peers in parallel
    let mut tasks = Vec::new();
    for peer in peers {
        let inv_clone = inv.clone();
        let peer_clone = peer.clone();
        
        let task = tokio::spawn(async move {
            if let Err(e) = super::tx_relay::announce_to_peers(vec![peer_clone.clone()], inv_clone).await {
                tracing::warn!(
                    target: "p2p::tx",
                    peer = %peer_clone,
                    error = %e,
                    "Failed to send tx INV"
                );
            }
        });
        
        tasks.push(task);
    }
    
    // Wait for all sends to complete
    for task in tasks {
        let _ = task.await;
    }
}

/// Get access to orphan pool
pub fn orphan_pool() -> Arc<Mutex<OrphanPool>> {
    ORPHAN_POOL.clone()
}

/// Get access to seen filters
pub fn seen_filters() -> Arc<Mutex<SeenFilters>> {
    SEEN_FILTERS.clone()
}
