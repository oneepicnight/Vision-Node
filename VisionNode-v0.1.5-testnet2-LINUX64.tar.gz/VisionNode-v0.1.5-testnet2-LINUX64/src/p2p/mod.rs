//! P2P Block Synchronization Module
//!
//! Implements headers-first sync with pipelined block fetching
//!
//! Phase 2 Extensions:
//! - Compact blocks (BIP-152 style)
//! - INV/GETDATA transaction relay
//! - Mempool synchronization
//! - Reorg handling

pub mod protocol;
pub mod sync;
pub mod orphans;
pub mod routes;

// Phase 2 modules
pub mod compact;
pub mod tx_relay;
pub mod mempool_sync;
pub mod reorg;

pub use protocol::*;
pub use sync::*;
pub use orphans::*;
