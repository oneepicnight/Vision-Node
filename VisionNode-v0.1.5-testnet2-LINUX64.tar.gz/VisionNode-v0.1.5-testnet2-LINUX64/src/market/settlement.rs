use crate::accounts::TokenAccountsCfg;
use crate::receipts::{write_receipt, Receipt};
use anyhow::Result;
use sled::Db;

// Credit an address with an amount (simplified - replace with your actual balance logic)
fn credit_address(db: &Db, address: &str, amount: u128) -> Result<()> {
    // Get existing balance
    let key = format!("balance:{}", address);
    let current = db
        .get(key.as_bytes())?
        .map(|v| u128::from_be_bytes(v.as_ref().try_into().unwrap_or([0u8; 16])))
        .unwrap_or(0);

    // Add amount
    let new_balance = current.saturating_add(amount);

    // Store back
    db.insert(key.as_bytes(), &new_balance.to_be_bytes())?;

    tracing::info!(
        "Credited {} with {} (new balance: {})",
        address,
        amount,
        new_balance
    );
    Ok(())
}

/// Route sale proceeds according to 50/30/20 split with founder sub-split
pub fn route_proceeds(tok_accounts: &TokenAccountsCfg, db: &Db, total: u128) -> Result<()> {
    let a = tok_accounts;

    // Calculate splits
    let vault_amt = total * (a.vault_pct as u128) / 100u128;
    let fund_amt = total * (a.fund_pct as u128) / 100u128;
    let treasury_amt = total * (a.treasury_pct as u128) / 100u128;

    // Split treasury between founders
    let f1_amt = treasury_amt * (a.founder1_pct as u128) / 100u128;
    let f2_amt = treasury_amt.saturating_sub(f1_amt);

    tracing::info!(
        "Routing {} total: vault={}, fund={}, founder1={}, founder2={}",
        total,
        vault_amt,
        fund_amt,
        f1_amt,
        f2_amt
    );

    // Credit accounts
    credit_address(db, &a.vault_address, vault_amt)?;
    credit_address(db, &a.fund_address, fund_amt)?;
    credit_address(db, &a.founder1_address, f1_amt)?;
    credit_address(db, &a.founder2_address, f2_amt)?;

    // Also update the vault ledger for tracking
    let _ = crate::treasury::vault::route_inflow(
        "CASH",
        vault_amt,
        format!("market_sale_vault total={}", total),
    );
    let _ = crate::treasury::vault::route_inflow(
        "CASH",
        fund_amt,
        format!("market_sale_fund total={}", total),
    );
    let _ = crate::treasury::vault::route_inflow(
        "CASH",
        f1_amt,
        format!("market_sale_founder1 total={}", total),
    );
    let _ = crate::treasury::vault::route_inflow(
        "CASH",
        f2_amt,
        format!("market_sale_founder2 total={}", total),
    );

    // Write receipts for each distribution (best-effort, don't fail on receipt errors)
    let write_settlement_receipt = |to: &str, amount: u128, label: &str| {
        let rec = Receipt {
            id: String::new(),
            ts_ms: 0,
            kind: "market_settle".to_string(),
            from: "market_proceeds".to_string(),
            to: to.to_string(),
            amount: amount.to_string(),
            fee: "0".to_string(),
            memo: Some(format!("{} settlement from market sale", label)),
            txid: None,
            ok: true,
            note: None,
        };
        if let Err(e) = write_receipt(db, None, rec) {
            tracing::warn!("Failed to write {} settlement receipt: {}", label, e);
        }
    };

    write_settlement_receipt(&a.vault_address, vault_amt, "Vault");
    write_settlement_receipt(&a.fund_address, fund_amt, "Fund");
    write_settlement_receipt(&a.founder1_address, f1_amt, "Founder1");
    write_settlement_receipt(&a.founder2_address, f2_amt, "Founder2");

    Ok(())
}
