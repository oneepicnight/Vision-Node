use crate::accounts::TokenAccountsCfg;
use axum::{extract::State, routing::post, Json, Router};
use serde::{Deserialize, Serialize};

#[derive(Clone)]
pub struct MarketState {
    pub db: sled::Db,
    pub tok_accounts: TokenAccountsCfg,
}

#[derive(Deserialize)]
pub struct TestSaleRequest {
    pub amount: u128,
}

#[derive(Serialize)]
pub struct TestSaleResponse {
    pub ok: bool,
    pub total: u128,
    pub vault_amount: u128,
    pub fund_amount: u128,
    pub founder1_amount: u128,
    pub founder2_amount: u128,
}

async fn test_sale_handler(
    State(state): State<MarketState>,
    Json(req): Json<TestSaleRequest>,
) -> Json<TestSaleResponse> {
    // Calculate splits
    let a = &state.tok_accounts;
    let total = req.amount;

    let vault_amt = total * (a.vault_pct as u128) / 100u128;
    let fund_amt = total * (a.fund_pct as u128) / 100u128;
    let treasury_amt = total * (a.treasury_pct as u128) / 100u128;

    let f1_amt = treasury_amt * (a.founder1_pct as u128) / 100u128;
    let f2_amt = treasury_amt.saturating_sub(f1_amt);

    // Route the proceeds
    let _ = crate::market::settlement::route_proceeds(&state.tok_accounts, &state.db, total);

    Json(TestSaleResponse {
        ok: true,
        total,
        vault_amount: vault_amt,
        fund_amount: fund_amt,
        founder1_amount: f1_amt,
        founder2_amount: f2_amt,
    })
}

pub fn router(db: sled::Db, tok_accounts: TokenAccountsCfg) -> Router {
    let state = MarketState { db, tok_accounts };

    Router::new()
        .route("/market/test-sale", post(test_sale_handler))
        .with_state(state)
}
