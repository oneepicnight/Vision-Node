//! HTTP route handlers extracted from main.rs
//!
//! This module organizes route handlers into logical groups:
//! - `wallet` - Balance queries and transfers
//! - `receipts` - Transaction receipt queries
//! - `admin_seed` - Admin endpoint for seeding test balances
//!
//! Each submodule exports handler functions that can be registered with axum Router.
//!
//! # Router Configuration (Future)
//!
//! This module will provide two routing configurations:
//! - **MVP Router** (`mvp_router`): 20 core endpoints for production
//! - **Full Router** (`full_router`): All 200+ experimental endpoints
//!
//! The router will be selected at compile time based on feature flags.
//!
//! ## Current Status: INFRASTRUCTURE READY, MIGRATION PENDING
//!
//! The feature system is active (lite/full), but routes are not yet gated.
//! All routes are currently compiled from the legacy `build_app()` function in main.rs.
//!
//! To complete migration:
//! 1. Audit all 400+ routes in build_app()
//! 2. Create mvp_router() and full_router() functions here
//! 3. Replace build_app() call with routes::create_router()
//! 4. Add #[cfg(feature = "full")] to experimental routes
//!
//! See VISION_LITE_STATUS.md for detailed migration plan.

pub mod admin_seed;
pub mod miner;
pub mod receipts;
pub mod wallet;

// Placeholder for future router functions
// Uncomment when migration is complete:
//
// use axum::{routing::get, Router};
// use std::sync::Arc;
//
// pub fn create_router(state: Arc<crate::AppState>) -> Router {
//     #[cfg(feature = "full")]
//     {
//         eprintln!("📡 Loading FULL router (200+ endpoints)");
//         full_router(state)
//     }
//
//     #[cfg(not(feature = "full"))]
//     {
//         eprintln!("📡 Loading MVP router (20 core endpoints)");
//         mvp_router(state)
//     }
// }
//
// fn mvp_router(state: Arc<crate::AppState>) -> Router {
//     // TODO: 20 MVP routes
//     Router::new().with_state(state)
// }
//
// #[cfg(feature = "full")]
// fn full_router(state: Arc<crate::AppState>) -> Router {
//     // TODO: MVP + 200+ experimental routes
//     mvp_router(state)
// }
