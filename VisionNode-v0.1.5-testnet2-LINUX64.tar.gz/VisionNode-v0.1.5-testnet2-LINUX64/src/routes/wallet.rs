//! Wallet route handlers
//!
//! Provides HTTP handlers for:
//! - GET /wallet/:addr/balance - Query token balance
//! - GET /wallet/:addr/nonce - Query current nonce for replay protection
//! - POST /wallet/transfer - Transfer tokens between addresses

use axum::{
    extract::{Path, State},
    response::IntoResponse,
    Json,
};

use crate::{wallet, DB_CTX, PROM_METRICS};

/// Handler for GET /wallet/:addr/balance
///
/// Queries the balance for a given address from the 'balances' tree.
/// Returns JSON with balance as string (u128).
pub async fn wallet_balance_handler(Path(addr): Path<String>) -> impl IntoResponse {
    let state = wallet::AppState {
        dbctx: DB_CTX.clone(),
        metrics: PROM_METRICS.clone(),
    };
    wallet::get_balance(State(state), Path(addr)).await
}

/// Handler for GET /wallet/:addr/nonce
///
/// Queries the current nonce for a given address from the 'wallet_nonces' tree.
/// Returns JSON with nonce as u64. Used by clients for replay protection.
pub async fn wallet_nonce_handler(Path(addr): Path<String>) -> impl IntoResponse {
    let state = wallet::AppState {
        dbctx: DB_CTX.clone(),
        metrics: PROM_METRICS.clone(),
    };
    wallet::get_nonce(State(state), Path(addr)).await
}

/// Handler for POST /wallet/transfer
///
/// Executes an atomic token transfer from one address to another.
/// Deducts amount + fee from sender, credits amount to recipient,
/// credits fee to __fees__ account, and writes a receipt.
///
/// Request body: TransferReq { from, to, amount, fee }
pub async fn wallet_transfer_handler(Json(req): Json<wallet::TransferReq>) -> impl IntoResponse {
    let state = wallet::AppState {
        dbctx: DB_CTX.clone(),
        metrics: PROM_METRICS.clone(),
    };
    wallet::post_transfer(State(state), Json(req)).await
}
