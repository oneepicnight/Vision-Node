#!/bin/bash
# Vision Node Build Script for Linux

echo "=== Building Vision Node v0.1.5 for Linux ==="
echo ""

# Check if Rust is installed
if ! command -v cargo &> /dev/null
then
    echo "❌ Rust/Cargo not found!"
    echo "Please install Rust first:"
    echo "  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"
    exit 1
fi

echo "✓ Rust found: $(rustc --version)"
echo ""

# Build in release mode
echo "Building vision-node (this may take 5-10 minutes)..."
cargo build --release --features lite

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Build successful!"
    echo ""
    echo "Binary location: target/release/vision-node"
    
    # Copy to root for easier access
    cp target/release/vision-node ./vision-node
    chmod +x ./vision-node
    chmod +x ./START-VISION-NODE.sh
    
    echo ""
    echo "To run the node:"
    echo "  ./START-VISION-NODE.sh"
    echo ""
    echo "Or directly:"
    echo "  ./vision-node --port 7070"
    echo ""
else
    echo ""
    echo "❌ Build failed! Check the error messages above."
    exit 1
fi
