#!/bin/bash
# Vision Node Startup Script for Linux

echo "=== Starting Vision Node v0.1.5 ==="
echo ""

# Check if binary exists
if [ ! -f "./vision-node" ]; then
    echo "❌ vision-node binary not found!"
    echo "Please build it first:"
    echo "  ./build.sh"
    exit 1
fi

# Create data directory if it doesn't exist
mkdir -p vision_data_7070

# Set environment
export RUST_LOG=info
export RUST_BACKTRACE=1

echo "🚀 Starting Vision Node..."
echo ""
echo "Access URLs:"
echo "  Wallet:    http://127.0.0.1:7070/app"
echo "  Panel:     http://127.0.0.1:7070/panel.html"
echo "  Dashboard: http://127.0.0.1:7070/dashboard.html"
echo ""
echo "Press Ctrl+C to stop the node"
echo ""

# Run the node
./vision-node --port 7070 --enable-cors
