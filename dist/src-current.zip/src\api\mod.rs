﻿pub mod vault_routes;
pub mod snapshot;
pub mod website_api;
pub mod discord_oauth;
pub mod upstream;
pub mod peers_api;
pub mod routing_api;
pub mod node_approval_api;

// Re-export website API router for easy access
pub use website_api::website_api_router;
pub use discord_oauth::{DiscordOAuthState, discord_login, discord_callback, discord_status, init_discord_links_db};

use tracing::info;

pub fn log_upstream_mode() {
    use std::env;

    if let Ok(base) = env::var("VISION_UPSTREAM_HTTP_BASE") {
        info!("[UPSTREAM] HTTP upstream enabled: {base}");
    } else {
        info!("[UPSTREAM] No HTTP upstream configured (local-only mode).");
    }
}
