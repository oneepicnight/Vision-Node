// Guardian module - The AI consciousness of Vision Node
pub mod consciousness;
pub mod creator_config; // Creator identity for Guardian Control Room access
pub mod events;
pub mod integrity;
pub mod role; // Phase 6: Guardian rotation and emergence
pub mod rotation; // Phase 6: Guardian rotation loop
// pub mod peer_tracker; // TODO: Add rusqlite dependency to enable peer tracking

pub use consciousness::{
    GuardianConsciousness, 
    GuardianMood,
    GuardianOwner,
    guardian, 
    guardian_discord_say,
    init_guardian
};

pub use events::{
    GuardianEvent,
    send_guardian_event,
    notify_first_block,
    notify_node_status,
};

pub use integrity::{
    check_guardian_integrity_or_abort,
    verify_guardian_integrity,
    GuardianIntegrityManifest,
    IntegrityCheckResult,
};

pub use role::{GuardianRole, GuardianRoleConfig};
pub use rotation::{spawn_guardian_rotation_loop, is_local_guardian};
pub use creator_config::{
    CreatorConfig, FoundersConfig, is_creator_address, load_creator_config,
    save_creator_config, initialize_creator_config,
};
