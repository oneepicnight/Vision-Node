//! Airdrop system module
//!
//! Handles CASH distribution to wallet addresses.

pub mod cash;

pub use cash::{
    CashAirdropError, CashAirdropLimits, CashAirdropRecipient, CashAirdropRequest,
    CashAirdropResult, execute_cash_airdrop, get_cash_balance, get_cash_total_supply,
    update_cash_total_supply, validate_airdrop_request,
};
