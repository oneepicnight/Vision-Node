//! Beacon module - Network discovery and peer registry

pub mod registry;

pub use registry::{
    BeaconPeer, 
    register_peer, 
    get_peers, 
    peer_count, 
    prune_stale_peers,
    purge_ipv6_peers,
    is_ipv4_url,
    is_ipv4_host
};
