//! Node Identity Module
//! 
//! Provides cryptographic node identity based on Ed25519 keypairs.
//! Node ID is deterministically derived from the public key.

pub mod node_id;
pub mod nonce_cache;
pub mod migration;

pub use node_id::{
    node_id_from_pubkey, 
    NodeIdentity, 
    local_node_identity, 
    local_node_id, 
    local_pubkey_b64, 
    local_fingerprint,
    pubkey_fingerprint,
    init_node_identity
};

pub use nonce_cache::{
    check_and_mark_nonce,
    nonce_cache_size,
    clear_nonce_cache,
};

pub use migration::{
    IdentityMigration,
    check_and_migrate_legacy_identity,
    is_legacy_peer,
};
