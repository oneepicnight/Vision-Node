use crate::treasury::vault;
use axum::{response::IntoResponse, routing::get, Json, Router};
use std::sync::Arc;

use crate::metrics;

#[derive(Clone)]
pub struct AppState {
    pub dbctx: Arc<metrics::DbCtx>,
    pub metrics: Arc<metrics::Metrics>,
}

pub fn router() -> Router {
    Router::new()
        .route("/vault", get(get_stats))
        .route("/vault/history", get(get_history))
        .route("/vault/epoch", get(get_epoch))
}

async fn get_stats() -> Json<serde_json::Value> {
    let s = vault::stats();
    Json(serde_json::json!({
        "ok": true,
        "split": { "vault": s.split.vault, "ops": s.split.ops, "founders": s.split.founders },
        "totals": {
            "LAND": { "vault": s.totals_land.0, "ops": s.totals_land.1, "founders": s.totals_land.2 },
            "CASH": { "vault": s.totals_cash.0, "ops": s.totals_cash.1, "founders": s.totals_cash.2 }
        },
        "last_10": s.last_10
    }))
}

async fn get_history() -> Json<serde_json::Value> {
    let s = vault::stats();
    Json(serde_json::json!({
        "ok": true,
        "events": s.last_10, // keep it small; expand later with paging
    }))
}

async fn get_epoch() -> impl IntoResponse {
    // Get current chain height
    let height = {
        let chain = crate::CHAIN.lock();
        chain.blocks.len() as u64
    };

    // Get DB reference
    let db = crate::CHAIN.lock().db.clone();

    // Read real vault totals from sled
    let vault_total = db.get(b"supply:vault")
        .ok()
        .flatten()
        .map(|v| {
            let mut buf = [0u8; 16];
            let bytes = v.as_ref();
            buf[..bytes.len().min(16)].copy_from_slice(&bytes[..bytes.len().min(16)]);
            u128::from_le_bytes(buf)
        })
        .unwrap_or(0);
    
    let fund_total = db.get(b"supply:fund")
        .ok()
        .flatten()
        .map(|v| {
            let mut buf = [0u8; 16];
            let bytes = v.as_ref();
            buf[..bytes.len().min(16)].copy_from_slice(&bytes[..bytes.len().min(16)]);
            u128::from_le_bytes(buf)
        })
        .unwrap_or(0);
    
    let treasury_total = db.get(b"supply:treasury")
        .ok()
        .flatten()
        .map(|v| {
            let mut buf = [0u8; 16];
            let bytes = v.as_ref();
            buf[..bytes.len().min(16)].copy_from_slice(&bytes[..bytes.len().min(16)]);
            u128::from_le_bytes(buf)
        })
        .unwrap_or(0);

    // Get epoch status from vault_epoch module
    let epoch_status = match crate::vault_epoch::get_epoch_status(&db, height) {
        Ok(status) => status,
        Err(_) => {
            return Json(serde_json::json!({
                "error": "Failed to fetch epoch status"
            }))
        }
    };

    Json(serde_json::json!({
        "epoch_index": epoch_status.epoch_index,
        "last_payout_height": epoch_status.last_payout_height,
        "last_payout_at_ms": epoch_status.last_payout_at_ms,
        "vault_balance": vault_total.to_string(),
        "fund_balance": fund_total.to_string(),
        "treasury_balance": treasury_total.to_string(),
        "total_weight": epoch_status.total_weight.to_string(),
        "due": epoch_status.due,
        "height": height
    }))
}
