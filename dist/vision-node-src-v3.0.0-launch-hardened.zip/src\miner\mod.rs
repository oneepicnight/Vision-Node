//! Active mining module with worker threads and VisionX PoW
//!
//! Provides the ActiveMiner struct for managing mining operations

pub mod manager;
pub mod perf_store;
pub mod auto_tuner;
pub mod telemetry;
pub mod thermal;
pub mod power;
pub mod numa;
pub mod intelligent_tuner;
pub mod tuning_hint;
pub mod hint_manager;

pub use manager::ActiveMiner;



