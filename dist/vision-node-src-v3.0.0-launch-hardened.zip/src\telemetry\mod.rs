// Telemetry module for swarm visualization and node health tracking
pub mod swarm_telemetry;
