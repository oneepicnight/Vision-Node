// External Chain Deposit Scanning
// Monitors BTC, BCH, and DOGE chains for deposits to user addresses

use anyhow::{Result, anyhow};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use once_cell::sync::Lazy;

use crate::market::engine::QuoteAsset;
use crate::market::wallet::{DepositEvent, process_deposit};

// HD Wallet derivation
use bip32::XPrv;

/// Global address mapping: deposit_address -> user_id
/// This is persisted to database in production
static ADDRESS_TO_USER: Lazy<Arc<Mutex<HashMap<String, String>>>> = 
    Lazy::new(|| Arc::new(Mutex::new(HashMap::new())));

/// HD wallet master key (should be loaded from secure storage in production)
static HD_MASTER_KEY: Lazy<Arc<Mutex<Option<XPrv>>>> = 
    Lazy::new(|| Arc::new(Mutex::new(None)));

/// Initialize HD wallet with master seed
pub fn init_hd_wallet(seed: &[u8]) -> Result<()> {
    let master_key = XPrv::new(seed).map_err(|e| anyhow!("Failed to create master key: {}", e))?;
    
    let mut key = HD_MASTER_KEY.lock().unwrap();
    *key = Some(master_key);
    
    tracing::info!("🔑 HD wallet initialized");
    Ok(())
}

/// Derive address for user using BIP44 path
/// m/44'/coin_type'/account'/change/address_index
fn derive_address(coin_type: u32, user_index: u32) -> Result<String> {
    let key_guard = HD_MASTER_KEY.lock().unwrap();
    let master_key = key_guard.as_ref()
        .ok_or_else(|| anyhow!("HD wallet not initialized"))?;
    
    // Simplified derivation - in production, implement full BIP44 path derivation
    // For now, generate deterministic address from master key + coin_type + user_index
    let mut key_material = master_key.to_bytes().to_vec();
    key_material.extend_from_slice(&coin_type.to_le_bytes());
    key_material.extend_from_slice(&user_index.to_le_bytes());
    
    let addr_hash = blake3::hash(&key_material);
    let address = format!("bc1q{}", hex::encode(&addr_hash.as_bytes()[..20]));
    
    Ok(address)
}

/// Get user index from user_id (hash-based)
fn user_id_to_index(user_id: &str) -> u32 {
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};
    
    let mut hasher = DefaultHasher::new();
    user_id.hash(&mut hasher);
    (hasher.finish() % 1_000_000) as u32 // Limit to reasonable range
}

/// Public helper: Derive deterministic deposit address for a user on a specific asset
/// 
/// Maps QuoteAsset to BIP44 coin types:
///   - BTC => 0
///   - BCH => 145
///   - DOGE => 3
///   - LAND => None (native asset)
///
/// Address is stable across restarts and machines (same user_id → same address).
pub fn deposit_address_for_user(user_id: &str, asset: QuoteAsset) -> Result<String> {
    let coin_type = match asset {
        QuoteAsset::Btc => 0,
        QuoteAsset::Bch => 145,
        QuoteAsset::Doge => 3,
        QuoteAsset::Land => return Err(anyhow!("LAND is a native asset; no deposit address")),
    };
    
    let user_index = user_id_to_index(user_id);
    derive_address(coin_type, user_index)
}

/// Store address -> user_id mapping
fn store_address_mapping(address: &str, user_id: &str) -> Result<()> {
    let mut map = ADDRESS_TO_USER.lock().unwrap();
    map.insert(address.to_string(), user_id.to_string());
    
    // TODO: Persist to database
    // DB.insert(format!("addr_map:{}", address).as_bytes(), user_id.as_bytes())?;
    
    Ok(())
}

/// Get user_id from address
pub fn get_user_from_address(address: &str) -> Option<String> {
    let map = ADDRESS_TO_USER.lock().unwrap();
    map.get(address).cloned()
}

/// Trait for external blockchain backends
pub trait ExternalChainBackend: Send + Sync {
    /// Get the chain name (BTC, BCH, DOGE)
    fn chain_name(&self) -> &str;
    
    /// Get the QuoteAsset for this chain
    fn quote_asset(&self) -> QuoteAsset;
    
    /// Generate or retrieve deposit address for a user
    /// TODO: Integrate with actual wallet generation (BIP32/BIP44)
    fn get_or_create_deposit_address(&self, user_id: &str) -> Result<String>;
    
    /// Scan for new deposits since last check
    /// Returns list of deposit events with confirmations
    fn scan_new_deposits(&self, last_block_height: u64) -> Result<Vec<DepositEvent>>;
    
    /// Get current block height of the external chain
    fn get_block_height(&self) -> Result<u64>;
    
    /// Get number of confirmations required before crediting
    fn confirmations_required(&self) -> u32 {
        6 // Default: 6 confirmations for security
    }
}

/// Bitcoin backend with RPC connection
pub struct BitcoinBackend {
    coin_type: u32, // BIP44 coin type (0 for BTC, 145 for BCH, 3 for DOGE)
}

impl BitcoinBackend {
    pub fn new() -> Self {
        // Check if external RPC is configured
        let has_rpc = {
            let clients = crate::EXTERNAL_RPC_CLIENTS.lock();
            clients.contains_key(&crate::external_rpc::ExternalChain::Btc)
        };
        
        if has_rpc {
            tracing::info!("✅ Bitcoin RPC configured via external_rpc system");
        } else {
            tracing::warn!("⚠️  Bitcoin RPC not configured - deposits disabled");
        }
        
        Self {
            coin_type: 0, // BTC coin type
        }
    }
    
    fn get_rpc_client(&self) -> Option<Arc<crate::external_rpc::RpcClient>> {
        let clients = crate::EXTERNAL_RPC_CLIENTS.lock();
        clients.get(&crate::external_rpc::ExternalChain::Btc).cloned()
    }
}

impl ExternalChainBackend for BitcoinBackend {
    fn chain_name(&self) -> &str {
        "Bitcoin"
    }
    
    fn quote_asset(&self) -> QuoteAsset {
        QuoteAsset::Btc
    }
    
    fn get_or_create_deposit_address(&self, user_id: &str) -> Result<String> {
        // Check if address already exists
        let existing = {
            let map = ADDRESS_TO_USER.lock().unwrap();
            map.iter()
                .find(|(_, uid)| uid.as_str() == user_id)
                .map(|(addr, _)| addr.clone())
        };
        
        if let Some(addr) = existing {
            return Ok(addr);
        }
        
        // Derive new address using HD wallet
        let user_index = user_id_to_index(user_id);
        let address = derive_address(self.coin_type, user_index)?;
        
        // Store mapping
        store_address_mapping(&address, user_id)?;
        
        tracing::info!("Generated BTC address {} for user {}", address, user_id);
        Ok(address)
    }
    
    fn scan_new_deposits(&self, last_block_height: u64) -> Result<Vec<DepositEvent>> {
        let client = match self.get_rpc_client() {
            Some(c) => c,
            None => return Ok(Vec::new()), // No RPC, no deposits
        };
        
        let mut deposits = Vec::new();
        
        // Get current block height using external RPC
        let current_height_future = async {
            let result = client.call_no_params("getblockcount").await?;
            result.as_u64().ok_or_else(|| anyhow!("Invalid block count response"))
        };
        
        let current_height = tokio::runtime::Handle::current()
            .block_on(current_height_future)
            .map_err(|e| anyhow!("Failed to get block count: {}", e))?;
        
        // Scan blocks from last_block_height to current
        // Note: This is a simplified implementation that scans for deposits
        // In production, consider using a more efficient approach with address indexing
        for height in last_block_height..=current_height {
            let scan_future = async {
                // Get block hash at height
                let hash_result = client.call("getblockhash", serde_json::json!([height])).await?;
                let block_hash = hash_result.as_str()
                    .ok_or_else(|| anyhow!("Invalid block hash response"))?;
                
                // Get block with transactions (verbosity=2 for full tx details)
                let block_result = client.call("getblock", serde_json::json!([block_hash, 2])).await?;
                
                // Parse transactions
                if let Some(tx_array) = block_result.get("tx").and_then(|v| v.as_array()) {
                    for tx in tx_array {
                        let txid = tx.get("txid")
                            .and_then(|v| v.as_str())
                            .unwrap_or("");
                        
                        // Check outputs
                        if let Some(vout_array) = tx.get("vout").and_then(|v| v.as_array()) {
                            for (vout_idx, vout) in vout_array.iter().enumerate() {
                                let value = vout.get("value")
                                    .and_then(|v| v.as_f64())
                                    .unwrap_or(0.0);
                                
                                // Get addresses from scriptPubKey
                                if let Some(addresses) = vout.get("scriptPubKey")
                                    .and_then(|sp| sp.get("addresses"))
                                    .and_then(|a| a.as_array()) 
                                {
                                    for addr_val in addresses {
                                        if let Some(addr_str) = addr_val.as_str() {
                                            // Check if this address belongs to one of our users
                                            if let Some(user_id) = get_user_from_address(addr_str) {
                                                let confirmations = (current_height - height) as u32 + 1;
                                                
                                                return Ok::<Option<DepositEvent>, anyhow::Error>(Some(DepositEvent {
                                                    user_id: user_id.clone(),
                                                    asset: QuoteAsset::Btc,
                                                    amount: value,
                                                    txid: format!("{}:{}", txid, vout_idx),
                                                    confirmations,
                                                }));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                Ok::<Option<DepositEvent>, anyhow::Error>(None)
            };
            
            match tokio::runtime::Handle::current().block_on(scan_future) {
                Ok(Some(deposit)) => {
                    tracing::info!(
                        "📥 BTC deposit detected: {} BTC to user {} ({} confirmations)",
                        deposit.amount, deposit.user_id, deposit.confirmations
                    );
                    deposits.push(deposit);
                }
                Ok(None) => {}
                Err(e) => {
                    tracing::warn!("Failed to scan block at height {}: {}", height, e);
                }
            }
        }
        
        Ok(deposits)
    }
    
    fn get_block_height(&self) -> Result<u64> {
        let client = match self.get_rpc_client() {
            Some(c) => c,
            None => return Ok(0),
        };
        
        let height_future = async {
            let result = client.call_no_params("getblockcount").await?;
            result.as_u64().ok_or_else(|| anyhow!("Invalid block count response"))
        };
        
        tokio::runtime::Handle::current()
            .block_on(height_future)
            .map_err(|e| anyhow!("Failed to get block height: {}", e))
    }
}

/// Bitcoin Cash backend (uses same RPC interface as Bitcoin)
pub struct BitcoinCashBackend {
    coin_type: u32,
}

impl BitcoinCashBackend {
    pub fn new() -> Self {
        let has_rpc = {
            let clients = crate::EXTERNAL_RPC_CLIENTS.lock();
            clients.contains_key(&crate::external_rpc::ExternalChain::Bch)
        };
        
        if has_rpc {
            tracing::info!("✅ Bitcoin Cash RPC configured via external_rpc system");
        } else {
            tracing::warn!("⚠️  Bitcoin Cash RPC not configured - deposits disabled");
        }
        
        Self {
            coin_type: 145, // BCH coin type
        }
    }
    
    fn get_rpc_client(&self) -> Option<Arc<crate::external_rpc::RpcClient>> {
        let clients = crate::EXTERNAL_RPC_CLIENTS.lock();
        clients.get(&crate::external_rpc::ExternalChain::Bch).cloned()
    }
}

impl ExternalChainBackend for BitcoinCashBackend {
    fn chain_name(&self) -> &str {
        "Bitcoin Cash"
    }
    
    fn quote_asset(&self) -> QuoteAsset {
        QuoteAsset::Bch
    }
    
    fn get_or_create_deposit_address(&self, user_id: &str) -> Result<String> {
        let existing = {
            let map = ADDRESS_TO_USER.lock().unwrap();
            map.iter()
                .find(|(addr, uid)| uid.as_str() == user_id && addr.starts_with("bitcoincash:"))
                .map(|(addr, _)| addr.clone())
        };
        
        if let Some(addr) = existing {
            return Ok(addr);
        }
        
        let user_index = user_id_to_index(user_id);
        let address = derive_address(self.coin_type, user_index)?;
        let bch_address = format!("bitcoincash:{}", address); // BCH address format
        
        store_address_mapping(&bch_address, user_id)?;
        
        tracing::info!("Generated BCH address {} for user {}", bch_address, user_id);
        Ok(bch_address)
    }
    
    fn scan_new_deposits(&self, _last_block_height: u64) -> Result<Vec<DepositEvent>> {
        // Similar to Bitcoin scanning (omitted for brevity - would be same logic)
        tracing::debug!("BCH scanning enabled but not fully implemented in this version");
        Ok(Vec::new())
    }
    
    fn get_block_height(&self) -> Result<u64> {
        let client = match self.get_rpc_client() {
            Some(c) => c,
            None => return Ok(0),
        };
        
        let height_future = async {
            let result = client.call_no_params("getblockcount").await?;
            result.as_u64().ok_or_else(|| anyhow!("Invalid block count response"))
        };
        
        tokio::runtime::Handle::current()
            .block_on(height_future)
            .map_err(|e| anyhow!("Failed to get block height: {}", e))
    }
}

/// Dogecoin backend (uses same RPC interface)
pub struct DogecoinBackend {
    coin_type: u32,
}

impl DogecoinBackend {
    pub fn new() -> Self {
        let has_rpc = {
            let clients = crate::EXTERNAL_RPC_CLIENTS.lock();
            clients.contains_key(&crate::external_rpc::ExternalChain::Doge)
        };
        
        if has_rpc {
            tracing::info!("✅ Dogecoin RPC configured via external_rpc system");
        } else {
            tracing::warn!("⚠️  Dogecoin RPC not configured - deposits disabled");
        }
        
        Self {
            coin_type: 3, // DOGE coin type
        }
    }
    
    fn get_rpc_client(&self) -> Option<Arc<crate::external_rpc::RpcClient>> {
        let clients = crate::EXTERNAL_RPC_CLIENTS.lock();
        clients.get(&crate::external_rpc::ExternalChain::Doge).cloned()
    }
}

impl ExternalChainBackend for DogecoinBackend {
    fn chain_name(&self) -> &str {
        "Dogecoin"
    }
    
    fn quote_asset(&self) -> QuoteAsset {
        QuoteAsset::Doge
    }
    
    fn get_or_create_deposit_address(&self, user_id: &str) -> Result<String> {
        let existing = {
            let map = ADDRESS_TO_USER.lock().unwrap();
            map.iter()
                .find(|(addr, uid)| uid.as_str() == user_id && addr.starts_with("D"))
                .map(|(addr, _)| addr.clone())
        };
        
        if let Some(addr) = existing {
            return Ok(addr);
        }
        
        let user_index = user_id_to_index(user_id);
        let address = derive_address(self.coin_type, user_index)?;
        
        store_address_mapping(&address, user_id)?;
        
        tracing::info!("Generated DOGE address {} for user {}", address, user_id);
        Ok(address)
    }
    
    fn scan_new_deposits(&self, _last_block_height: u64) -> Result<Vec<DepositEvent>> {
        tracing::debug!("DOGE scanning enabled but not fully implemented in this version");
        Ok(Vec::new())
    }
    
    fn get_block_height(&self) -> Result<u64> {
        let client = match self.get_rpc_client() {
            Some(c) => c,
            None => return Ok(0),
        };
        
        let height_future = async {
            let result = client.call_no_params("getblockcount").await?;
            result.as_u64().ok_or_else(|| anyhow!("Invalid block count response"))
        };
        
        tokio::runtime::Handle::current()
            .block_on(height_future)
            .map_err(|e| anyhow!("Failed to get block height: {}", e))
    }
}

/// Last scanned block heights per chain
static LAST_SCANNED_HEIGHTS: Lazy<Arc<Mutex<HashMap<String, u64>>>> = 
    Lazy::new(|| Arc::new(Mutex::new(HashMap::new())));

fn get_last_scanned_height(chain_name: &str) -> u64 {
    let heights = LAST_SCANNED_HEIGHTS.lock().unwrap();
    heights.get(chain_name).copied().unwrap_or(0)
}

fn update_last_scanned_height(chain_name: &str, height: u64) {
    let mut heights = LAST_SCANNED_HEIGHTS.lock().unwrap();
    heights.insert(chain_name.to_string(), height);
    // TODO: Persist to database
}

/// Deposit scanner manager
pub struct DepositScanner {
    backends: Vec<Box<dyn ExternalChainBackend>>,
}

impl DepositScanner {
    /// Create new deposit scanner with all supported chains
    pub fn new() -> Self {
        let backends: Vec<Box<dyn ExternalChainBackend>> = vec![
            Box::new(BitcoinBackend::new()),
            Box::new(BitcoinCashBackend::new()),
            Box::new(DogecoinBackend::new()),
        ];
        
        Self { backends }
    }
    
    /// Run one scan cycle across all chains
    /// Should be called periodically (e.g., every 30 seconds)
    pub fn scan_all_chains(&self) -> Result<usize> {
        let mut total_deposits = 0;
        
        for backend in &self.backends {
            let chain_name = backend.chain_name();
            
            // Get last scanned block height from state
            let last_height = get_last_scanned_height(chain_name);
            
            // Get current block height
            let current_height = match backend.get_block_height() {
                Ok(h) if h > 0 => h,
                _ => {
                    tracing::debug!("{} node not available, skipping scan", chain_name);
                    continue;
                }
            };
            
            // Only scan if there are new blocks
            if current_height <= last_height {
                continue;
            }
            
            match backend.scan_new_deposits(last_height) {
                Ok(deposits) => {
                    for deposit in deposits {
                        // Only process deposits with sufficient confirmations
                        if deposit.confirmations >= backend.confirmations_required() {
                            match process_deposit(deposit.clone()) {
                                Ok(_) => {
                                    tracing::info!(
                                        "✅ Processed deposit: {} {} to {} (txid: {})",
                                        deposit.amount,
                                        deposit.asset.as_str(),
                                        deposit.user_id,
                                        deposit.txid
                                    );
                                    total_deposits += 1;
                                }
                                Err(e) => {
                                    tracing::error!(
                                        "Failed to process deposit for {}: {}",
                                        deposit.user_id,
                                        e
                                    );
                                }
                            }
                        } else {
                            tracing::debug!(
                                "Deposit pending: {} {} to {} ({}/{} confirmations)",
                                deposit.amount,
                                deposit.asset.as_str(),
                                deposit.user_id,
                                deposit.confirmations,
                                backend.confirmations_required()
                            );
                        }
                    }
                    
                    // Update last scanned height
                    update_last_scanned_height(chain_name, current_height);
                }
                Err(e) => {
                    tracing::warn!("Failed to scan {} deposits: {}", chain_name, e);
                }
            }
        }
        
        Ok(total_deposits)
    }
}

/// Background task that runs deposit scanning periodically
pub async fn run_deposit_scanner() {
    let scanner = DepositScanner::new();
    let mut interval = tokio::time::interval(tokio::time::Duration::from_secs(30));
    
    tracing::info!("🔍 Starting deposit scanner (checking every 30 seconds)");
    
    loop {
        interval.tick().await;
        
        match scanner.scan_all_chains() {
            Ok(count) if count > 0 => {
                tracing::info!("Deposit scan complete: processed {} deposits", count);
            }
            Ok(_) => {
                tracing::debug!("Deposit scan complete: no new deposits");
            }
            Err(e) => {
                tracing::error!("Deposit scan failed: {}", e);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_backend_creation() {
        let btc = BitcoinBackend::new();
        assert_eq!(btc.chain_name(), "Bitcoin");
        assert_eq!(btc.confirmations_required(), 6);
        
        let bch = BitcoinCashBackend::new();
        assert_eq!(bch.chain_name(), "Bitcoin Cash");
        
        let doge = DogecoinBackend::new();
        assert_eq!(doge.chain_name(), "Dogecoin");
    }
    
    #[test]
    fn test_scanner_creation() {
        let scanner = DepositScanner::new();
        assert_eq!(scanner.backends.len(), 3);
    }
}


