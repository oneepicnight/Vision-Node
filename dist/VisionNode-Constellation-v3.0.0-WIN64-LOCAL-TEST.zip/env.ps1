﻿# Local test mode and shared PeerBook scope
$env:VISION_LOCAL_TEST = "1"
$env:VISION_PEERBOOK_SCOPE = "local-5nodes"
$env:VISION_ALLOW_PRIVATE_PEERS = "true"

# Optional: override per run
# $env:VISION_HTTP_PORT = "7070"
# $env:VISION_P2P_PORT = "7072"
# $env:VISION_P2P_SEEDS = "127.0.0.1:8082,127.0.0.1:9092"
