//! Beacon module - Network discovery and peer registry
#![allow(dead_code)]

pub mod registry;

pub use registry::{
    BeaconPeer, 
    register_peer, 
    get_peers,
};
