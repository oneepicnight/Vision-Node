fn main() {
    let lite = std::env::var_os("CARGO_FEATURE_LITE").is_some();
    let full = std::env::var_os("CARGO_FEATURE_FULL").is_some();

    if lite && full {
        panic!("Features 'lite' and 'full' are mutually exclusive. Choose one.");
    }

    // Print which build is active
    if lite {
        println!("cargo:warning=Building Vision Node - LITE (MVP) variant");
    } else if full {
        println!("cargo:warning=Building Vision Node - FULL (advanced) variant");
    }
}
