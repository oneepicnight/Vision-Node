@echo off
echo.
echo Vision Wallet Installer
echo.
echo This will install the wallet into your Vision Node installation.
echo Make sure Vision Node is already installed!
echo.
pause

PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL.ps1"

pause
