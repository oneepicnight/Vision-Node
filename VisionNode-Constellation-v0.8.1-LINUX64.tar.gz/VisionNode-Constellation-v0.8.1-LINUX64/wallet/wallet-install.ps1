# Vision Wallet - Quick Installer
# Installs wallet into Vision Node's public directory

$ErrorActionPreference = "Stop"

Write-Host "`n+--------------------------------------------------------------+" -ForegroundColor Cyan
Write-Host "|              VISION WALLET - Quick Installer                  |" -ForegroundColor Cyan
Write-Host "+--------------------------------------------------------------+`n" -ForegroundColor Cyan

$installDir = Join-Path $env:LOCALAPPDATA "VisionBlockchain"
$walletDest = Join-Path $installDir "public\wallet"
$scriptDir = $PSScriptRoot

# Check if Vision Node is installed
if (-not (Test-Path $installDir)) {
    Write-Host "[ERROR] Vision Node not found!" -ForegroundColor Red
    Write-Host "Please install Vision Node first before installing the wallet.`n" -ForegroundColor Yellow
    pause
    exit 1
}

Write-Host "Vision Node found at: $installDir" -ForegroundColor Green
Write-Host "Installing wallet...`n" -ForegroundColor Yellow

# Create wallet directory
try {
    New-Item -ItemType Directory -Path $walletDest -Force | Out-Null
    Write-Host "[OK] Wallet directory created" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Failed to create directory: $_" -ForegroundColor Red
    pause
    exit 1
}

# Copy wallet files
try {
    Copy-Item -Path (Join-Path $scriptDir "*") -Destination $walletDest -Recurse -Force -Exclude "INSTALL.bat", "INSTALL.ps1", "README.txt"
    Write-Host "[OK] Wallet files copied" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Failed to copy files: $_" -ForegroundColor Red
    pause
    exit 1
}

# Verify installation
$requiredFiles = @(
    (Join-Path $walletDest "index.html"),
    (Join-Path $walletDest "vite.svg"),
    (Join-Path $walletDest "assets")
)

$allExist = $true
foreach ($file in $requiredFiles) {
    if (-not (Test-Path $file)) {
        Write-Host "[WARN] Missing: $file" -ForegroundColor Yellow
        $allExist = $false
    }
}

if ($allExist) {
    Write-Host "[OK] All wallet files verified`n" -ForegroundColor Green
} else {
    Write-Host "[WARN] Some files may be missing`n" -ForegroundColor Yellow
}

# Create desktop shortcut
Write-Host "Creating desktop shortcut..." -ForegroundColor Yellow
try {
    $WshShell = New-Object -ComObject WScript.Shell
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    
    # Create launcher script
    $launcherPath = Join-Path $installDir "Start-VisionWallet.bat"
    $launcherContent = @"
@echo off
echo Opening Vision Wallet...
start http://localhost:7070/wallet/
"@
    [System.IO.File]::WriteAllText($launcherPath, $launcherContent, [System.Text.Encoding]::ASCII)
    
    # Create shortcut
    $walletShortcut = $WshShell.CreateShortcut((Join-Path $desktopPath "Vision Wallet.lnk"))
    $walletShortcut.TargetPath = $launcherPath
    $walletShortcut.WorkingDirectory = $installDir
    $walletShortcut.Description = "Open Vision Wallet"
    $walletShortcut.IconLocation = "%SystemRoot%\System32\imageres.dll,109"  # Credit card/wallet icon
    $walletShortcut.Save()
    
    Write-Host "[OK] Desktop shortcut created`n" -ForegroundColor Green
} catch {
    Write-Host "[WARN] Shortcut creation failed: $_" -ForegroundColor Yellow
}

# Success message
Write-Host "+--------------------------------------------------------------+" -ForegroundColor Green
Write-Host "|                  INSTALLATION COMPLETE!                       |" -ForegroundColor Green
Write-Host "+--------------------------------------------------------------+`n" -ForegroundColor Green

Write-Host "Vision Wallet has been installed successfully!`n" -ForegroundColor Cyan

Write-Host "Installation Location:" -ForegroundColor Yellow
Write-Host "  $walletDest`n" -ForegroundColor White

Write-Host "How to use:" -ForegroundColor Yellow
Write-Host "  1. Make sure Vision Node is running" -ForegroundColor White
Write-Host "  2. Double-click 'Vision Wallet' icon on your desktop" -ForegroundColor White
Write-Host "  3. Or visit: http://localhost:7070/wallet/`n" -ForegroundColor White

Write-Host "[TIP] If wallet doesn't load, restart Vision Node`n" -ForegroundColor Cyan

Write-Host "Press any key to finish..." -ForegroundColor Cyan
pause | Out-Null
