#!/bin/bash
# Vision Constellation Node - One-Click Installer
# v0.8.0 - 48-Hour Testnet Edition
# Automated setup script for Ubuntu/Debian and RHEL/Fedora systems

set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_banner() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}   VISION CONSTELLATION NODE - ONE-CLICK INSTALLER${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo "  Version: 0.8.0 (48-Hour Testnet)"
    echo "  Network: vision-testnet-48h-v0.8.0"
    echo ""
}

check_os() {
    echo -e "${YELLOW}→ Detecting operating system...${NC}"
    
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$ID
        echo "  Detected: $PRETTY_NAME"
    else
        echo -e "${RED}✗ Cannot detect OS. This script requires /etc/os-release${NC}"
        exit 1
    fi
}

check_rust() {
    echo ""
    echo -e "${YELLOW}→ Checking for Rust installation...${NC}"
    
    if command -v cargo &> /dev/null; then
        RUST_VERSION=$(cargo --version | awk '{print $2}')
        echo -e "${GREEN}✓ Rust found: $RUST_VERSION${NC}"
        return 0
    else
        echo -e "${YELLOW}  Rust not found. Installing...${NC}"
        install_rust
    fi
}

install_rust() {
    echo "  Downloading Rust installer..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    
    # Source cargo environment
    . "$HOME/.cargo/env"
    
    if command -v cargo &> /dev/null; then
        echo -e "${GREEN}✓ Rust installed successfully${NC}"
    else
        echo -e "${RED}✗ Rust installation failed. Please install manually:${NC}"
        echo "  https://rustup.rs"
        exit 1
    fi
}

install_dependencies() {
    echo ""
    echo -e "${YELLOW}→ Installing system dependencies...${NC}"
    
    case $OS in
        ubuntu|debian|pop)
            echo "  Using apt package manager..."
            sudo apt-get update -qq
            sudo apt-get install -y -qq \
                build-essential \
                pkg-config \
                libssl-dev \
                curl \
                git
            ;;
        fedora|rhel|centos)
            echo "  Using dnf/yum package manager..."
            sudo dnf install -y \
                gcc \
                gcc-c++ \
                make \
                pkgconfig \
                openssl-devel \
                curl \
                git
            ;;
        arch|manjaro)
            echo "  Using pacman package manager..."
            sudo pacman -Sy --noconfirm \
                base-devel \
                openssl \
                curl \
                git
            ;;
        *)
            echo -e "${YELLOW}⚠ Unsupported OS: $OS${NC}"
            echo "  Please install manually:"
            echo "  - build-essential / development tools"
            echo "  - OpenSSL development libraries"
            echo "  - curl and git"
            read -p "  Continue anyway? (y/N): " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                exit 1
            fi
            ;;
    esac
    
    echo -e "${GREEN}✓ Dependencies installed${NC}"
}

build_node() {
    echo ""
    echo -e "${YELLOW}→ Building Vision Node (this takes 10-15 minutes)...${NC}"
    echo "  Compiling with optimizations..."
    
    cargo build --release 2>&1 | grep -E "(Compiling|Finished)" || true
    
    if [ -f "target/release/vision-node" ]; then
        cp target/release/vision-node ./vision-node
        chmod +x ./vision-node
        echo -e "${GREEN}✓ Build successful!${NC}"
        
        # Get binary size
        SIZE=$(du -h vision-node | awk '{print $1}')
        echo "  Binary size: $SIZE"
    else
        echo -e "${RED}✗ Build failed. Check output above for errors.${NC}"
        exit 1
    fi
}

setup_scripts() {
    echo ""
    echo -e "${YELLOW}→ Setting up launch scripts...${NC}"
    
    # Make START-VISION-NODE.sh executable if it exists
    if [ -f "START-VISION-NODE.sh" ]; then
        chmod +x START-VISION-NODE.sh
        echo -e "${GREEN}✓ START-VISION-NODE.sh ready${NC}"
    else
        echo -e "${YELLOW}⚠ START-VISION-NODE.sh not found (you can run ./vision-node directly)${NC}"
        # Create a basic launch script if missing
        cat > START-VISION-NODE.sh <<'EOF'
#!/usr/bin/env bash
echo "🌟 Starting Vision Node (Constellation mode)..."
cd "$(dirname "$0")"

# Set environment variables
export VISION_PUBLIC_DIR="$PWD/public"
export VISION_WALLET_DIR="$PWD/wallet/dist"
export BEACON_ENDPOINT="https://visionworld.tech"

echo "Guardian Beacon: $BEACON_ENDPOINT"
echo ""

if [ -f "./target/release/vision-node" ]; then
    exec ./target/release/vision-node --role constellation
elif [ -f "./vision-node" ]; then
    exec ./vision-node --role constellation
else
    echo "❌ Binary not found. Build with: cargo build --release"
    exit 1
fi
EOF
        chmod +x START-VISION-NODE.sh
        echo -e "${GREEN}✓ Created START-VISION-NODE.sh${NC}"
    fi
    
    chmod +x build.sh 2>/dev/null || true
    
    echo -e "${GREEN}✓ Scripts ready${NC}"
}

create_systemd_service() {
    echo ""
    echo -e "${YELLOW}→ Creating systemd service (optional)...${NC}"
    read -p "  Install as system service? (y/N): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        SERVICE_FILE="/etc/systemd/system/vision-node.service"
        INSTALL_DIR=$(pwd)
        
        sudo tee $SERVICE_FILE > /dev/null <<EOF
[Unit]
Description=Vision Constellation Node
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR
Environment="RUST_LOG=info"
Environment="RUST_BACKTRACE=1"
Environment="VISION_NETWORK=vision-testnet-48h-v0.8.0"
Environment="VISION_PUBLIC_DIR=$INSTALL_DIR/public"
Environment="VISION_WALLET_DIR=$INSTALL_DIR/wallet/dist"
Environment="BEACON_ENDPOINT=https://visionworld.tech"
ExecStart=$INSTALL_DIR/vision-node --port 7070 --enable-cors
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
        
        sudo systemctl daemon-reload
        sudo systemctl enable vision-node
        
        echo -e "${GREEN}✓ Service installed${NC}"
        echo "  Start with: sudo systemctl start vision-node"
        echo "  Status:     sudo systemctl status vision-node"
        echo "  Logs:       sudo journalctl -u vision-node -f"
    else
        echo "  Skipped. Use ./START-VISION-NODE.sh to run manually."
    fi
}

setup_firewall() {
    echo ""
    echo -e "${YELLOW}→ Configuring firewall (optional)...${NC}"
    read -p "  Open port 7070 in firewall? (y/N): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if command -v ufw &> /dev/null; then
            sudo ufw allow 7070/tcp
            echo -e "${GREEN}✓ UFW rule added${NC}"
        elif command -v firewall-cmd &> /dev/null; then
            sudo firewall-cmd --permanent --add-port=7070/tcp
            sudo firewall-cmd --reload
            echo -e "${GREEN}✓ Firewalld rule added${NC}"
        else
            echo -e "${YELLOW}  No firewall manager detected. Configure manually if needed.${NC}"
        fi
    fi
}

print_completion() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}   INSTALLATION COMPLETE!${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${GREEN}✓${NC} Vision Node built and ready"
    echo ""
    echo "QUICK START:"
    echo "  1. Start node:  ./START-VISION-NODE.sh"
    echo "  2. Open browser: http://localhost:7070/dashboard.html"
    echo "  3. Wallet:       http://localhost:7070/app"
    echo ""
    echo "48-HOUR TIMELINE:"
    echo "  Hour 0-24:  Mining phase (VisionX PoW)"
    echo "  Hour 24-48: Staking phase (validator rewards)"
    echo "  Hour 48:    Automatic sunset and final snapshot"
    echo ""
    echo "CONFIGURATION:"
    echo "  Config file:  vision.conf"
    echo "  Data folder:  vision_data_7070/"
    echo "  Logs:         logs/"
    echo ""
    echo "SUPPORT:"
    echo "  Documentation: README.txt"
    echo "  Issues:        github.com/oneepicnight/Vision-Node"
    echo ""
    echo -e "${YELLOW}Note:${NC} This is a 48-hour testnet. Join early for maximum rewards!"
    echo ""
}

# Main installation flow
main() {
    print_banner
    
    # System checks
    check_os
    check_rust
    install_dependencies
    
    # Build and setup
    build_node
    setup_scripts
    
    # Optional configurations
    create_systemd_service
    setup_firewall
    
    # Completion
    print_completion
}

# Run installer
main
