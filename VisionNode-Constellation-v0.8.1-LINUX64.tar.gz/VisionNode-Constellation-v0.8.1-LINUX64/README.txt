Vision Node - Constellation Mode (v0.8.0)
==========================================

Linux 64-bit Build - Full Source Distribution

QUICK START
===========

Method 1: One-Click Installer (Recommended)
--------------------------------------------
./install.sh

This will:
- Check your Linux distribution (Ubuntu/Debian/Fedora/Arch)
- Install Rust if needed
- Install system dependencies
- Build the node (takes 10-15 minutes)
- Set up launch scripts
- Optionally create a systemd service

Method 2: Manual Installation
-----------------------------
1. Install Rust (if not already installed):
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   source $HOME/.cargo/env

2. Install dependencies:
   # Ubuntu/Debian:
   sudo apt update
   sudo apt install build-essential pkg-config libssl-dev curl git

   # Fedora:
   sudo dnf install gcc openssl-devel curl git

   # Arch:
   sudo pacman -S base-devel openssl curl git

3. Build the node:
   cargo build --release
   (This takes 10-15 minutes)

4. Start the node:
   ./START-VISION-NODE.sh

   Or run directly:
   ./target/release/vision-node --role constellation


STARTING THE NODE
=================

After installation, start the node with:

   ./START-VISION-NODE.sh

Or run the binary directly:

   chmod +x vision-node
   ./vision-node --role constellation

Or from the build directory:

   ./target/release/vision-node --role constellation


SYSTEMD SERVICE (Optional)
===========================

If you chose to install as a service during setup:

   sudo systemctl start vision-node
   sudo systemctl enable vision-node
   sudo systemctl status vision-node

View logs:
   sudo journalctl -u vision-node -f


FIREWALL CONFIGURATION
======================

Constellation nodes need port 7070 open:

   # Ubuntu/Debian (UFW):
   sudo ufw allow 7070/tcp
   sudo ufw enable

   # Fedora/RHEL (firewalld):
   sudo firewall-cmd --permanent --add-port=7070/tcp
   sudo firewall-cmd --reload

   # Arch (iptables):
   sudo iptables -A INPUT -p tcp --dport 7070 -j ACCEPT
   sudo iptables-save


VERIFICATION
============

Check if the node is running:

   curl http://localhost:7070/status

Expected output:
   {"height":..., "peers":..., "network_id":"constellation", ...}


TROUBLESHOOTING
===============

Build fails?
- Make sure you have at least 4GB RAM
- Try: cargo clean && cargo build --release
- Check Rust version: rustc --version (should be 1.70+)

Port already in use?
- Check: netstat -tlnp | grep 7070
- Kill existing process: pkill -f vision-node

Can't connect?
- Check firewall: sudo ufw status
- Check if node is running: ps aux | grep vision-node
- Check logs: journalctl -u vision-node -f

Permission denied on START-VISION-NODE.sh?
- Run: chmod +x START-VISION-NODE.sh


CONFIGURATION
=============

The node runs with these defaults:
- Port: 7070
- Data directory: ./data
- Network mode: Constellation
- P2P enabled: Yes

To customize:
   ./vision-node --help

Common options:
   --port <PORT>          Change HTTP port (default: 7070)
   --data <DIR>           Set data directory
   --role constellation   Run in constellation mode


PACKAGE CONTENTS
================

VisionNode-Constellation-v0.8.0-LINUX64/
 install.sh                  # One-click installer
 START-VISION-NODE.sh        # Launch script
 build.rs                    # Build configuration
 Cargo.toml                  # Rust dependencies
 Cargo.lock                  # Locked dependencies
 VERSION                     # Version file
 src/                        # Source code
 config/                     # Configuration files
 public/                     # Web dashboard & wallet
 wallet/                     # Wallet UI assets


FEATURES
========

This Constellation build includes:
 Full blockchain consensus
 P2P networking & sync
 Mining & staking
 Multi-currency wallet (LAND, GAME, CASH)
 Web dashboard (http://localhost:7070/dashboard.html)
 Integrated wallet UI (http://localhost:7070/app)
 REST API for queries
 Guardian mode support
 Snapshot management
 Prometheus metrics


SUPPORT
=======

Documentation: ./docs/
GitHub: https://github.com/oneepicnight/Vision-Node
Discord: [Your Discord Link]

For installation issues, include:
- Linux distribution & version (cat /etc/os-release)
- Rust version (rustc --version)
- Error messages from install.sh or cargo build


VERSION INFO
============

Version: 0.8.0
Build: Constellation (Linux 64-bit)
Release Date: November 2025
License: MIT
