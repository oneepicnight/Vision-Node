// --- imports & globals (restored) ---
use std::{env, time::{SystemTime, UNIX_EPOCH, Duration}, net::SocketAddr, sync::atomic::Ordering};
use std::collections::{BTreeMap, BTreeSet, VecDeque};
use parking_lot::Mutex;
use once_cell::sync::Lazy;
use sled::{Db, IVec};
use std::sync::atomic::AtomicU64;

use axum::{
    Router,
    Json,
    extract::{Query, Path, ConnectInfo},
    response::IntoResponse,
    routing::{get, post},
};
use axum::http::{StatusCode, HeaderMap, HeaderValue};
// We'll use a small custom CORS middleware to enforce VISION_CORS_ORIGINS precisely.
use tower_http::cors::{CorsLayer, Any};
// tower imports were experimented with earlier but are unused; remove to silence warnings
// ...existing code...

use serde::{Serialize, Deserialize};
use thiserror::Error;

use reqwest::Client;

// shared HTTP client used around the node
static HTTP: Lazy<Client> = Lazy::new(|| Client::new());

use blake3::Hasher;
use ed25519_dalek::{PublicKey, Signature, Verifier};
use tracing::{info, debug};
use tracing_subscriber::EnvFilter;
use dashmap::DashMap;
mod mempool;
mod version;
mod types;
mod p2p;
mod auto_sync;
mod consensus;
use tower_http::services::{ServeDir, ServeFile};
use std::path::PathBuf;

// Prometheus metrics infrastructure
use prometheus::{IntCounter, IntGauge, Gauge, Histogram, HistogramOpts, Opts};

fn mk_gauge(name: &str, help: &str) -> Gauge {
    let opts = Opts::new(name, help);
    Gauge::with_opts(opts).expect("create gauge")
}

fn mk_int_gauge(name: &str, help: &str) -> IntGauge {
    let opts = Opts::new(name, help);
    IntGauge::with_opts(opts).expect("create int gauge")
}

fn mk_int_counter(name: &str, help: &str) -> IntCounter {
    let opts = Opts::new(name, help);
    IntCounter::with_opts(opts).expect("create int counter")
}

// Replace earlier DashMap usage with a simple Mutex-wrapped BTreeMap to avoid adding deps
static PEERS: Lazy<Mutex<BTreeMap<String, __PeerMeta>>> = Lazy::new(|| Mutex::new(BTreeMap::new()));

// Broadcaster senders set during startup
static TX_BCAST_SENDER: once_cell::sync::OnceCell<tokio::sync::mpsc::Sender<Tx>> = once_cell::sync::OnceCell::new();
static BLOCK_BCAST_SENDER: once_cell::sync::OnceCell<tokio::sync::mpsc::Sender<Block>> = once_cell::sync::OnceCell::new();

// Node metrics / counters used across the binary
static VISION_UNDOS_PRUNED: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_PRUNE_RUNS: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_BLOCK_WEIGHT_LAST: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_BLOCKS_MINED: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_TXS_APPLIED: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_SIDE_BLOCKS: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_REORGS: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_REORG_REJECTED: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_REORG_LENGTH_TOTAL: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_REORG_DURATION_MS: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_SNAPSHOTS: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_GOSSIP_IN: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static VISION_GOSSIP_OUT: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));
static ADMIN_PING_TOTAL: Lazy<AtomicU64> = Lazy::new(|| AtomicU64::new(0));

// Prometheus-style metrics for mempool sweeper
static PROM_VISION_MEMPOOL_SWEEPS: Lazy<IntCounter> = Lazy::new(|| mk_int_counter("vision_mempool_sweeps_total", "Total mempool sweep operations"));
static PROM_VISION_MEMPOOL_REMOVED_TOTAL: Lazy<IntCounter> = Lazy::new(|| mk_int_counter("vision_mempool_removed_total", "Total transactions removed by sweeper"));
static PROM_VISION_MEMPOOL_REMOVED_LAST: Lazy<IntGauge> = Lazy::new(|| mk_int_gauge("vision_mempool_removed_last", "Transactions removed in last sweep"));
static PROM_VISION_MEMPOOL_SWEEP_LAST_MS: Lazy<IntGauge> = Lazy::new(|| mk_int_gauge("vision_mempool_sweep_last_ms", "Duration of last sweep (ms)"));
static VISION_MEMPOOL_SWEEP_HISTORY: Lazy<Mutex<VecDeque<(u64, u64, u64, u64)>>> = Lazy::new(|| Mutex::new(VecDeque::new()));
static VISION_MEMPOOL_SWEEP_DURATION_HISTOGRAM: Lazy<Histogram> = Lazy::new(|| {
    let opts = HistogramOpts::new("vision_mempool_sweep_duration_seconds", "Mempool sweep duration (seconds)");
    Histogram::with_opts(opts).expect("create histogram")
});
static PROM_VISION_UNDOS_PRUNED: Lazy<IntCounter> = Lazy::new(|| mk_int_counter("vision_undos_pruned_total", "Total undo entries pruned"));


#[derive(serde::Serialize)]
struct PanelStatus {
    peers: Vec<String>,
    port: u16,
    height: u64,
}

async fn panel_status() -> impl IntoResponse {
    let g = CHAIN.lock();
    let peers = g.peers.iter().cloned().collect::<Vec<_>>();
    let port: u16 = std::env::var("VISION_PORT").ok().and_then(|s| s.parse().ok()).unwrap_or(7070);
    let height = g.blocks.last().map(|b| b.header.number).unwrap_or(0);
    Json(PanelStatus { peers, port, height })
}
#[inline]
#[allow(dead_code)]
fn now_secs() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs()
}

async fn livez() -> &'static str { "ok" }

async fn readyz() -> (StatusCode, Json<serde_json::Value>) {
    let g = CHAIN.lock();
    let height = g.blocks.last().map(|b| b.header.number).unwrap_or(0);
    let hash = g.blocks.last().map(|b| b.header.pow_hash.clone()).unwrap_or_default();
    let gm = g.gamemaster.clone();
    (StatusCode::OK, Json(serde_json::json!({ "gamemaster": gm, "height": height, "hash": hash })))
}

async fn peers_list() -> Json<Vec<PeerMeta>> {
    let m = PEERS.lock();
    let out: Vec<PeerMeta> = m.values().cloned().collect();
    Json(out)
}

async fn peers_summary() -> Json<serde_json::Value> {
    let m = PEERS.lock();
    let peers_len = m.len();
    let recent_ok = m.values().filter(|p| p.last_ok.is_some()).count();
    let recent_fail = m.values().filter(|p| p.fail_count > 0).count();
    Json(serde_json::json!({ "peers_len": peers_len, "recent_ok": recent_ok, "recent_fail": recent_fail }))
}

async fn peers_ping(Query(q): Query<std::collections::HashMap<String,String>>) -> Json<serde_json::Value> {
    if let Some(raw) = q.get("url") {
        let url = normalize_url(raw);
        let start = std::time::Instant::now();
        let resp = HTTP.get(format!("{}/status", url)).timeout(Duration::from_millis(500)).send().await;
        let ms = start.elapsed().as_millis() as u64;
        if let Ok(r) = resp {
            if r.status().is_success() { return Json(serde_json::json!({ "ok": true, "ms": ms })); }
        }
        return Json(serde_json::json!({ "ok": false, "ms": ms }));
    }
    Json(serde_json::json!({ "error": "missing url" }))
}

// --- small helper stubs ---
fn normalize_url(raw: &str) -> String { raw.trim_end_matches('/').to_string() }

async fn panel_config() -> Json<serde_json::Value> {
    Json(serde_json::json!({"ok":true}))
}

async fn peers_add_handler(Json(req): Json<AddPeerReq>) -> (StatusCode, Json<serde_json::Value>) {
    peers_add(&req.url);
    (StatusCode::OK, Json(serde_json::json!({"ok": true, "url": req.url})))
}

fn peers_add(u: &str) {
    let mut g = CHAIN.lock();
    if hygiene_allow_add(u) { g.peers.insert(u.to_string()); let _ = g.db.insert(format!("{}{}", PEER_PREFIX, u).as_bytes(), IVec::from(&b"1"[..])); }
}

async fn admin_ping_handler(
    headers: HeaderMap,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> (StatusCode, Json<serde_json::Value>) {
    // debug log incoming admin auth attempts
    // keep admin auth logging minimal in prod; avoid printing tokens
        if !check_admin(headers.clone(), &q) {
            return api_error_struct(StatusCode::UNAUTHORIZED, "unauthorized", "invalid or missing admin token"); }
    ADMIN_PING_TOTAL.fetch_add(1, Ordering::Relaxed);
    (StatusCode::OK, Json(serde_json::json!({"ok": true})))
}

async fn admin_info() -> (StatusCode, Json<serde_json::Value>) {
    // admin_info should be protected by check_admin at call sites; provide basic info
    let version = env::var("VISION_VERSION").unwrap_or_else(|_| "dev".into());
    (StatusCode::OK, Json(serde_json::json!({"version": version})))
}


// =================== Config / Constants ===================

// Centralized runtime limits loaded from environment (FIX21)
#[derive(Debug, Clone)]
pub struct Limits {
    pub block_weight_limit: u64,
    pub block_target_txs: usize,
    pub max_reorg: u64,
    pub mempool_max: usize,
    pub rate_submit_rps: u64,
    pub rate_gossip_rps: u64,
    pub snapshot_every_blocks: u64,
    pub target_block_time: u64,
    pub retarget_window: u64,
}

fn load_limits() -> Limits {
    Limits {
        block_weight_limit: std::env::var("VISION_BLOCK_WEIGHT_LIMIT").ok().and_then(|s| s.parse().ok()).unwrap_or(400_000),
        block_target_txs: std::env::var("VISION_BLOCK_TARGET_TXS").ok().and_then(|s| s.parse().ok()).unwrap_or(200),
    max_reorg: std::env::var("VISION_MAX_REORG_DEPTH").ok().and_then(|s| s.parse().ok()).unwrap_or(100),
        mempool_max: std::env::var("VISION_MEMPOOL_MAX").ok().and_then(|s| s.parse().ok()).unwrap_or(10_000),
        rate_submit_rps: std::env::var("VISION_RATE_SUBMIT_TX_RPS").ok().and_then(|s| s.parse().ok()).unwrap_or(8),
        rate_gossip_rps: std::env::var("VISION_RATE_GOSSIP_RPS").ok().and_then(|s| s.parse().ok()).unwrap_or(20),
        snapshot_every_blocks: std::env::var("VISION_SNAPSHOT_EVERY_BLOCKS").ok().and_then(|s| s.parse().ok()).unwrap_or(1000),
        target_block_time: std::env::var("VISION_TARGET_BLOCK_SECS").ok().and_then(|s| s.parse().ok()).unwrap_or(5),
        retarget_window: std::env::var("VISION_RETARGET_WINDOW").ok().and_then(|s| s.parse().ok()).unwrap_or(20),
    }
}

#[cfg(test)]
mod proof_tests {
    use super::*;

    #[test]
    fn balance_proof_reconstructs_root() {
        let mut g = crate::fresh_chain();
        // populate some balances
        g.balances.insert(acct_key("alice"), 100u128);
        g.balances.insert(acct_key("bob"), 200u128);
        g.balances.insert(acct_key("carol"), 50u128);
        // get proof for bob
        let proof = get_balance_proof(&g, "bob").expect("proof");
        // reconstruct root from leaf and path
        let mut cur = hex::decode(&proof.leaf).expect("leaf hex");
        for (sibling_hex, sibling_on_left) in proof.path.iter() {
            let sib = hex::decode(sibling_hex).expect("sib hex");
            let mut hasher = blake3::Hasher::new();
            if *sibling_on_left { hasher.update(&sib); hasher.update(&cur); } else { hasher.update(&cur); hasher.update(&sib); }
            let out = hasher.finalize();
            cur = out.as_bytes().to_vec();
        }
        let reconstructed = hex::encode(&cur);
        assert_eq!(reconstructed, proof.root);
    }
}

// Simple token-bucket for per-IP rate limiting
#[derive(Debug, Clone)]
struct TokenBucket {
    tokens: f64,
    capacity: f64,
    refill_per_sec: f64,
    last_ts: u64,
}
impl TokenBucket {
    fn new(capacity: f64, refill_per_sec: f64) -> Self {
        Self { tokens: capacity, capacity, refill_per_sec, last_ts: now_ts() }
    }
    fn allow(&mut self, cost: f64) -> bool {
        let now = now_ts();
        let elapsed = (now.saturating_sub(self.last_ts)) as f64;
        self.last_ts = now;
        self.tokens = (self.tokens + elapsed * self.refill_per_sec).min(self.capacity);
        if self.tokens + 1e-9 >= cost {
            self.tokens -= cost;
            true
        } else { false }
    }
}

// Per-IP token buckets
static IP_TOKEN_BUCKETS: once_cell::sync::Lazy<DashMap<String, TokenBucket>> = once_cell::sync::Lazy::new(|| DashMap::new());

static FEE_BASE: Lazy<Mutex<u128>> = Lazy::new(|| {
    Mutex::new(env::var("VISION_FEE_BASE").ok().and_then(|s| s.parse().ok()).unwrap_or(1))
});
static CHAIN: Lazy<Mutex<Chain>> = Lazy::new(|| {
    // Per-port data dir so multi-nodes on one machine don't step on each other
    let port: u16 = env::var("VISION_PORT").ok().and_then(|s| s.parse().ok()).unwrap_or(7070);
    let dir = format!("./vision_data_{}", port);
    Mutex::new(Chain::init(&dir))
});

fn fee_base() -> u128 { *FEE_BASE.lock() }
fn fee_per_recipient() -> u128 {
    env::var("VISION_FEE_PER_RECIPIENT").ok().and_then(|s| s.parse().ok()).unwrap_or(0)
}
fn miner_require_sync() -> bool {
    env::var("VISION_MINER_REQUIRE_SYNC").ok().and_then(|s| s.parse::<u64>().ok()).unwrap_or(0) != 0
}
fn miner_max_lag() -> u64 {
    env::var("VISION_MINER_MAX_LAG").ok().and_then(|s| s.parse().ok()).unwrap_or(0)
}
fn discovery_secs() -> u64 {
    std::env::var("VISION_DISCOVERY_SECS").ok().and_then(|s| s.parse().ok()).unwrap_or(15)
}
fn block_target_txs() -> usize {
    env::var("VISION_BLOCK_TARGET_TXS").ok().and_then(|s| s.parse().ok()).unwrap_or(200)
}
fn block_util_high() -> f64 {
    env::var("VISION_BLOCK_UTIL_HIGH").ok().and_then(|s| s.parse().ok()).unwrap_or(0.8)
}
fn block_util_low() -> f64 {
    env::var("VISION_BLOCK_UTIL_LOW").ok().and_then(|s| s.parse().ok()).unwrap_or(0.3)
}
// mempool max is available on Chain.limits; keep this helper marked dead
#[allow(dead_code)]
fn mempool_max() -> usize {
    env::var("VISION_MEMPOOL_MAX").ok().and_then(|s| s.parse().ok()).unwrap_or(10_000)
}
fn mempool_ttl_secs() -> u64 {
    std::env::var("VISION_MEMPOOL_TTL_SECS").ok().and_then(|s| s.parse().ok()).unwrap_or(0) // 0 = disabled
}

// sled keys/prefixes
const BAL_PREFIX: &str = "bal:";           // bal:acct:<addr> -> u128 BE
const NONCE_PREFIX: &str = "nonce:";       // nonce:acct:<addr> -> u64 BE
const BLK_PREFIX: &str = "blk:";           // blk:<height_be8> -> json(Block)
const META_HEIGHT: &str = "meta:height";   // -> u64 BE
const META_GM: &str = "meta:gamemaster";   // -> bytes (hex string)
const RCPT_PREFIX: &str = "rcpt:";         // rcpt:<tx_hash_hex> -> json(Receipt)
const PEER_PREFIX: &str = "peer:";         // peer:<url> -> b"1"

const META_FEE_BASE: &str = "meta:fee_base"; // -> u128 BE
