//! Vision Node Mining Pool Implementation
//!
//! Enables miners to host pools and workers to join pools for collaborative mining.
//! Pool hosts distribute work, track shares, and automatically split block rewards.

pub mod state;
pub mod worker;
pub mod protocol;
pub mod payouts;
pub mod routes;
pub mod worker_client;
pub mod performance;

pub use state::{PoolState, PoolConfig};
pub use worker::PoolWorker as PoolWorkerInfo;
pub use worker_client::PoolWorker;
pub use performance::{SHARE_RATE_LIMITER, JOB_CACHE, BAN_MANAGER, POOL_METRICS};
pub use protocol::{PoolJob, ShareSubmission, RegistrationRequest};
pub use payouts::compute_pool_payouts;

/// Mining mode for the node
#[derive(Clone, Copy, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum MiningMode {
    /// Solo mining (default)
    Solo,
    /// Hosting a mining pool
    HostPool,
    /// Joined as a worker to a pool
    JoinPool,
}

impl Default for MiningMode {
    fn default() -> Self {
        MiningMode::Solo
    }
}

impl MiningMode {
    pub fn as_str(&self) -> &'static str {
        match self {
            MiningMode::Solo => "solo",
            MiningMode::HostPool => "host_pool",
            MiningMode::JoinPool => "join_pool",
        }
    }
    
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "solo" => Some(MiningMode::Solo),
            "host" | "host_pool" => Some(MiningMode::HostPool),
            "join" | "join_pool" | "worker" => Some(MiningMode::JoinPool),
            _ => None,
        }
    }
}
