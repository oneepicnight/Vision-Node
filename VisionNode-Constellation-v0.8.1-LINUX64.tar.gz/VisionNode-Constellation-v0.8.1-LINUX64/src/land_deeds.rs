use sled::{Db, IVec};
use serde::{Serialize, Deserialize};
use std::fmt::Debug;

use crate::vision_constants::{META_LAND_GENESIS_DONE, LAND_DEED_PREFIX, FOUNDER_ADDRESS};

// Reverse index: "land:deed:by-owner:<addr>" => deed_id (u64 BE)
const LAND_DEED_OWNER_INDEX: &str = "land:deed:by-owner:";

pub fn genesis_land_deed_total() -> u64 {
    std::env::var("VISION_GENESIS_LAND_DEED_TOTAL")
        .ok()
        .and_then(|s| s.parse::<u64>().ok())
        .unwrap_or(1_000_000u64)
}

/// Mint genesis land deeds to FOUNDER_ADDRESS. Ids will be `1..=count`.
/// This function will ensure it only runs once by checking/setting the
/// `META_LAND_GENESIS_DONE` DB flag. Returns Ok(minted_count) or Err.
pub fn mint_genesis_deeds(db: &Db) -> Result<u64, String> {
    // If already done, no-op
    match db.get(META_LAND_GENESIS_DONE.as_bytes()) {
        Ok(Some(_)) => return Ok(0),
        Ok(None) => (),
        Err(e) => return Err(format!("db error: {}", e)),
    }
    let deeds_total = genesis_land_deed_total();
    if deeds_total == 0 {
        // ensure 0 is not allowed
        return Err("deed total cannot be 0".to_string());
    }

    for i in 1..=deeds_total {
        let key = format!("{}{}", LAND_DEED_PREFIX, i);
        // Insert owner address bytes
        if let Err(e) = db.insert(key.as_bytes(), IVec::from(FOUNDER_ADDRESS.as_bytes())) {
            return Err(format!("failed to insert deed {}: {}", i, e));
        }
        // Update owner index (only for first deed per owner to avoid duplicates)
        if i == 1 {
            let owner_key = format!("{}{}", LAND_DEED_OWNER_INDEX, FOUNDER_ADDRESS);
            let deed_id_bytes = i.to_be_bytes();
            if let Err(e) = db.insert(owner_key.as_bytes(), IVec::from(&deed_id_bytes[..])) {
                return Err(format!("failed to update owner index for deed {}: {}", i, e));
            }
        }
        if i % 100_000 == 0 && i != 0 {
            // flush periodically to disk
            let _ = db.flush();
            tracing::info!(minted = i, "genesis deeds minted so far");
        }
    }

    // Mark as done
    if let Err(e) = db.insert(META_LAND_GENESIS_DONE.as_bytes(), IVec::from(&[1u8][..])) {
        return Err(format!("failed to set genesis done flag: {}", e));
    }
    let _ = db.flush();
    Ok(deeds_total)
}

/// Check if a wallet owns at least one deed
/// 
/// For Testnet 48h v0.8.0: ALL wallets are treated as deed holders
/// for governance testing purposes
pub fn wallet_has_deed(db: &Db, addr: &str) -> bool {
    // Testnet 48h v0.8.0: Grant all wallets deed powers for governance testing
    let network = crate::network_config::NetworkType::from_env();
    if crate::network_config::is_testnet_48h_v080(network) {
        return true;
    }
    
    // Normal deed check
    let owner_key = format!("{}{}", LAND_DEED_OWNER_INDEX, addr);
    db.get(owner_key.as_bytes()).ok().flatten().is_some()
}

/// Get the deed ID owned by an address (if any)
pub fn get_owned_deed_id(db: &Db, addr: &str) -> Option<u64> {
    let owner_key = format!("{}{}", LAND_DEED_OWNER_INDEX, addr);
    if let Ok(Some(bytes)) = db.get(owner_key.as_bytes()) {
        if bytes.len() >= 8 {
            let mut arr = [0u8; 8];
            arr.copy_from_slice(&bytes[..8]);
            return Some(u64::from_be_bytes(arr));
        }
    }
    None
}

/// Get all deed-owning wallets (addresses that own at least one deed)
/// Returns Vec of address strings
pub fn all_deed_owners(db: &Db) -> Vec<String> {
    let mut owners = Vec::new();
    
    // Iterate over all keys with prefix LAND_DEED_OWNER_INDEX
    for item in db.scan_prefix(LAND_DEED_OWNER_INDEX.as_bytes()) {
        if let Ok((key, _value)) = item {
            let key_str = String::from_utf8_lossy(&key);
            // Extract address from key: "land:deed:by-owner:<addr>"
            if let Some(addr) = key_str.strip_prefix(LAND_DEED_OWNER_INDEX) {
                owners.push(addr.to_string());
            }
        }
    }
    
    owners
}

/// Update owner index when deed ownership changes
/// Call this whenever a deed is transferred
pub fn update_owner_index(db: &Db, deed_id: u64, new_owner: &str) -> Result<(), String> {
    let owner_key = format!("{}{}", LAND_DEED_OWNER_INDEX, new_owner);
    let deed_id_bytes = deed_id.to_be_bytes();
    db.insert(owner_key.as_bytes(), IVec::from(&deed_id_bytes[..]))
        .map_err(|e| format!("failed to update owner index: {}", e))?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;
    use sled::Config;

    #[test]
    #[ignore]
    fn heavy_mint_1m() {
        // WARNING: heavy test - inserts 1,000,000 deeds
        let tmp = TempDir::new().unwrap();
        let db = Config::new().temporary(true).open().unwrap();
        std::env::set_var("VISION_GENESIS_LAND_DEED_TOTAL", "1000000");
        let minted = mint_genesis_deeds(&db).expect("mint should succeed");
        assert_eq!(minted, 1_000_000);
    }

    #[test]
    fn mint_small() {
        let db = Config::new().temporary(true).open().unwrap();
        std::env::set_var("VISION_GENESIS_LAND_DEED_TOTAL", "10");
        let minted = mint_genesis_deeds(&db).expect("mint should succeed");
        assert_eq!(minted, 10);
        // verify keys exist
        for i in 1..=10u64 {
            let k = format!("{}{}", LAND_DEED_PREFIX, i);
            let val = db.get(k.as_bytes()).unwrap();
            assert!(val.is_some());
        }
        // second call should be no-op
        let minted2 = mint_genesis_deeds(&db).unwrap();
        assert_eq!(minted2, 0);
    }

    #[test]
    fn default_total_is_one_million() {
        std::env::remove_var("VISION_GENESIS_LAND_DEED_TOTAL");
        assert_eq!(genesis_land_deed_total(), 1_000_000u64);
    }
}
