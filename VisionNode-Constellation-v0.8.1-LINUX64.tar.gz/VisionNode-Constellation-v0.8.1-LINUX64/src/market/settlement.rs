use crate::receipts::{write_receipt, Receipt};
use crate::vision_constants::{VAULT_ADDRESS, FOUNDER_ADDRESS, OPS_ADDRESS};
use crate::market::engine::QuoteAsset;
use crate::market::{vault, autobuy};
use anyhow::Result;
use sled::Db;

// Credit an address with an amount (simplified - replace with your actual balance logic)
fn credit_address(db: &Db, address: &str, amount: u128) -> Result<()> {
    // Get existing balance
    let key = format!("balance:{}", address);
    let current = db
        .get(key.as_bytes())?
        .map(|v| u128::from_be_bytes(v.as_ref().try_into().unwrap_or([0u8; 16])))
        .unwrap_or(0);

    // Add amount
    let new_balance = current.saturating_add(amount);

    // Store back
    db.insert(key.as_bytes(), &new_balance.to_be_bytes())?;

    tracing::info!(
        "Credited {} with {} (new balance: {})",
        address,
        amount,
        new_balance
    );
    Ok(())
}

/// Route exchange fee using multi-currency vault system
/// Fee is charged in the quote asset and split 50/30/20
pub fn route_exchange_fee(quote: QuoteAsset, fee_amount: f64) -> Result<()> {
    // Distribute fee to multi-currency vault (50% miners, 30% dev, 20% founders)
    vault::distribute_exchange_fee(quote, fee_amount)?;
    
    // Try auto-buy for miners if balance is sufficient
    if let Err(e) = autobuy::auto_buy_for_miners_if_ready(quote) {
        tracing::warn!("Auto-buy check failed for {}: {}", quote.as_str(), e);
    }
    
    tracing::info!(
        "💰 Exchange fee routed: {} {} (50% miners, 30% dev, 20% founders)",
        fee_amount,
        quote.as_str()
    );
    
    Ok(())
}

/// Route sale proceeds according to 50/30/20 split (Vault/Fund/Treasury)
/// Legacy function for LAND-based sales
pub fn route_proceeds(db: &Db, total: u128) -> Result<()> {
    // Hard-coded 50/30/20 split for Vision chain
    let vault_amt = total * 50 / 100;
    let fund_amt = total * 30 / 100;
    let treasury_amt = total * 20 / 100;

    // For treasury, split between founder and ops (50/50)
    let founder_amt = treasury_amt / 2;
    let ops_amt = treasury_amt.saturating_sub(founder_amt);

    tracing::info!(
        "Routing {} total: vault={}, fund={}, founder={}, ops={}",
        total,
        vault_amt,
        fund_amt,
        founder_amt,
        ops_amt
    );

    // Credit accounts
    credit_address(db, VAULT_ADDRESS, vault_amt)?;
    credit_address(db, FOUNDER_ADDRESS, fund_amt)?;
    credit_address(db, FOUNDER_ADDRESS, founder_amt)?;
    credit_address(db, OPS_ADDRESS, ops_amt)?;

    // Also update the vault ledger for tracking
    let _ = crate::treasury::vault::route_inflow(
        "CASH",
        vault_amt,
        format!("market_sale_vault total={}", total),
    );
    let _ = crate::treasury::vault::route_inflow(
        "CASH",
        fund_amt,
        format!("market_sale_fund total={}", total),
    );
    let _ = crate::treasury::vault::route_inflow(
        "CASH",
        founder_amt,
        format!("market_sale_founder total={}", total),
    );
    let _ = crate::treasury::vault::route_inflow(
        "CASH",
        ops_amt,
        format!("market_sale_ops total={}", total),
    );

    // Write receipts for each distribution (best-effort, don't fail on receipt errors)
    let write_settlement_receipt = |to: &str, amount: u128, label: &str| {
        let rec = Receipt {
            id: String::new(),
            ts_ms: 0,
            kind: "market_settle".to_string(),
            from: "market_proceeds".to_string(),
            to: to.to_string(),
            amount: amount.to_string(),
            fee: "0".to_string(),
            memo: Some(format!("{} settlement from market sale", label)),
            txid: None,
            ok: true,
            note: None,
        };
        if let Err(e) = write_receipt(db, None, rec) {
            tracing::warn!("Failed to write {} settlement receipt: {}", label, e);
        }
    };

    write_settlement_receipt(VAULT_ADDRESS, vault_amt, "Vault");
    write_settlement_receipt(FOUNDER_ADDRESS, fund_amt, "Fund");
    write_settlement_receipt(FOUNDER_ADDRESS, founder_amt, "Founder");
    write_settlement_receipt(OPS_ADDRESS, ops_amt, "Ops");

    Ok(())
}
