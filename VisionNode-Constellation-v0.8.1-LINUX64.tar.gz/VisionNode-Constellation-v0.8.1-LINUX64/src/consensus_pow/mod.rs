//! Consensus PoW module for VisionX blockchain
//!
//! Provides block building, difficulty adjustment, and submission handling
//! for the VisionX proof-of-work consensus mechanism.
//!
//! Note: Renamed to consensus_pow to avoid conflict with existing consensus.rs

pub mod block_builder;
pub mod difficulty;
pub mod submit;

pub use block_builder::{BlockBuilder, BlockHeader, MineableBlock, Transaction};
pub use difficulty::{DifficultyConfig, DifficultyTracker, calculate_next_difficulty};
pub use submit::{BlockSubmitter, SubmitResult, MiningStats, RecentBlock};
