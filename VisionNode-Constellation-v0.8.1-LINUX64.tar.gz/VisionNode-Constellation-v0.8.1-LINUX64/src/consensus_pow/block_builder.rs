//! Block builder for VisionX PoW mining
//!
//! Constructs mineable block templates with proper headers and metadata.

use crate::pow::{U256, visionx::PowJob};
use serde::{Deserialize, Serialize};

/// Block header for mining
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BlockHeader {
    pub version: u32,
    pub height: u64,
    pub prev_hash: [u8; 32],
    pub timestamp: u64,
    pub difficulty: u64,
    pub nonce: u64,
    pub transactions_root: [u8; 32],
}

impl BlockHeader {
    /// Serialize header to bytes for hashing (without nonce initially)
    pub fn to_bytes_without_nonce(&self) -> Vec<u8> {
        let mut bytes = Vec::with_capacity(128);
        bytes.extend_from_slice(&self.version.to_be_bytes());
        bytes.extend_from_slice(&self.height.to_be_bytes());
        bytes.extend_from_slice(&self.prev_hash);
        bytes.extend_from_slice(&self.timestamp.to_be_bytes());
        bytes.extend_from_slice(&self.difficulty.to_be_bytes());
        bytes.extend_from_slice(&[0u8; 8]); // Placeholder for nonce
        bytes.extend_from_slice(&self.transactions_root);
        bytes
    }
    
    /// Serialize complete header with nonce
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::with_capacity(128);
        bytes.extend_from_slice(&self.version.to_be_bytes());
        bytes.extend_from_slice(&self.height.to_be_bytes());
        bytes.extend_from_slice(&self.prev_hash);
        bytes.extend_from_slice(&self.timestamp.to_be_bytes());
        bytes.extend_from_slice(&self.difficulty.to_be_bytes());
        bytes.extend_from_slice(&self.nonce.to_be_bytes());
        bytes.extend_from_slice(&self.transactions_root);
        bytes
    }
    
    /// Calculate header hash (for prev_hash of next block)
    pub fn hash(&self) -> [u8; 32] {
        let bytes = self.to_bytes();
        blake3::hash(&bytes).into()
    }
}

/// Mineable block with transactions
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct MineableBlock {
    pub header: BlockHeader,
    pub transactions: Vec<Transaction>,
}

/// Simplified transaction for block building
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Transaction {
    pub from: String,
    pub to: String,
    pub amount: u64,
    pub nonce: u64,
    pub signature: Vec<u8>,
}

impl Transaction {
    /// Calculate transaction hash
    pub fn hash(&self) -> [u8; 32] {
        let mut data = Vec::new();
        data.extend_from_slice(self.from.as_bytes());
        data.extend_from_slice(self.to.as_bytes());
        data.extend_from_slice(&self.amount.to_be_bytes());
        data.extend_from_slice(&self.nonce.to_be_bytes());
        data.extend_from_slice(&self.signature);
        blake3::hash(&data).into()
    }
}

/// Calculate Merkle root of transactions
pub fn calculate_merkle_root(transactions: &[Transaction]) -> [u8; 32] {
    if transactions.is_empty() {
        return [0u8; 32];
    }
    
    let mut hashes: Vec<[u8; 32]> = transactions.iter().map(|tx| tx.hash()).collect();
    
    while hashes.len() > 1 {
        let mut next_level = Vec::new();
        
        for chunk in hashes.chunks(2) {
            let mut data = Vec::new();
            data.extend_from_slice(&chunk[0]);
            if chunk.len() > 1 {
                data.extend_from_slice(&chunk[1]);
            } else {
                data.extend_from_slice(&chunk[0]); // Duplicate last hash if odd
            }
            next_level.push(blake3::hash(&data).into());
        }
        
        hashes = next_level;
    }
    
    hashes[0]
}

/// Block builder for creating mineable templates
pub struct BlockBuilder {
    version: u32,
}

impl BlockBuilder {
    pub fn new() -> Self {
        Self { version: 1 }
    }
    
    /// Build a new mineable block
    pub fn build_block(
        &self,
        height: u64,
        prev_hash: [u8; 32],
        difficulty: u64,
        transactions: Vec<Transaction>,
    ) -> MineableBlock {
        let timestamp = crate::consensus_pow::difficulty::current_timestamp();
        let transactions_root = calculate_merkle_root(&transactions);
        
        let header = BlockHeader {
            version: self.version,
            height,
            prev_hash,
            timestamp,
            difficulty,
            nonce: 0, // Will be filled by miner
            transactions_root,
        };
        
        MineableBlock {
            header,
            transactions,
        }
    }
    
    /// Create PowJob from mineable block for mining
    pub fn create_pow_job(
        &self,
        block: &MineableBlock,
        target: U256,
    ) -> PowJob {
        let header_bytes = block.header.to_bytes_without_nonce();
        
        // Nonce offset: version(4) + height(8) + prev_hash(32) + timestamp(8) + difficulty(8) = 60
        let nonce_offset = 4 + 8 + 32 + 8 + 8;
        
        PowJob {
            header: header_bytes,
            nonce_offset,
            target,
            prev_hash32: block.header.prev_hash,
            height: block.header.height,
        }
    }
    
    /// Finalize block with found nonce
    pub fn finalize_block(
        &self,
        mut block: MineableBlock,
        nonce: u64,
    ) -> MineableBlock {
        block.header.nonce = nonce;
        block
    }
}

impl Default for BlockBuilder {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_merkle_root_single_tx() {
        let tx = Transaction {
            from: "alice".to_string(),
            to: "bob".to_string(),
            amount: 100,
            nonce: 1,
            signature: vec![1, 2, 3],
        };
        
        let root = calculate_merkle_root(&[tx.clone()]);
        assert_eq!(root, tx.hash());
    }
    
    #[test]
    fn test_merkle_root_multiple_tx() {
        let txs = vec![
            Transaction {
                from: "alice".to_string(),
                to: "bob".to_string(),
                amount: 100,
                nonce: 1,
                signature: vec![1, 2, 3],
            },
            Transaction {
                from: "bob".to_string(),
                to: "charlie".to_string(),
                amount: 50,
                nonce: 2,
                signature: vec![4, 5, 6],
            },
        ];
        
        let root = calculate_merkle_root(&txs);
        assert_ne!(root, [0u8; 32]);
    }
    
    #[test]
    fn test_block_builder() {
        let builder = BlockBuilder::new();
        let prev_hash = [1u8; 32];
        let txs = vec![
            Transaction {
                from: "alice".to_string(),
                to: "bob".to_string(),
                amount: 100,
                nonce: 1,
                signature: vec![1, 2, 3],
            },
        ];
        
        let block = builder.build_block(1, prev_hash, 10000, txs.clone());
        
        assert_eq!(block.header.height, 1);
        assert_eq!(block.header.prev_hash, prev_hash);
        assert_eq!(block.header.difficulty, 10000);
        assert_eq!(block.transactions.len(), 1);
    }
    
    #[test]
    fn test_pow_job_creation() {
        let builder = BlockBuilder::new();
        let prev_hash = [2u8; 32];
        let block = builder.build_block(2, prev_hash, 5000, vec![]);
        
        let target = crate::pow::u256_from_difficulty(5000);
        let job = builder.create_pow_job(&block, target);
        
        assert_eq!(job.height, 2);
        assert_eq!(job.prev_hash32, prev_hash);
        assert_eq!(job.target, target);
        assert_eq!(job.nonce_offset, 60);
    }
    
    #[test]
    fn test_block_finalization() {
        let builder = BlockBuilder::new();
        let block = builder.build_block(3, [3u8; 32], 1000, vec![]);
        
        let finalized = builder.finalize_block(block.clone(), 123456);
        
        assert_eq!(finalized.header.nonce, 123456);
        assert_eq!(finalized.header.height, block.header.height);
    }
    
    #[test]
    fn test_header_hash() {
        let header = BlockHeader {
            version: 1,
            height: 1,
            prev_hash: [0u8; 32],
            timestamp: 1000,
            difficulty: 5000,
            nonce: 12345,
            transactions_root: [1u8; 32],
        };
        
        let hash1 = header.hash();
        let hash2 = header.hash();
        
        // Same header should produce same hash
        assert_eq!(hash1, hash2);
        
        // Hash should not be zero
        assert_ne!(hash1, [0u8; 32]);
    }
}
