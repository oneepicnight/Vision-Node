//! Constellation Beacon - Guardian's network heartbeat broadcaster
//!
//! The Constellation Beacon is the Guardian's radio tower - broadcasting heartbeats
//! to tell all nodes in the network that the beacon is alive and operational.
//!
//! **Guardian Nodes**: Run beacon in ACTIVE mode, broadcasting heartbeats
//! **Constellation Nodes**: Connect to beacon endpoint for network discovery
//!
//! Environment Variables:
//! - BEACON_PORT: Port for beacon HTTP endpoint (default: 7070, same as main API)
//! - BEACON_INTERVAL_SECS: Seconds between heartbeat broadcasts (default: 30)
//! - BEACON_ENABLED: Set to "false" to disable beacon (Guardian always overrides to true)
//! - BEACON_MODE: "active" (broadcast) or "passive" (receive only) - Guardian forces "active"

use once_cell::sync::OnceCell;
use serde::{Deserialize, Serialize};
use std::net::{SocketAddr, UdpSocket};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use tokio::time::sleep;
use tracing::{error, info, warn};

/// Global beacon instance
static BEACON: OnceCell<Arc<ConstellationBeacon>> = OnceCell::new();

/// Beacon operational mode
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum BeaconMode {
    /// Active broadcasting - Guardian nodes only
    Active,
    /// Passive listening - Constellation nodes
    Passive,
}

impl BeaconMode {
    pub fn from_env() -> Self {
        match std::env::var("BEACON_MODE").ok().as_deref() {
            Some("passive") => Self::Passive,
            _ => {
                // Default to active if Guardian, passive otherwise
                if crate::is_guardian_mode() {
                    Self::Active
                } else {
                    Self::Passive
                }
            }
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Active => "active",
            Self::Passive => "passive",
        }
    }
}

/// Beacon heartbeat packet (sent over UDP)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BeaconHeartbeat {
    /// Guardian node ID
    pub node_id: String,
    /// Network identifier
    pub network: String,
    /// Current block height
    pub height: u64,
    /// Number of active peers
    pub peer_count: usize,
    /// Unix timestamp
    pub timestamp: u64,
    /// Beacon version
    pub version: String,
}

/// Constellation Beacon - The Guardian's heartbeat broadcaster
pub struct ConstellationBeacon {
    /// Node identifier
    node_id: String,
    /// Beacon mode (active/passive)
    mode: BeaconMode,
    /// Beacon start time
    start_time: Instant,
    /// Total heartbeats broadcast
    heartbeat_count: AtomicU64,
    /// Running flag
    running: AtomicBool,
    /// Broadcast interval (seconds)
    interval_secs: u64,
}

impl ConstellationBeacon {
    /// Create a new beacon instance
    pub fn new(node_id: String) -> Self {
        let mode = BeaconMode::from_env();
        let interval_secs = std::env::var("BEACON_INTERVAL_SECS")
            .ok()
            .and_then(|s| s.parse::<u64>().ok())
            .unwrap_or(30); // Default: 30 seconds

        Self {
            node_id,
            mode,
            start_time: Instant::now(),
            heartbeat_count: AtomicU64::new(0),
            running: AtomicBool::new(false),
            interval_secs,
        }
    }

    /// Get beacon mode
    pub fn mode(&self) -> BeaconMode {
        self.mode
    }

    /// Get beacon uptime
    pub fn uptime(&self) -> Duration {
        self.start_time.elapsed()
    }

    /// Get total heartbeats sent
    pub fn heartbeat_count(&self) -> u64 {
        self.heartbeat_count.load(Ordering::Relaxed)
    }

    /// Check if beacon is running
    pub fn is_running(&self) -> bool {
        self.running.load(Ordering::Relaxed)
    }

    /// Start the beacon (spawns background task)
    pub fn start(&self) {
        if self.running.swap(true, Ordering::SeqCst) {
            warn!("[BEACON] Already running");
            return;
        }

        match self.mode {
            BeaconMode::Active => {
                info!(
                    "[BEACON] Starting in ACTIVE mode - broadcasting every {} seconds",
                    self.interval_secs
                );
                self.start_active_beacon();
            }
            BeaconMode::Passive => {
                info!("[BEACON] Running in PASSIVE mode - no broadcasting");
            }
        }
    }

    /// Stop the beacon
    pub fn stop(&self) {
        if self.running.swap(false, Ordering::SeqCst) {
            info!("[BEACON] Stopped");
        }
    }

    /// Start active beacon broadcasting (Guardian mode)
    fn start_active_beacon(&self) {
        let node_id = self.node_id.clone();
        let interval = self.interval_secs;
        
        // Get references to the atomic counters (they're already behind Arc in the global)
        // We'll access them via the global BEACON instance
        let beacon_node_id = node_id.clone();

        tokio::spawn(async move {
            info!("[BEACON] Active broadcast loop started");

            // Get broadcast address from env or use default
            let broadcast_addr = std::env::var("BEACON_BROADCAST_ADDR")
                .unwrap_or_else(|_| "255.255.255.255:7071".to_string());

            // Create UDP socket for broadcasting
            let socket = match UdpSocket::bind("0.0.0.0:0") {
                Ok(s) => {
                    if let Err(e) = s.set_broadcast(true) {
                        error!("[BEACON] Failed to enable broadcast: {}", e);
                        if let Some(b) = BEACON.get() {
                            b.running.store(false, Ordering::SeqCst);
                        }
                        return;
                    }
                    info!("[BEACON] UDP broadcast socket bound");
                    s
                }
                Err(e) => {
                    error!("[BEACON] Failed to bind UDP socket: {}", e);
                    if let Some(b) = BEACON.get() {
                        b.running.store(false, Ordering::SeqCst);
                    }
                    return;
                }
            };

            loop {
                // Check if still running via global beacon
                if let Some(b) = BEACON.get() {
                    if !b.running.load(Ordering::Relaxed) {
                        break;
                    }
                } else {
                    break;
                }
                // Build heartbeat packet
                let heartbeat = BeaconHeartbeat {
                    node_id: beacon_node_id.clone(),
                    network: crate::network_config::NetworkType::from_env().as_str().to_string(),
                    height: {
                        let chain = crate::CHAIN.lock();
                        chain.blocks.len() as u64
                    },
                    peer_count: {
                        let chain = crate::CHAIN.lock();
                        chain.peers.len()
                    },
                    timestamp: SystemTime::now()
                        .duration_since(UNIX_EPOCH)
                        .unwrap()
                        .as_secs(),
                    version: env!("CARGO_PKG_VERSION").to_string(),
                };

                // Serialize and broadcast
                match serde_json::to_vec(&heartbeat) {
                    Ok(data) => {
                        match socket.send_to(&data, &broadcast_addr) {
                            Ok(sent) => {
                                if let Some(b) = BEACON.get() {
                                    let count = b.heartbeat_count.fetch_add(1, Ordering::Relaxed) + 1;
                                    info!(
                                        "[BEACON] Broadcasting active | Heartbeat #{} | Height: {} | Peers: {} | {} bytes sent",
                                        count,
                                        heartbeat.height,
                                        heartbeat.peer_count,
                                        sent
                                    );
                                }
                            }
                            Err(e) => {
                                error!("[BEACON] Failed to send heartbeat: {}", e);
                            }
                        }
                    }
                    Err(e) => {
                        error!("[BEACON] Failed to serialize heartbeat: {}", e);
                    }
                }

                // Wait for next interval
                sleep(Duration::from_secs(interval)).await;
            }

            info!("[BEACON] Broadcast loop stopped");
        });
    }
}

/// Initialize the global beacon
pub fn init_beacon(node_id: String) {
    let beacon = Arc::new(ConstellationBeacon::new(node_id));
    
    if BEACON.set(beacon.clone()).is_err() {
        warn!("[BEACON] Already initialized");
        return;
    }

    info!(
        "[BEACON] Initialized | Mode: {} | Node: {}",
        beacon.mode().as_str(),
        beacon.node_id
    );
}

/// Get the global beacon instance
pub fn beacon() -> &'static Arc<ConstellationBeacon> {
    BEACON.get().expect("Beacon not initialized - call init_beacon() first")
}

/// Beacon status for API responses
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BeaconStatus {
    pub enabled: bool,
    pub mode: String,
    pub running: bool,
    pub uptime_secs: u64,
    pub heartbeat_count: u64,
    pub interval_secs: u64,
}

/// Get beacon status for API
pub fn get_beacon_status() -> BeaconStatus {
    if let Some(b) = BEACON.get() {
        BeaconStatus {
            enabled: true,
            mode: b.mode().as_str().to_string(),
            running: b.is_running(),
            uptime_secs: b.uptime().as_secs(),
            heartbeat_count: b.heartbeat_count(),
            interval_secs: b.interval_secs,
        }
    } else {
        BeaconStatus {
            enabled: false,
            mode: "disabled".to_string(),
            running: false,
            uptime_secs: 0,
            heartbeat_count: 0,
            interval_secs: 0,
        }
    }
}

/// Check beacon configuration on node boot
pub fn check_beacon_config() {
    let is_guardian = crate::is_guardian_mode();
    
    // Check if BEACON_ENDPOINT is configured for constellation nodes
    if !is_guardian {
        match std::env::var("BEACON_ENDPOINT") {
            Ok(endpoint) => {
                info!("[NETWORK] Connecting to beacon at: {}", endpoint);
            }
            Err(_) => {
                warn!("[WARNING] No beacon configured — node running blind.");
                warn!("[WARNING] Set BEACON_ENDPOINT environment variable to connect to Guardian beacon");
                warn!("[WARNING] Example: BEACON_ENDPOINT=http://<guardian-ip>:7070");
            }
        }
    }
    
    // Guardian nodes should always have beacon enabled
    if is_guardian {
        let mode = BeaconMode::from_env();
        if mode != BeaconMode::Active {
            error!("[BEACON] Guardian mode requires ACTIVE beacon mode!");
            error!("[BEACON] Forcing beacon mode to ACTIVE");
            std::env::set_var("BEACON_MODE", "active");
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_beacon_mode() {
        // Test default mode detection
        std::env::remove_var("BEACON_MODE");
        std::env::remove_var("VISION_GUARDIAN_MODE");
        
        let mode = BeaconMode::from_env();
        assert_eq!(mode, BeaconMode::Passive);
    }

    #[test]
    fn test_beacon_creation() {
        let beacon = ConstellationBeacon::new("test-node-123".to_string());
        assert!(!beacon.is_running());
        assert_eq!(beacon.heartbeat_count(), 0);
    }
}
