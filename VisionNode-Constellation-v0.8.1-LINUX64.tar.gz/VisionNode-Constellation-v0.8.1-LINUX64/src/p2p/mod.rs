//! P2P Block Synchronization Module
//!
//! Implements headers-first sync with pipelined block fetching
//!
//! Phase 2 Extensions:
//! - Compact blocks (BIP-152 style)
//! - INV/GETDATA transaction relay
//! - Mempool synchronization
//! - Reorg handling

pub mod protocol;
pub mod sync;
pub mod orphans;
pub mod routes;
pub mod p2p_config;

// Phase 2 modules
pub mod compact;
pub mod tx_relay;
pub mod mempool_sync;
pub mod reorg;

// Phase 3: TCP P2P with persistent connections
pub mod connection;

// Bootstrap module for dynamic peer discovery
pub mod bootstrap;

// Test utilities for isolated unit testing
#[cfg(test)]
pub mod test_utils;

pub use protocol::*;
pub use sync::*;
pub use orphans::*;
pub use connection::P2PConnectionManager;
pub use p2p_config::*;
pub use bootstrap::{fetch_bootstrap_info, fetch_bootstrap_peers, BootstrapResponse};
