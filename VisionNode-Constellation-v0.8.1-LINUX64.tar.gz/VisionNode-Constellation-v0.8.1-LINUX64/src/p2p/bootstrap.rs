//! Bootstrap Module
//!
//! Fetches dynamic seed peers and network information from a central bootstrap endpoint.
//! This allows nodes to discover peers without hardcoding addresses, while keeping
//! consensus logic completely independent.

use serde::Deserialize;
use tracing::{info, warn};

/// Response from the bootstrap endpoint
#[derive(Debug, Deserialize)]
pub struct BootstrapResponse {
    /// Network identifier (e.g., "testnet", "mainnet")
    pub network: String,
    /// Welcome message to display to users
    #[serde(default)]
    pub welcome_message: Option<String>,
    /// Minimum supported node version
    #[serde(default)]
    pub min_version: Option<String>,
    /// Recommended node version
    #[serde(default)]
    pub recommended_version: Option<String>,
    /// List of seed peer addresses in "host:port" format
    pub seed_peers: Vec<String>,
}

/// Fetch bootstrap information from the specified URL
///
/// # Arguments
/// * `url` - Bootstrap endpoint URL (e.g., "https://visionworld.tech/api/bootstrap")
///
/// # Returns
/// * `Ok(BootstrapResponse)` - Successfully fetched bootstrap info
/// * `Err(String)` - Error message if fetch failed
pub async fn fetch_bootstrap_info(url: &str) -> Result<BootstrapResponse, String> {
    info!(url = url, "Fetching bootstrap information");
    
    // Create a client with timeout to avoid hanging
    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(10))
        .build()
        .map_err(|e| format!("Failed to create HTTP client: {}", e))?;
    
    // Fetch the bootstrap endpoint
    let response = client
        .get(url)
        .send()
        .await
        .map_err(|e| format!("Failed to fetch bootstrap endpoint: {}", e))?;
    
    // Check status code
    if !response.status().is_success() {
        return Err(format!(
            "Bootstrap endpoint returned status {}",
            response.status()
        ));
    }
    
    // Parse JSON response
    let bytes = response
        .bytes()
        .await
        .map_err(|e| format!("Failed to read response body: {}", e))?;
    
    let info: BootstrapResponse = serde_json::from_slice(&bytes)
        .map_err(|e| format!("Failed to parse bootstrap JSON: {}", e))?;
    
    // Log welcome message if present
    if let Some(ref msg) = info.welcome_message {
        info!(message = %msg, "Bootstrap welcome message");
    }
    
    // Log version information if present
    if let Some(ref min_ver) = info.min_version {
        info!(min_version = %min_ver, "Minimum supported version from bootstrap");
    }
    if let Some(ref rec_ver) = info.recommended_version {
        info!(recommended_version = %rec_ver, "Recommended node version from bootstrap");
    }
    
    info!(
        network = %info.network,
        seed_count = info.seed_peers.len(),
        "Successfully fetched bootstrap information"
    );
    
    Ok(info)
}

/// Fetch bootstrap peers with fallback to empty list on error
///
/// This is a convenience wrapper that logs errors but doesn't fail the node startup
/// if the bootstrap endpoint is unavailable.
pub async fn fetch_bootstrap_peers(url: &str) -> Vec<String> {
    match fetch_bootstrap_info(url).await {
        Ok(info) => {
            info!(count = info.seed_peers.len(), "Fetched bootstrap peers");
            info.seed_peers
        }
        Err(e) => {
            warn!(error = %e, "Failed to fetch bootstrap peers, continuing with static configuration");
            Vec::new()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_bootstrap_response_deserialization() {
        let json = r#"{
            "network": "testnet",
            "welcome_message": "Welcome to Vision World, Dreamer...",
            "min_version": "0.7.0",
            "recommended_version": "0.7.9",
            "seed_peers": ["1.2.3.4:7070", "5.6.7.8:7070"]
        }"#;
        
        let response: BootstrapResponse = serde_json::from_str(json).unwrap();
        assert_eq!(response.network, "testnet");
        assert_eq!(response.welcome_message.unwrap(), "Welcome to Vision World, Dreamer...");
        assert_eq!(response.seed_peers.len(), 2);
    }

    #[tokio::test]
    async fn test_bootstrap_response_minimal() {
        let json = r#"{
            "network": "mainnet",
            "seed_peers": []
        }"#;
        
        let response: BootstrapResponse = serde_json::from_str(json).unwrap();
        assert_eq!(response.network, "mainnet");
        assert!(response.welcome_message.is_none());
        assert!(response.seed_peers.is_empty());
    }
}
