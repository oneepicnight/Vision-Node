//! TCP P2P connection management with persistent bidirectional connections
//!
//! This module implements a proper P2P network layer where:
//! - Each peer has a persistent TCP connection (not HTTP request/response)
//! - Connections are bidirectional (both nodes can send/receive on same socket)
//! - Messages are length-prefixed for streaming
//! - Handshake establishes peer identity and chain height
//! - Connection failures automatically cleanup and remove dead peers

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::Mutex;
use tracing::{debug, error, info, warn};

/// P2P protocol version - MUST match between nodes
#[cfg(feature = "full")]
const P2P_PROTOCOL_VERSION: u32 = crate::vision_constants::PROTOCOL_VERSION_FULL;
#[cfg(not(feature = "full"))]
const P2P_PROTOCOL_VERSION: u32 = crate::vision_constants::PROTOCOL_VERSION_LITE;

/// Maximum handshake message size (10KB should be plenty)
const MAX_HANDSHAKE_SIZE: u32 = 10_000;

/// Handshake message - sent first on connection (uses bincode for compact binary)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HandshakeMessage {
    pub protocol_version: u32,    // Must be 1
    pub chain_id: [u8; 32],       // Chain identifier hash
    pub genesis_hash: [u8; 32],   // Genesis block hash (must match)
    pub node_nonce: u64,          // Random nonce to detect self-connections
    pub chain_height: u64,        // Current blockchain height
    pub node_version: u32,        // Software version (0.1.0 = 100)
}

/// P2P message types sent over TCP (uses JSON for flexibility)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum P2PMessage {
    /// Initial handshake when connection established (DEPRECATED - use HandshakeMessage)
    Handshake {
        protocol_version: u32,
        chain_id: String,
        genesis_hash: String,
        chain_height: u64,
        peer_id: String,
        node_version: String,
    },
    /// Ping for keepalive
    Ping {
        timestamp: u64,
    },
    /// Pong response
    Pong {
        timestamp: u64,
    },
    /// Compact block announcement
    CompactBlock {
        compact: super::compact::CompactBlock,
    },
    /// Full block (fallback if compact reconstruction fails)
    FullBlock {
        block: crate::Block,
    },
    /// Transaction relay
    Transaction {
        tx: crate::Tx,
    },
    /// Request blocks by height range
    GetBlocks {
        start_height: u64,
        end_height: u64,
    },
    /// Disconnect notification
    Disconnect {
        reason: String,
    },
    /// Peer list exchange for discovery
    PeerList {
        peers: Vec<String>,
    },
    /// Request peer list from peer
    GetPeers,
}

/// Direction of peer connection
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConnectionDirection {
    Inbound,  // Peer connected to us
    Outbound, // We connected to peer
}

/// Active peer connection with TCP stream
pub struct PeerConnection {
    /// Peer address (host:port)
    pub address: String,
    /// Peer's reported chain height
    pub height: u64,
    /// Peer identifier (public key or node ID)
    pub peer_id: String,
    /// Connection direction
    pub direction: ConnectionDirection,
    /// Last activity timestamp
    pub last_activity: Instant,
    /// TCP write half (for sending messages)
    writer: Arc<Mutex<tokio::io::WriteHalf<TcpStream>>>,
}

impl PeerConnection {
    /// Send a message to this peer
    pub async fn send_message(&self, msg: P2PMessage) -> Result<(), String> {
        // Serialize message
        let data = serde_json::to_vec(&msg)
            .map_err(|e| format!("Failed to serialize message: {}", e))?;
        
        // Length-prefixed format: [4 bytes length][message data]
        let len = data.len() as u32;
        let len_bytes = len.to_be_bytes();
        
        // Write to stream
        let mut writer = self.writer.lock().await;
        writer.write_all(&len_bytes).await
            .map_err(|e| format!("Failed to write length: {}", e))?;
        writer.write_all(&data).await
            .map_err(|e| format!("Failed to write message: {}", e))?;
        writer.flush().await
            .map_err(|e| format!("Failed to flush: {}", e))?;
        
        Ok(())
    }
}

/// Global P2P connection manager
pub struct P2PConnectionManager {
    /// Active peer connections indexed by address
    peers: Arc<Mutex<HashMap<String, Arc<Mutex<PeerConnection>>>>>,
    /// Our node's peer ID
    node_id: String,
}

impl HandshakeMessage {
    /// Create handshake message from local chain state
    fn new() -> Result<Self, String> {
        let g = crate::CHAIN.lock();
        if g.blocks.is_empty() {
            return Err("No genesis block".to_string());
        }
        
        let genesis_hash_str = g.blocks[0].header.pow_hash.clone();
        drop(g);
        
        // Parse genesis hash from hex string to [u8; 32]
        let genesis_bytes = hex::decode(&genesis_hash_str)
            .map_err(|e| format!("Invalid genesis hash: {}", e))?;
        if genesis_bytes.len() != 32 {
            return Err(format!("Genesis hash wrong length: {}", genesis_bytes.len()));
        }
        let mut genesis_hash = [0u8; 32];
        genesis_hash.copy_from_slice(&genesis_bytes);
        
        // Create chain ID string using configured network
        let chain_id_str = crate::vision_constants::Network::from_env().as_str();
        let mut chain_id = [0u8; 32];
        let chain_bytes = blake3::hash(chain_id_str.as_bytes());
        chain_id.copy_from_slice(chain_bytes.as_bytes());
        
        let g = crate::CHAIN.lock();
        let chain_height = g.blocks.len() as u64;
        drop(g);
        
        // Generate random nonce
        let node_nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos() as u64;
        
        Ok(HandshakeMessage {
            protocol_version: P2P_PROTOCOL_VERSION,
            chain_id,
            genesis_hash,
            node_nonce,
            chain_height,
            node_version: 100, // 0.1.0 = version 100
        })
    }
    
    /// Validate this handshake against our local chain
    fn validate(&self) -> Result<(), String> {
        // Check protocol version
        if self.protocol_version != P2P_PROTOCOL_VERSION {
            return Err(format!(
                "Handshake failed: protocol mismatch local={} remote={}",
                P2P_PROTOCOL_VERSION, self.protocol_version
            ));
        }
        
        // Check chain ID matches configured network
        let expected_chain_id_str = crate::vision_constants::Network::from_env().as_str();
        let mut expected_chain_id = [0u8; 32];
        let chain_bytes = blake3::hash(expected_chain_id_str.as_bytes());
        expected_chain_id.copy_from_slice(chain_bytes.as_bytes());
        
        if self.chain_id != expected_chain_id {
            return Err(format!(
                "Handshake failed: chain ID mismatch (local={} remote={})",
                hex::encode(expected_chain_id),
                hex::encode(self.chain_id)
            ));
        }
        
        // Check genesis hash
        let g = crate::CHAIN.lock();
        if g.blocks.is_empty() {
            return Err("No genesis block in local chain".to_string());
        }
        let our_genesis_str = g.blocks[0].header.pow_hash.clone();
        drop(g);
        
        let our_genesis_bytes = hex::decode(&our_genesis_str)
            .map_err(|e| format!("Invalid local genesis hash: {}", e))?;
        if our_genesis_bytes.len() != 32 {
            return Err("Local genesis hash wrong length".to_string());
        }
        let mut our_genesis = [0u8; 32];
        our_genesis.copy_from_slice(&our_genesis_bytes);
        
        if self.genesis_hash != our_genesis {
            return Err(format!(
                "Handshake failed: genesis mismatch (local={} remote={})",
                hex::encode(our_genesis),
                hex::encode(self.genesis_hash)
            ));
        }

        // Enforce expected genesis hashes by build variant.
        // Lite builds should only use the testnet genesis hash, and Full builds
        // should only use the mainnet genesis hash (to avoid cross-network mixing).
        #[cfg(feature = "lite")]
        {
            let allowed_hex = crate::vision_constants::allowed_genesis_testnet();
            if !allowed_hex.is_empty() && allowed_hex != "<to be filled>" {
                if let Ok(bytes) = hex::decode(&allowed_hex) {
                    if bytes.len() == 32 && bytes != our_genesis_bytes {
                        return Err(format!("Handshake failed: this lite node only allows testnet genesis (expected {} got {})", allowed_hex, hex::encode(our_genesis)));                    }
                }
            }
        }
        #[cfg(feature = "full")]
        {
            let allowed_hex = crate::vision_constants::allowed_genesis_mainnet();
            if !allowed_hex.is_empty() && allowed_hex != "<to be filled>" {
                if let Ok(bytes) = hex::decode(&allowed_hex) {
                    if bytes.len() == 32 && bytes != our_genesis_bytes {
                        return Err(format!("Handshake failed: this full node only allows mainnet genesis (expected {} got {})", allowed_hex, hex::encode(our_genesis)));                    }
                }
            }
        }
        
        info!(
            protocol_version = self.protocol_version,
            chain_height = self.chain_height,
            node_version = self.node_version,
            "Handshake validation successful"
        );
        
        Ok(())
    }
    
    /// Serialize handshake to bytes using bincode
    fn serialize(&self) -> Result<Vec<u8>, String> {
        bincode::serialize(self)
            .map_err(|e| format!("Failed to serialize handshake: {}", e))
    }
    
    /// Deserialize handshake from bytes using bincode
    fn deserialize(data: &[u8]) -> Result<Self, String> {
        bincode::deserialize(data)
            .map_err(|e| format!("Failed to deserialize handshake: {}", e))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::CHAIN;
    use std::sync::Arc;
    use hex;

    #[tokio::test]
    async fn handshake_rejects_different_genesis() {
        // Mutate global CHAIN genesis to a known value
        {
            let mut g = CHAIN.lock();
            if g.blocks.is_empty() {
                // Should not happen in this test harness, but bail if it does
                panic!("chain uninitialized");
            }
            g.blocks[0].header.pow_hash = "aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000".to_string();
        }

        // Create handshake with a different genesis
        let genesis_bytes = hex::decode("bbbb0000bbbb0000bbbb0000bbbb0000bbbb0000bbbb0000bbbb0000bbbb0000").unwrap();
        let mut gh = [0u8; 32];
        gh.copy_from_slice(&genesis_bytes);
        let h = HandshakeMessage {
            protocol_version: P2P_PROTOCOL_VERSION,
            chain_id: [0u8; 32],
            genesis_hash: gh,
            node_nonce: 1234,
            chain_height: 1,
            node_version: 100,
        };
        let res = h.validate();
        assert!(res.is_err());
    }

    #[tokio::test]
    async fn handshake_allowed_genesis_ok() {
        // Ensure when genesis matches allowed value (if set), validate passes
        let allowed_hex = crate::vision_constants::allowed_genesis_testnet();
        // If allowed_hex is placeholder, skip this runtime check
        if allowed_hex.is_empty() {
            return;
        }
        // Mutate local chain to use the allowed genesis
        {
            let mut g = CHAIN.lock();
            g.blocks[0].header.pow_hash = allowed_hex.to_string();
        }
        // Create handshake with the same genesis
        let genesis_bytes = hex::decode(&allowed_hex).unwrap();
        let mut gh = [0u8; 32];
        gh.copy_from_slice(&genesis_bytes);
        let h = HandshakeMessage {
            protocol_version: P2P_PROTOCOL_VERSION,
            chain_id: [0u8; 32],
            genesis_hash: gh,
            node_nonce: 5678,
            chain_height: 1,
            node_version: 100,
        };
        let res = h.validate();
        assert!(res.is_ok());
    }

    #[tokio::test]
    async fn handshake_allowed_mainnet_genesis_ok() {
        let allowed_hex = crate::vision_constants::allowed_genesis_mainnet();
        if allowed_hex.is_empty() {
            return;
        }
        {
            let mut g = CHAIN.lock();
            g.blocks[0].header.pow_hash = allowed_hex.to_string();
        }
        let genesis_bytes = hex::decode(&allowed_hex).unwrap();
        let mut gh = [0u8; 32];
        gh.copy_from_slice(&genesis_bytes);
        let h = HandshakeMessage {
            protocol_version: P2P_PROTOCOL_VERSION,
            chain_id: [0u8; 32],
            genesis_hash: gh,
            node_nonce: 56789,
            chain_height: 1,
            node_version: 100,
        };
        let res = h.validate();
        assert!(res.is_ok());
    }

    #[tokio::test]
    async fn handshake_env_override_testnet_ok() {
        // Set the env override for allowed testnet genesis
        std::env::set_var("VISION_GENESIS_HASH_TESTNET", "aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000");
        let allowed_hex = crate::vision_constants::allowed_genesis_testnet();
        // Mutate local chain to use the allowed genesis
        {
            let mut g = CHAIN.lock();
            g.blocks[0].header.pow_hash = allowed_hex.clone();
        }
        // Create handshake with the same genesis
        let genesis_bytes = hex::decode(&allowed_hex).unwrap();
        let mut gh = [0u8; 32];
        gh.copy_from_slice(&genesis_bytes);
        let h = HandshakeMessage {
            protocol_version: P2P_PROTOCOL_VERSION,
            chain_id: [0u8; 32],
            genesis_hash: gh,
            node_nonce: 9876,
            chain_height: 1,
            node_version: 100,
        };
        let res = h.validate();
        assert!(res.is_ok());
        std::env::remove_var("VISION_GENESIS_HASH_TESTNET");
    }

    #[tokio::test]
    async fn handshake_env_override_mainnet_ok() {
        std::env::set_var("VISION_GENESIS_HASH_MAINNET", "bbbb0000bbbb0000bbbb0000bbbb0000bbbb0000bbbb0000bbbb0000bbbb0000");
        let allowed_hex = crate::vision_constants::allowed_genesis_mainnet();
        {
            let mut g = CHAIN.lock();
            g.blocks[0].header.pow_hash = allowed_hex.clone();
        }
        let genesis_bytes = hex::decode(&allowed_hex).unwrap();
        let mut gh = [0u8; 32];
        gh.copy_from_slice(&genesis_bytes);
        let h = HandshakeMessage {
            protocol_version: P2P_PROTOCOL_VERSION,
            chain_id: [0u8; 32],
            genesis_hash: gh,
            node_nonce: 98765,
            chain_height: 1,
            node_version: 100,
        };
        let res = h.validate();
        assert!(res.is_ok());
        std::env::remove_var("VISION_GENESIS_HASH_MAINNET");
    }
}

impl P2PConnectionManager {
    /// Create new connection manager
    pub fn new(node_id: String) -> Self {
        Self {
            peers: Arc::new(Mutex::new(HashMap::new())),
            node_id,
        }
    }
    
    /// Get our node ID
    pub fn get_node_id(&self) -> &str {
        &self.node_id
    }
    
    /// Get list of connected peer addresses
    pub async fn get_peer_addresses(&self) -> Vec<String> {
        let peers = self.peers.lock().await;
        peers.keys().cloned().collect()
    }
    
    /// Get peer connection info for API
    pub async fn get_peer_info(&self) -> Vec<PeerInfo> {
        let peers = self.peers.lock().await;
        let mut info = Vec::new();
        
        for (addr, peer_arc) in peers.iter() {
            let peer = peer_arc.lock().await;
            info.push(PeerInfo {
                address: addr.clone(),
                peer_id: peer.peer_id.clone(),
                height: peer.height,
                direction: peer.direction,
                last_activity_secs: peer.last_activity.elapsed().as_secs(),
            });
        }
        
        info
    }
    
    /// Register a new peer connection
    pub async fn register_peer(
        &self,
        address: String,
        peer_id: String,
        height: u64,
        direction: ConnectionDirection,
        writer: tokio::io::WriteHalf<TcpStream>,
    ) -> Arc<Mutex<PeerConnection>> {
        let peer = Arc::new(Mutex::new(PeerConnection {
            address: address.clone(),
            height,
            peer_id: peer_id.clone(),
            direction,
            last_activity: Instant::now(),
            writer: Arc::new(Mutex::new(writer)),
        }));
        
        let mut peers = self.peers.lock().await;
        peers.insert(address.clone(), peer.clone());
        
        info!(
            address = %address,
            peer_id = %peer_id,
            height = height,
            direction = ?direction,
            "Registered new peer connection"
        );
        
        // Phase 3: Guardian welcomes new star 🛡️✨
        crate::guardian::guardian().welcome_star(
            &peer_id,
            Some(&address),
            Some("Unknown") // TODO: Add region detection
        ).await;
        
        // Persist discovered peer to database (only for outbound connections)
        if direction == ConnectionDirection::Outbound {
            self.persist_peer_address(&address).await;
        }
        
        peer
    }
    
    /// Remove peer connection
    pub async fn remove_peer(&self, address: &str) {
        let mut peers = self.peers.lock().await;
        if let Some(peer_arc) = peers.remove(address) {
            // Phase 3: Guardian announces farewell 🛡️
            let peer = peer_arc.lock().await;
            crate::guardian::guardian().farewell_star(
                &peer.peer_id,
                Some(address)
            ).await;
            drop(peer);
            
            info!(address = %address, "Removed peer connection");
            // Remove from persisted peers when connection is lost
            self.remove_persisted_peer_address(address).await;
        }
    }
    
    /// Get all persisted peer addresses from database
    pub fn load_persisted_peers() -> Vec<String> {
        let g = crate::CHAIN.lock();
        let mut peers = Vec::new();
        for kv in g.db.scan_prefix(crate::PEER_PREFIX.as_bytes()) {
            if let Ok((k, _v)) = kv {
                if let Ok(key) = String::from_utf8(k.to_vec()) {
                    let url = key[crate::PEER_PREFIX.len()..].to_string();
                    if !url.is_empty() {
                        peers.push(url);
                    }
                }
            }
        }
        info!("Loaded {} persisted peers from database", peers.len());
        peers
    }

    /// Persist peer address to database for reconnection on startup
    async fn persist_peer_address(&self, address: &str) {
        let g = crate::CHAIN.lock();
        let key = format!("{}{}", crate::PEER_PREFIX, address);
        let _ = g.db.insert(key.as_bytes(), crate::IVec::from(&b"1"[..]));
        let _ = g.db.flush();
        debug!(address = %address, "Persisted peer address to database");
    }
    
    /// Remove persisted peer address from database
    async fn remove_persisted_peer_address(&self, address: &str) {
        let g = crate::CHAIN.lock();
        let key = format!("{}{}", crate::PEER_PREFIX, address);
        let _ = g.db.remove(key.as_bytes());
        let _ = g.db.flush();
        debug!(address = %address, "Removed persisted peer address from database");
    }
    
    /// Maintain minimum outbound connections by connecting to persisted or seed peers
    pub async fn maintain_outbound_connections(self: Arc<Self>) {
        // Load seed peers config
        let seed_config = match crate::p2p::p2p_config::load_seed_peers_config("config/seed_peers.toml") {
            Ok(config) => config,
            Err(e) => {
                warn!("Failed to load seed peers config for connection maintenance: {}", e);
                return;
            }
        };
        
        let min_connections = seed_config.min_outbound_connections;
        let max_connections = seed_config.max_outbound_connections;
        
        loop {
            tokio::time::sleep(Duration::from_secs(seed_config.reconnection_interval_seconds)).await;
            
            let current_peers = self.get_peer_addresses().await;
            let outbound_count = current_peers.len(); // For now, assume all are outbound
            
            debug!(
                current_outbound = outbound_count,
                min_required = min_connections,
                max_allowed = max_connections,
                "Checking outbound connection requirements"
            );
            
            if outbound_count >= min_connections {
                continue; // Enough connections
            }
            
            // Need more connections - build candidate list in priority order:
            // 1) Persisted peers from DB
            // 2) Bootstrap peers from website (if configured)
            // 3) Static seed peers from config
            
            let persisted_peers = Self::load_persisted_peers();
            let mut candidate_peers: Vec<String> = persisted_peers.iter()
                .filter(|peer| !current_peers.contains(peer))
                .cloned()
                .collect();
            
            // Try bootstrap URL if we need more peers
            if candidate_peers.len() < (min_connections - outbound_count) {
                if let Some(ref bootstrap_url) = seed_config.bootstrap_url {
                    info!(url = %bootstrap_url, "Fetching bootstrap peers from website");
                    let bootstrap_peers = crate::p2p::bootstrap::fetch_bootstrap_peers(bootstrap_url).await;
                    for peer in bootstrap_peers {
                        if !current_peers.contains(&peer) && !candidate_peers.contains(&peer) {
                            candidate_peers.push(peer);
                        }
                    }
                }
            }
            
            // If still not enough, add static seed peers
            if candidate_peers.len() < (min_connections - outbound_count) {
                info!("Adding static seed peers from configuration");
                for seed in &seed_config.seed_peers {
                    if !current_peers.contains(seed) && !candidate_peers.contains(seed) {
                        candidate_peers.push(seed.clone());
                    }
                }
            }
            
            let peers_to_try: Vec<String> = candidate_peers.into_iter()
                .take(max_connections.saturating_sub(outbound_count))
                .collect();
            
            if peers_to_try.is_empty() {
                debug!("No available peers to connect to");
                continue;
            }
            
            info!(
                attempting_connections = peers_to_try.len(),
                "Attempting to establish outbound connections"
            );
            
            for peer_addr in peers_to_try {
                let manager = self.clone();
                tokio::spawn(async move {
                    match manager.connect_to_peer(peer_addr.clone()).await {
                        Ok(()) => {
                            info!(peer = %peer_addr, "Successfully established outbound connection");
                        }
                        Err(e) => {
                            debug!(peer = %peer_addr, error = %e, "Failed to connect to peer");
                        }
                    }
                });
            }
        }
    }
    
    /// Update peer height
    pub async fn update_peer_height(&self, address: &str, height: u64) {
        let peers = self.peers.lock().await;
        if let Some(peer_arc) = peers.get(address) {
            let mut peer = peer_arc.lock().await;
            peer.height = height;
            peer.last_activity = Instant::now();
        }
    }
    
    /// Broadcast message to all peers
    pub async fn broadcast_message(&self, msg: P2PMessage) -> (usize, usize) {
        let peers = self.peers.lock().await;
        let peer_list: Vec<_> = peers.values().cloned().collect();
        drop(peers);
        
        let mut success = 0;
        let mut failure = 0;
        
        for peer_arc in peer_list {
            let peer = peer_arc.lock().await;
            let address = peer.address.clone();
            drop(peer);
            
            match peer_arc.lock().await.send_message(msg.clone()).await {
                Ok(()) => {
                    success += 1;
                    debug!(address = %address, "Sent message to peer");
                }
                Err(e) => {
                    failure += 1;
                    error!(address = %address, error = %e, "Failed to send message to peer");
                    // Remove dead peer
                    self.remove_peer(&address).await;
                }
            }
        }
        
        (success, failure)
    }
    
    /// Send message to specific peer
    pub async fn send_to_peer(&self, address: &str, msg: P2PMessage) -> Result<(), String> {
        let peers = self.peers.lock().await;
        let peer_arc = peers.get(address)
            .ok_or_else(|| format!("Peer {} not connected", address))?
            .clone();
        drop(peers);
        
        let result = peer_arc.lock().await.send_message(msg).await;
        
        if result.is_err() {
            // Remove dead peer on failure
            self.remove_peer(address).await;
        }
        
        result
    }
    
    /// Start TCP listener for incoming peer connections
    pub async fn start_listener(
        self: Arc<Self>,
        bind_addr: SocketAddr,
    ) -> Result<(), String> {
        let listener = TcpListener::bind(bind_addr).await
            .map_err(|e| format!("Failed to bind to {}: {}", bind_addr, e))?;
        
        info!("P2P listener started on {}", bind_addr);
        
        loop {
            match listener.accept().await {
                Ok((stream, peer_addr)) => {
                    let manager = self.clone();
                    tokio::spawn(async move {
                        if let Err(e) = manager.handle_inbound_connection(stream, peer_addr).await {
                            error!(peer = %peer_addr, error = %e, "Failed to handle inbound connection");
                        }
                    });
                }
                Err(e) => {
                    error!(error = %e, "Failed to accept connection");
                }
            }
        }
    }
    
    /// Send handshake message with proper length-prefix framing
    async fn send_handshake(
        &self,
        writer: &mut tokio::io::WriteHalf<TcpStream>,
    ) -> Result<(), String> {
        // Create handshake
        let handshake = HandshakeMessage::new()?;
        
        info!(
            protocol_version = handshake.protocol_version,
            chain_height = handshake.chain_height,
            node_version = handshake.node_version,
            "Sending handshake"
        );
        
        // Serialize to binary using bincode
        let data = handshake.serialize()?;
        let len = data.len() as u32;
        
        info!(
            serialized_length = len,
            "Handshake serialized"
        );
        
        if len > MAX_HANDSHAKE_SIZE {
            return Err(format!("Handshake too large: {} bytes", len));
        }
        
        // Send length prefix (4 bytes, big-endian)
        let len_bytes = len.to_be_bytes();
        writer.write_all(&len_bytes).await
            .map_err(|e| format!("Failed to write handshake length: {}", e))?;
        
        // Send handshake data
        writer.write_all(&data).await
            .map_err(|e| format!("Failed to write handshake data: {}", e))?;
        
        writer.flush().await
            .map_err(|e| format!("Failed to flush handshake: {}", e))?;
        
        debug!("Handshake sent successfully");
        
        Ok(())
    }
    
    /// Receive handshake message with proper length-prefix framing
    async fn receive_handshake(
        &self,
        reader: &mut tokio::io::ReadHalf<TcpStream>,
    ) -> Result<HandshakeMessage, String> {
        // Read 4-byte length prefix (big-endian)
        let mut len_bytes = [0u8; 4];
        reader.read_exact(&mut len_bytes).await
            .map_err(|e| format!("Failed to read handshake length: {}", e))?;
        
        let len = u32::from_be_bytes(len_bytes);
        
        info!(
            received_length = len,
            "Received handshake length prefix"
        );
        
        // Validate length
        if len == 0 {
            return Err("Handshake length is 0".to_string());
        }
        
        if len > MAX_HANDSHAKE_SIZE {
            return Err(format!(
                "Invalid handshake length: {} bytes (max {} bytes)",
                len, MAX_HANDSHAKE_SIZE
            ));
        }
        
        // Read handshake data
        let mut data = vec![0u8; len as usize];
        reader.read_exact(&mut data).await
            .map_err(|e| format!("Failed to read handshake data: {}", e))?;
        
        debug!(
            data_length = data.len(),
            first_bytes = format!("{:02x} {:02x} {:02x} {:02x}", 
                data.get(0).unwrap_or(&0),
                data.get(1).unwrap_or(&0),
                data.get(2).unwrap_or(&0),
                data.get(3).unwrap_or(&0)),
            "Received handshake data"
        );
        
        // Deserialize from bincode
        let handshake = HandshakeMessage::deserialize(&data)?;
        
        info!(
            protocol_version = handshake.protocol_version,
            chain_height = handshake.chain_height,
            node_version = handshake.node_version,
            "Handshake deserialized"
        );
        
        // Validate handshake
        handshake.validate()?;
        
        Ok(handshake)
    }
    
    /// Handle inbound peer connection
    async fn handle_inbound_connection(
        &self,
        stream: TcpStream,
        peer_addr: SocketAddr,
    ) -> Result<(), String> {
        info!(peer = %peer_addr, "Accepted inbound connection");
        
        // Split stream
        let (mut reader, mut writer) = tokio::io::split(stream);
        
        // Receive handshake with binary framing
        info!(peer = %peer_addr, "Waiting to receive handshake...");
        let handshake = self.receive_handshake(&mut reader).await
            .map_err(|e| {
                error!(peer = %peer_addr, error = %e, "Failed to receive handshake");
                e
            })?;
        
        info!(
            peer = %peer_addr,
            chain_height = handshake.chain_height,
            "Handshake received and validated"
        );
        
        // Send our handshake response
        info!(peer = %peer_addr, "Sending our handshake response");
        self.send_handshake(&mut writer).await
            .map_err(|e| {
                error!(peer = %peer_addr, error = %e, "Failed to send handshake");
                e
            })?;
        
        // Register peer (use node_nonce as peer_id)
        let address = peer_addr.to_string();
        let peer_id = format!("peer-{:016x}", handshake.node_nonce);
        let peer = self.register_peer(
            address.clone(),
            peer_id,
            handshake.chain_height,
            ConnectionDirection::Inbound,
            writer,
        ).await;
        
        info!(peer = %peer_addr, "Peer registered, starting message loop");
        
        // Start message loop for regular messages (blocks, txs, etc.)
        self.peer_message_loop(address, reader).await;
        
        Ok(())
    }
    
    /// Connect to outbound peer
    pub async fn connect_to_peer(
        self: Arc<Self>,
        address: String,
    ) -> Result<(), String> {
        info!(peer = %address, "Connecting to peer");
        
        let stream = TcpStream::connect(&address).await
            .map_err(|e| format!("Connection failed: {}", e))?;
        
        let (mut reader, mut writer) = tokio::io::split(stream);
        
        // Send our handshake first
        info!(peer = %address, "Sending handshake");
        self.send_handshake(&mut writer).await
            .map_err(|e| {
                error!(peer = %address, error = %e, "Failed to send handshake");
                e
            })?;
        
        // Receive peer handshake response
        info!(peer = %address, "Waiting for peer handshake response...");
        let peer_handshake = self.receive_handshake(&mut reader).await
            .map_err(|e| {
                error!(peer = %address, error = %e, "Failed to receive peer handshake");
                e
            })?;
        
        info!(
            peer = %address,
            chain_height = peer_handshake.chain_height,
            "Peer handshake received and validated"
        );
        
        // Register peer (use node_nonce as peer_id)
        let peer_id = format!("peer-{:016x}", peer_handshake.node_nonce);
        let peer_height = peer_handshake.chain_height;
        let peer = self.register_peer(
            address.clone(),
            peer_id,
            peer_height,
            ConnectionDirection::Outbound,
            writer,
        ).await;
        
        info!(peer = %address, height = peer_height, "Successfully connected to peer");
        
        // Request peer list for discovery
        if let Err(e) = self.send_to_peer(&address, P2PMessage::GetPeers).await {
            warn!(peer = %address, error = %e, "Failed to request peer list");
        }
        
        // Start message loop
        let manager = self.clone();
        tokio::spawn(async move {
            manager.peer_message_loop(address, reader).await;
        });
        
        Ok(())
    }
    
    /// Message receive loop for a peer connection
    async fn peer_message_loop(
        &self,
        address: String,
        mut reader: tokio::io::ReadHalf<TcpStream>,
    ) {
        loop {
            match self.receive_message(&mut reader).await {
                Ok(msg) => {
                    if let Err(e) = self.handle_peer_message(&address, msg).await {
                        error!(peer = %address, error = %e, "Error handling message");
                    }
                }
                Err(e) => {
                    info!(peer = %address, error = %e, "Peer disconnected");
                    self.remove_peer(&address).await;
                    break;
                }
            }
        }
    }
    
    /// Receive a length-prefixed message from stream
    async fn receive_message(
        &self,
        reader: &mut tokio::io::ReadHalf<TcpStream>,
    ) -> Result<P2PMessage, String> {
        // Read 4-byte length prefix
        let mut len_bytes = [0u8; 4];
        reader.read_exact(&mut len_bytes).await
            .map_err(|e| format!("Failed to read length: {}", e))?;
        
        let len = u32::from_be_bytes(len_bytes) as usize;
        
        debug!("Received message length prefix: {} bytes", len);
        
        // Sanity check
        if len > 100 * 1024 * 1024 {  // 100MB max
            return Err(format!("Message too large: {} bytes", len));
        }
        
        if len == 0 {
            return Err("Message length is 0".to_string());
        }
        
        // Read message data
        let mut data = vec![0u8; len];
        reader.read_exact(&mut data).await
            .map_err(|e| format!("Failed to read message: {}", e))?;
        
        // Log first 200 bytes for debugging
        let preview = if data.len() > 200 {
            format!("{}... ({} total bytes)", 
                String::from_utf8_lossy(&data[..200]), data.len())
        } else {
            String::from_utf8_lossy(&data).to_string()
        };
        debug!("Received message data: {}", preview);
        
        // Deserialize
        serde_json::from_slice(&data)
            .map_err(|e| {
                error!("Deserialization failed: {}", e);
                error!("Raw bytes (first 500): {:?}", &data[..data.len().min(500)]);
                format!("Failed to deserialize message: {}", e)
            })
    }
    
    /// Handle received message from peer
    async fn handle_peer_message(
        &self,
        address: &str,
        msg: P2PMessage,
    ) -> Result<(), String> {
        match msg {
            P2PMessage::Ping { timestamp } => {
                // Respond with pong
                self.send_to_peer(address, P2PMessage::Pong { timestamp }).await?;
            }
            P2PMessage::Pong { .. } => {
                // Update last activity
                self.update_peer_height(address, 0).await;  // Just update timestamp
            }
            P2PMessage::CompactBlock { compact } => {
                let height = compact.header.height;
                let hash = compact.header.hash.clone();
                
                info!(
                    peer = %address,
                    hash = %hash,
                    height = height,
                    "Received compact block from peer"
                );
                
                // Handle compact block (existing logic)
                super::routes::handle_compact_block_direct(compact).await?;
                
                // Update peer height
                self.update_peer_height(address, height).await;
            }
            P2PMessage::FullBlock { block } => {
                info!(
                    peer = %address,
                    hash = %block.header.pow_hash,
                    height = block.header.number,
                    "Received full block from peer"
                );
                
                // Integrate block (would need to call existing block integration logic)
                // TODO: Call block integration
                
                self.update_peer_height(address, block.header.number).await;
            }
            P2PMessage::GetPeers => {
                // Send our peer list
                let peers = self.get_peer_addresses().await;
                let _ = self.send_to_peer(address, P2PMessage::PeerList { peers }).await;
            }
            P2PMessage::PeerList { peers } => {
                info!(
                    peer = %address,
                    peer_count = peers.len(),
                    "Received peer list from peer"
                );
                // Persist discovered peers
                for peer_addr in peers {
                    if peer_addr != address && !peer_addr.is_empty() {
                        self.persist_peer_address(&peer_addr).await;
                    }
                }
            }
            P2PMessage::Transaction { tx } => {
                debug!(
                    peer = %address,
                    "Received transaction from peer"
                );
                
                // Add to mempool (existing logic)
                // TODO: Call mempool logic to add tx to mempool
            }
            P2PMessage::GetBlocks { start_height, end_height } => {
                info!(
                    peer = %address,
                    start = start_height,
                    end = end_height,
                    "Peer requested blocks"
                );
                
                // Send requested blocks
                // TODO: Implement block sending
            }
            P2PMessage::Disconnect { reason } => {
                info!(peer = %address, reason = %reason, "Peer disconnecting");
                self.remove_peer(address).await;
            }
            P2PMessage::Handshake { .. } => {
                warn!(peer = %address, "Received unexpected handshake after connection established");
            }
        }
        
        Ok(())
    }
    
    /// Start keepalive ping loop
    pub async fn start_keepalive(self: Arc<Self>) {
        tokio::spawn(async move {
            loop {
                tokio::time::sleep(Duration::from_secs(30)).await;
                
                let timestamp = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_secs();
                
                let (success, failure) = self.broadcast_message(P2PMessage::Ping { timestamp }).await;
                
                if success > 0 || failure > 0 {
                    debug!(success = success, failure = failure, "Keepalive ping sent");
                }
            }
        });
    }
}

/// Peer info for API responses
#[derive(Debug, Clone, Serialize)]
pub struct PeerInfo {
    pub address: String,
    pub peer_id: String,
    pub height: u64,
    pub direction: ConnectionDirection,
    pub last_activity_secs: u64,
}

impl Serialize for ConnectionDirection {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        serializer.serialize_str(match self {
            ConnectionDirection::Inbound => "inbound",
            ConnectionDirection::Outbound => "outbound",
        })
    }
}
