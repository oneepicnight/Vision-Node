//! Chain reorganization handling
//!
//! Manages chain switches when a competing fork becomes longer than the
//! current main chain. This includes:
//! - Detecting when reorg is needed (fork has more accumulated work)
//! - Rolling back current chain to common ancestor
//! - Replaying blocks from the new fork
//! - Returning transactions from orphaned blocks to mempool
//! - Updating chain state and metrics

use crate::{Block, BlockHeader, Tx};
use std::collections::{HashMap, VecDeque};

/// Result of reorg attempt
#[derive(Debug)]
pub enum ReorgResult {
    /// Successfully switched to new chain
    Success {
        old_tip: String,
        new_tip: String,
        blocks_rolled_back: usize,
        blocks_applied: usize,
    },
    /// No reorg needed (current chain is still best)
    NotNeeded,
    /// Reorg failed (kept current chain)
    Failed(String),
}

/// Represents a competing fork that may require reorganization
#[derive(Debug, Clone)]
pub struct Fork {
    /// Blocks in this fork (from common ancestor forward)
    pub blocks: Vec<Block>,
    /// Hash of common ancestor with main chain
    pub common_ancestor: String,
    /// Total accumulated difficulty
    pub total_difficulty: u64,
}

/// Check if a reorg is needed and execute it if so
pub fn handle_reorg(new_block: &Block) -> ReorgResult {
    let mut g = crate::CHAIN.lock();
    
    // Get current chain tip
    let current_tip = match g.blocks.last() {
        Some(b) => b,
        None => {
            // Empty chain, just add the block
            drop(g);
            return ReorgResult::NotNeeded;
        }
    };
    
    // Check if new block extends current tip (no reorg needed)
    if new_block.header.parent_hash == current_tip.header.pow_hash {
        tracing::trace!(
            target = "p2p::reorg",
            parent = %new_block.header.parent_hash,
            "Block extends current tip, no reorg needed"
        );
        return ReorgResult::NotNeeded;
    }
    
    // Find common ancestor and build fork
    let fork = match find_fork(&g.blocks, new_block) {
        Some(f) => f,
        None => {
            tracing::warn!(
                target = "p2p::reorg",
                block_hash = %new_block.header.pow_hash,
                parent = %new_block.header.parent_hash,
                "Cannot find common ancestor for reorg"
            );
            return ReorgResult::Failed("No common ancestor found".to_string());
        }
    };
    
    // Calculate current chain difficulty from common ancestor
    let ancestor_height = find_block_height(&g.blocks, &fork.common_ancestor);
    let current_difficulty: u64 = g.blocks.iter()
        .skip(ancestor_height + 1)
        .map(|b| b.header.difficulty)
        .sum();
    
    tracing::debug!(
        target = "p2p::reorg",
        fork_difficulty = fork.total_difficulty,
        current_difficulty = current_difficulty,
        fork_blocks = fork.blocks.len(),
        "Evaluating potential reorg"
    );
    
    // Only reorg if fork has MORE accumulated work
    if fork.total_difficulty <= current_difficulty {
        tracing::debug!(
            target = "p2p::reorg",
            "Fork does not have more work, keeping current chain"
        );
        return ReorgResult::NotNeeded;
    }
    
    tracing::warn!(
        target = "p2p::reorg",
        old_tip = %current_tip.header.pow_hash,
        new_tip = %fork.blocks.last().unwrap().header.pow_hash,
        rollback_count = g.blocks.len() - ancestor_height - 1,
        apply_count = fork.blocks.len(),
        "Executing chain reorganization"
    );
    
    // Execute the reorg
    let old_tip = current_tip.header.pow_hash.clone();
    let rollback_count = g.blocks.len() - ancestor_height - 1;
    
    // 1. Save transactions from blocks being rolled back
    let orphaned_txs = collect_orphaned_transactions(&g.blocks, ancestor_height + 1);
    
    // 2. Roll back to common ancestor
    g.blocks.truncate(ancestor_height + 1);
    
    // 3. Apply fork blocks
    for block in &fork.blocks {
        // TODO: Should validate each block before applying
        g.blocks.push(block.clone());
    }
    
    let new_tip = g.blocks.last().unwrap().header.pow_hash.clone();
    
    // 4. Return orphaned transactions to mempool (excluding those in new chain)
    let new_chain_txs = collect_transactions_in_blocks(&fork.blocks);
    let reinserted_count = reinsert_orphaned_transactions(&mut g, orphaned_txs, &new_chain_txs);
    
    // 5. Update metrics
    crate::PROM_CHAIN_REORGS.inc();
    crate::PROM_CHAIN_REORG_BLOCKS_ROLLED_BACK.inc_by(rollback_count as u64);
    crate::PROM_CHAIN_REORG_TXS_REINSERTED.inc_by(reinserted_count as u64);
    crate::PROM_CHAIN_REORG_DEPTH.set(rollback_count as i64);
    
    // Release lock
    drop(g);
    
    ReorgResult::Success {
        old_tip,
        new_tip,
        blocks_rolled_back: rollback_count,
        blocks_applied: fork.blocks.len(),
    }
}

/// Find the fork starting from a new block back to common ancestor
fn find_fork(main_chain: &[Block], new_block: &Block) -> Option<Fork> {
    let mut fork_blocks = vec![new_block.clone()];
    let mut current_hash = new_block.header.parent_hash.clone();
    let mut total_difficulty = new_block.header.difficulty;
    
    // Walk backwards through orphan pool and main chain
    let max_depth = 100; // Prevent infinite loops
    for _ in 0..max_depth {
        // Check if current_hash is in main chain
        if let Some(_) = main_chain.iter().find(|b| b.header.pow_hash == current_hash) {
            // Found common ancestor
            return Some(Fork {
                blocks: fork_blocks.into_iter().rev().collect(),
                common_ancestor: current_hash,
                total_difficulty,
            });
        }
        
        // Try to find parent in orphan pool
        let orphan_pool_arc = crate::p2p::routes::orphan_pool();
        let pool = orphan_pool_arc.lock();
        
        if let Some(parent_block) = pool.get_orphan(&current_hash) {
            total_difficulty += parent_block.header.difficulty;
            fork_blocks.push(parent_block.clone());
            current_hash = parent_block.header.parent_hash.clone();
            drop(pool); // Release lock before next iteration
        } else {
            // Can't find parent in orphan pool or main chain
            tracing::debug!(
                target = "p2p::reorg",
                missing_hash = %current_hash,
                "Cannot find parent block in orphan pool or main chain"
            );
            break;
        }
    }
    
    None
}

/// Find the height of a block in the chain
fn find_block_height(blocks: &[Block], hash: &str) -> usize {
    blocks.iter()
        .position(|b| b.header.pow_hash == hash)
        .unwrap_or(0)
}

/// Collect all transactions from blocks being rolled back
fn collect_orphaned_transactions(blocks: &[Block], from_height: usize) -> Vec<Tx> {
    let mut txs = Vec::new();
    
    for block in blocks.iter().skip(from_height) {
        // Skip coinbase transaction (index 0)
        for tx in block.txs.iter().skip(1) {
            txs.push(tx.clone());
        }
    }
    
    tracing::debug!(
        target = "p2p::reorg",
        count = txs.len(),
        "Collected orphaned transactions"
    );
    
    txs
}

/// Collect all transaction hashes in a set of blocks
fn collect_transactions_in_blocks(blocks: &[Block]) -> std::collections::HashSet<[u8; 32]> {
    let mut txs = std::collections::HashSet::new();
    
    for block in blocks {
        for tx in &block.txs {
            let tx_hash = crate::tx_hash(tx);
            txs.insert(tx_hash);
        }
    }
    
    txs
}

/// Reinsert orphaned transactions back into mempool
fn reinsert_orphaned_transactions(
    chain_state: &mut parking_lot::MutexGuard<crate::Chain>,
    orphaned: Vec<Tx>,
    new_chain_txs: &std::collections::HashSet<[u8; 32]>,
) -> usize {
    let mut reinserted = 0;
    let total = orphaned.len();
    
    for tx in orphaned {
        let tx_hash = crate::tx_hash(&tx);
        
        // Only reinsert if not already in new chain
        if !new_chain_txs.contains(&tx_hash) {
            // TODO: Should re-validate transaction against new chain state
            // For now, put back in bulk mempool (lower priority)
            chain_state.mempool_bulk.push_back(tx);
            reinserted += 1;
        }
    }
    
    tracing::info!(
        target = "p2p::reorg",
        total = total,
        reinserted = reinserted,
        skipped = total - reinserted,
        "Reinserted orphaned transactions to mempool"
    );
    
    reinserted
}

/// Check if a block would trigger a reorg (without executing it)
pub fn would_trigger_reorg(block: &Block) -> bool {
    let g = crate::CHAIN.lock();
    
    let current_tip = match g.blocks.last() {
        Some(b) => b,
        None => return false,
    };
    
    // Not a reorg if it extends current tip
    if block.header.parent_hash == current_tip.header.pow_hash {
        return false;
    }
    
    // Check if fork would have more work
    if let Some(fork) = find_fork(&g.blocks, block) {
        let ancestor_height = find_block_height(&g.blocks, &fork.common_ancestor);
        let current_difficulty: u64 = g.blocks.iter()
            .skip(ancestor_height + 1)
            .map(|b| b.header.difficulty)
            .sum();
        
        fork.total_difficulty > current_difficulty
    } else {
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_no_reorg_on_tip_extension() {
        // Test that extending the tip doesn't trigger reorg
    }
    
    #[test]
    fn test_reorg_detection() {
        // Test fork detection and comparison
    }
    
    #[test]
    fn test_orphaned_tx_collection() {
        // Test that transactions are properly collected from orphaned blocks
    }
}
