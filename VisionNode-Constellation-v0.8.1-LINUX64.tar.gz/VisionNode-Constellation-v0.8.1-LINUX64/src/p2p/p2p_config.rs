//! P2P Configuration Module
//!
//! Handles loading and validation of P2P network configuration,
//! including seed peers for initial network bootstrap.

use serde::{Deserialize, Serialize};
use std::fs;

/// Configuration for seed peers used for initial network bootstrap
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SeedPeersConfig {
    /// List of seed peer addresses (host:port format)
    pub seed_peers: Vec<String>,
    /// Minimum number of outbound connections to maintain
    pub min_outbound_connections: usize,
    /// Maximum number of outbound connections allowed
    pub max_outbound_connections: usize,
    /// Interval in seconds between connection maintenance checks
    pub reconnection_interval_seconds: u64,
    /// Connection timeout in seconds
    pub connection_timeout_seconds: u64,
    /// Optional bootstrap URL to fetch dynamic seed peers (e.g., "https://visionworld.tech/api/bootstrap")
    #[serde(default)]
    pub bootstrap_url: Option<String>,
}

impl Default for SeedPeersConfig {
    fn default() -> Self {
        Self {
            seed_peers: vec![
                "127.0.0.1:7071".to_string(), // Local fallback
            ],
            min_outbound_connections: 3,
            max_outbound_connections: 8,
            reconnection_interval_seconds: 30,
            connection_timeout_seconds: 10,
            bootstrap_url: Some("https://visionworld.tech/api/bootstrap".to_string()),
        }
    }
}

impl SeedPeersConfig {
    /// Validate the configuration
    pub fn validate(&self) -> Result<(), String> {
        if self.seed_peers.is_empty() {
            return Err("seed_peers cannot be empty".to_string());
        }

        for peer in &self.seed_peers {
            if !peer.contains(':') {
                return Err(format!("Invalid peer address format (missing port): {}", peer));
            }
        }

        if self.min_outbound_connections > self.max_outbound_connections {
            return Err("min_outbound_connections cannot be greater than max_outbound_connections".to_string());
        }

        if self.min_outbound_connections == 0 {
            return Err("min_outbound_connections must be at least 1".to_string());
        }

        Ok(())
    }
}

/// Load seed peers configuration from TOML file
pub fn load_seed_peers_config(path: &str) -> Result<SeedPeersConfig, String> {
    let content = fs::read_to_string(path)
        .map_err(|e| format!("Failed to read config file {}: {}", path, e))?;

    let mut config: SeedPeersConfig = toml::from_str(&content)
        .map_err(|e| format!("Failed to parse TOML config: {}", e))?;

    config.validate()?;

    tracing::info!(
        seed_peers = config.seed_peers.len(),
        min_connections = config.min_outbound_connections,
        max_connections = config.max_outbound_connections,
        "Loaded seed peers configuration"
    );

    Ok(config)
}