pub mod visionx;

pub type U256 = [u8; 32];

#[inline]
pub fn u256_leq(a: &U256, b: &U256) -> bool {
    // big-endian compare: a <= b
    for i in 0..32 {
        if a[i] < b[i] { return true; }
        if a[i] > b[i] { return false; }
    }
    true
}

#[inline]
pub fn u256_from_difficulty(difficulty: u64) -> U256 {
    // Simple approximation: target = 0xFFFF...FF / difficulty
    // For low difficulties, this gives reasonable targets
    if difficulty == 0 {
        return [0xFF; 32]; // max target (easiest)
    }
    
    let mut target = [0u8; 32];
    // Start with max value and divide by difficulty
    // Simplified: just scale the first bytes
    let scale = 0xFFFFFFFFFFFFFFFFu64 / difficulty;
    target[0..8].copy_from_slice(&scale.to_be_bytes());
    target
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_u256_leq() {
        let a = [0x00; 32];
        let b = [0xFF; 32];
        assert!(u256_leq(&a, &b));
        assert!(!u256_leq(&b, &a));
        assert!(u256_leq(&a, &a));
    }
}
