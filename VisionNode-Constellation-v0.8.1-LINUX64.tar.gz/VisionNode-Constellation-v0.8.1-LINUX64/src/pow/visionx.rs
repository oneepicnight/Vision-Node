use std::time::{SystemTime, UNIX_EPOCH};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

use crate::pow::{U256, u256_leq};

/// VisionX parameters — tune to taste
#[derive(Clone, Copy, Debug)]
pub struct VisionXParams {
    pub dataset_mb: usize,  // e.g., 64
    pub mix_iters: u32,     // e.g., 65536
    pub write_every: u32,   // e.g., 1024
    pub epoch_blocks: u32,  // e.g., 32
}

impl Default for VisionXParams {
    fn default() -> Self {
        Self {
            dataset_mb: 64,
            mix_iters: 65_536,
            write_every: 1024,
            epoch_blocks: 32,
        }
    }
}

/// SplitMix64 PRNG (std-only, our own)
#[derive(Clone)]
struct SplitMix64 { state: u64 }
impl SplitMix64 {
    fn new(seed: u64) -> Self { Self { state: seed } }
    #[inline] fn next(&mut self) -> u64 {
        let mut z = { self.state = self.state.wrapping_add(0x9E3779B97F4A7C15); self.state };
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58476D1CE4E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D049BB133111EB);
        z ^ (z >> 31)
    }
}

/// Tiny mixer to expand 128 bits → 256 bits (ours)
#[inline]
fn expand_256(mut a: u64, mut b: u64) -> U256 {
    // 4 rounds Feistel-ish
    for _ in 0..4 {
        a = a.rotate_left(13) ^ b.wrapping_mul(0x9E3779B185EBCA87);
        b = b.rotate_left(17) ^ a.wrapping_mul(0xC2B2AE3D27D4EB4F);
    }
    let mut sm = SplitMix64::new(a ^ b ^ 0xD6E8FEB86659FD93);
    let c = sm.next();
    let d = sm.next();
    let mut out = [0u8; 32];
    out[..8].copy_from_slice(&a.to_be_bytes());
    out[8..16].copy_from_slice(&b.to_be_bytes());
    out[16..24].copy_from_slice(&c.to_be_bytes());
    out[24..32].copy_from_slice(&d.to_be_bytes());
    out
}

/// Fold a 32-byte hash into a u64 seed (ours)
#[inline]
pub fn fold_seed(prev_hash32: &[u8; 32], epoch_id: u64) -> u64 {
    let mut s: u64 = epoch_id ^ 0xA24BAED4963EE407;
    for chunk in prev_hash32.chunks(8) {
        let mut v = [0u8; 8];
        v[..chunk.len()].copy_from_slice(chunk);
        s ^= u64::from_be_bytes(v).rotate_left(7);
        s = s.wrapping_mul(0x9E3779B97F4A7C15).rotate_left(9);
    }
    s
}

/// Deterministic dataset derived from prev hash + epoch
pub struct VisionXDataset {
    pub mem: Box<[u64]>,
    pub mask: usize, // length-1 if pow2 sized
}

impl VisionXDataset {
    pub fn build(params: &VisionXParams, prev_hash32: &[u8; 32], epoch: u64) -> Self {
        // Size in u64s; round to next power-of-two for fast masking
        let bytes = params.dataset_mb * 1024 * 1024;
        let mut words = bytes / std::mem::size_of::<u64>();
        let mut n = 1usize;
        while n < words { n <<= 1; }
        words = n;

        let seed = fold_seed(prev_hash32, epoch);
        let mut sm = SplitMix64::new(seed);
        let mut mem = vec![0u64; words].into_boxed_slice();
        for i in 0..words {
            mem[i] = sm.next();
        }
        Self { mem, mask: words - 1 }
    }
}

/// Block header template given to miner
#[derive(Clone)]
pub struct PowJob {
    pub header: Vec<u8>,   // header bytes without nonce (or include nonce offset)
    pub nonce_offset: usize, // byte offset where 8-byte nonce is written
    pub target: U256,      // big-endian target
    pub prev_hash32: [u8; 32],
    pub height: u64,
}

/// Result (solution)
#[derive(Debug, Clone)]
pub struct PowSolution {
    pub nonce: u64,
    pub digest: U256,
}

/// Core VisionX hash (std-only, memory-hard)
pub fn visionx_hash(params: &VisionXParams, ds: &[u64], mask: usize, header: &[u8], nonce: u64) -> U256 {
    // Build initial 128-bit state (our own fold of header+nonce)
    let mut a: u64 = 0x243F_6A88_85A3_08D3 ^ nonce.rotate_left(17);
    let mut b: u64 = 0x1319_8A2E_0370_7344 ^ nonce.rotate_right(11);
    // fold header into (a,b)
    for chunk in header.chunks(16) {
        let mut p = [0u8; 16];
        p[..chunk.len()].copy_from_slice(chunk);
        let x = u64::from_be_bytes(p[0..8].try_into().unwrap());
        let y = u64::from_be_bytes(p[8..16].try_into().unwrap());
        a ^= x.wrapping_mul(0x9E37_79B1_85EB_CA87);
        b ^= y.wrapping_mul(0xC2B2_AE3D_27D4_EB4F);
        a = a.rotate_left(13) ^ b.rotate_right(7);
        b = b.rotate_left(29) ^ a.rotate_right(19);
    }

    let its = params.mix_iters;
    let mut acc = a ^ b ^ 0xDEAD_BEEF_F00D_FACEu64;

    for i in 0..its {
        // generate index from state & loop counter (fast path)
        let j = (a ^ b ^ acc ^ (i as u64).wrapping_mul(0x9E37_79B9)).rotate_left(17) as usize & mask;
        // load and mix (read-only, no write-back for verifiability)
        let v = ds[j];
        a = a.rotate_left(13) ^ v.wrapping_mul(0x94D0_49BB_1331_11EB);
        b = b.rotate_left(17) ^ (v ^ acc).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        acc = acc.rotate_left(7) ^ (a ^ b).wrapping_mul(0xD6E8_FEB8_6659_FD93);
    }

    expand_256(a ^ acc, b ^ acc.rotate_left(3))
}

/// Verify VisionX
pub fn verify(params: &VisionXParams, prev_hash32: &[u8; 32], epoch: u64, header_with_nonce: &[u8], nonce_offset: usize, target: &U256) -> bool {
    let ds = VisionXDataset::build(params, prev_hash32, epoch);
    let mut header = header_with_nonce.to_vec();
    let mut nonce_bytes = [0u8; 8];
    nonce_bytes.copy_from_slice(&header[nonce_offset..nonce_offset+8]);
    let nonce = u64::from_be_bytes(nonce_bytes);
    let digest = visionx_hash(params, &ds.mem, ds.mask, &header, nonce);
    u256_leq(&digest, target)
}

/// Miner engine (single-thread batch)
pub struct VisionXMiner {
    pub params: VisionXParams,
    pub dataset: Arc<Vec<u64>>, // immutable snapshot per epoch (we'll clone into a mutable scratch for writes)
    pub mask: usize,
    pub last_hps: AtomicU64,
}

impl VisionXMiner {
    pub fn new(params: VisionXParams, prev_hash32: &[u8; 32], epoch: u64) -> Self {
        let ds = VisionXDataset::build(&params, prev_hash32, epoch);
        Self {
            params,
            dataset: Arc::new(ds.mem.to_vec()),
            mask: ds.mask,
            last_hps: AtomicU64::new(0),
        }
    }

    /// Create a lightweight miner engine without building a large dataset
    /// Useful for tests where we do not want expensive dataset builds.
    pub fn new_disabled(params: VisionXParams) -> Self {
        // Minimal dataset (1 u64) to keep API stable
        Self {
            params,
            dataset: Arc::new(vec![0u64; 1]),
            mask: 0,
            last_hps: AtomicU64::new(0),
        }
    }

    /// Hash a batch of nonces; returns (solutions, hashes_done)
    pub fn mine_batch(&self, job: &PowJob, start_nonce: u64, batch: u32) -> (Vec<PowSolution>, u32) {
        // clone header locally; we'll overwrite nonce region each loop
        let mut header = job.header.clone();
        let mut sols = Vec::new();
        let t0 = now_ns();

        for n in 0..batch {
            let nonce = start_nonce.wrapping_add(n as u64);
            header[job.nonce_offset..job.nonce_offset+8].copy_from_slice(&nonce.to_be_bytes());
            let digest = visionx_hash(&self.params, self.dataset.as_slice(), self.mask, &header, nonce);
            if u256_leq(&digest, &job.target) {
                sols.push(PowSolution { nonce, digest });
            }
        }

        let dt_ns = now_ns().saturating_sub(t0).max(1);
        let hps = ((batch as u128) * 1_000_000_000u128 / (dt_ns as u128)) as u64;
        self.last_hps.store(hps, Ordering::Relaxed);
        (sols, batch)
    }

    pub fn last_hps(&self) -> u64 { self.last_hps.load(Ordering::Relaxed) }
}

#[inline]
fn now_ns() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos() as u64
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_splitmix64() {
        let mut rng = SplitMix64::new(12345);
        let a = rng.next();
        let b = rng.next();
        assert_ne!(a, b);
    }

    #[test]
    fn test_dataset_build() {
        let params = VisionXParams::default();
        let prev = [0u8; 32];
        let ds = VisionXDataset::build(&params, &prev, 0);
        assert!(ds.mem.len() > 0);
        assert_eq!(ds.mem.len() & ds.mask, 0); // power of 2
    }

    #[test]
    fn test_visionx_hash() {
        let params = VisionXParams {
            dataset_mb: 1, // small for test
            mix_iters: 100,
            write_every: 10,
            epoch_blocks: 32,
        };
        let prev = [0u8; 32];
        let mut ds = VisionXDataset::build(&params, &prev, 0);
        let header = vec![1, 2, 3, 4];
        let hash1 = visionx_hash(&params, &mut ds.mem, ds.mask, &header, 0);
        let hash2 = visionx_hash(&params, &mut ds.mem, ds.mask, &header, 1);
        assert_ne!(hash1, hash2); // different nonces give different hashes
    }
}
