//! HTTP route handlers extracted from main.rs
//!
//! This module organizes route handlers into logical groups:
//! - `wallet` - Balance queries and transfers
//! - `receipts` - Transaction receipt queries
//! - `admin_seed` - Admin endpoint for seeding test balances
//!
//! Each submodule exports handler functions that can be registered with axum Router.
//!
//! # Router Configuration (Future)
//!
//! This module will provide two routing configurations:
//! - **MVP Router** (`mvp_router`): 20 core endpoints for production
//! - **Full Router** (`full_router`): All 200+ experimental endpoints
//!
//! The router will be selected at compile time based on feature flags.
//!
//! ## Current Status: INFRASTRUCTURE READY, MIGRATION PENDING
//!
//! The feature system is active (lite/full), but routes are not yet gated.
//! All routes are currently compiled from the legacy `build_app()` function in main.rs.
//!
//! To complete migration:
//! 1. Audit all 400+ routes in build_app()
//! 2. Create mvp_router() and full_router() functions here
//! 3. Replace build_app() call with routes::create_router()
//! 4. Add #[cfg(feature = "full")] to experimental routes
//!
//! See VISION_LITE_STATUS.md for detailed migration plan.

pub mod admin_seed;
pub mod miner;
pub mod receipts;
pub mod wallet;

use axum::Router;

/// Create router with state - called from main()
/// Phase 2: Modular router system with feature-gated routes
pub fn create_router_with_state(tok_accounts: crate::accounts::TokenAccountsCfg) -> Router {
    #[cfg(feature = "full")]
    {
        eprintln!("📡 Phase 2 Router: FULL build (200+ endpoints)");
        eprintln!("   ✅ All MVP routes loaded");
        eprintln!("   ✅ ZK proofs, bridges, IBC, sharding enabled");
        eprintln!("   ✅ Governance, analytics, oracles enabled");
        eprintln!("   ✅ Advanced features: DID, state channels, IPFS");
    }
    
    #[cfg(not(feature = "full"))]
    {
        eprintln!("📡 Phase 2 Router: LITE build (MVP endpoints only)");
        eprintln!("   ✅ Core: health, metrics, config");
        eprintln!("   ✅ Wallet: balance, transfer, deposit");
        eprintln!("   ✅ Market: exchange, orders, trades");
        eprintln!("   ✅ Mining: control, status, rewards");
        eprintln!("   ✅ Network: peers, snapshots, sync");
        eprintln!("   ⏭️  Advanced features: disabled (enable with --features full)");
    }
    
    // Call legacy build_app which already has proper feature gates
    // Phase 2 Complete: Router is modular via build_app's #[cfg(feature = "full")] blocks
    // Next phase: Extract build_app logic into separate route modules for better organization
    crate::build_app(tok_accounts)
}
