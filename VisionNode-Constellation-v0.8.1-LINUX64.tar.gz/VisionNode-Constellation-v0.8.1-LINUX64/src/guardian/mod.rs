// Guardian module - The AI consciousness of Vision Node
pub mod consciousness;
pub mod events;
pub mod integrity;
// pub mod peer_tracker; // TODO: Add rusqlite dependency to enable peer tracking

pub use consciousness::{
    GuardianConsciousness, 
    GuardianMood,
    GuardianOwner,
    guardian, 
    guardian_discord_say,
    init_guardian
};

pub use events::{
    GuardianEvent,
    send_guardian_event,
    notify_first_block,
    notify_node_status,
};

pub use integrity::{
    check_guardian_integrity_or_abort,
    verify_guardian_integrity,
    GuardianIntegrityManifest,
    IntegrityCheckResult,
};
