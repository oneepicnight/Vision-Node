// Vision Chain Constants
// Import serde for derive macros used in enums
use serde::{Serialize, Deserialize};
// Hard-coded values for deterministic chain behavior

/// Block time in seconds
pub const BLOCK_TIME_SECS: u64 = 2;

/// Blocks per day (86400 seconds / 2 seconds per block)
pub const BLOCKS_PER_DAY: u64 = 43_200;

/// Blocks per era (1 year worth of blocks)
pub const BLOCKS_PER_ERA: u64 = 15_768_000;

/// Maximum mining block height (4 years total)
pub const MAX_MINING_BLOCK: u64 = 63_072_000;

/// Testnet sunset height
pub const TESTNET_SUNSET_HEIGHT: u64 = 1_000_000;

/// Cash first mint height
pub const CASH_FIRST_MINT_HEIGHT: u64 = 1_000_000;

/// Foundation addresses
pub const VAULT_ADDRESS: &str = "0xb977c16e539670ddfecc0ac902fcb916ec4b944e";
pub const FOUNDER_ADDRESS: &str = "0xdf7a79291bb96e9dd1c77da089933767999eabf0";
pub const OPS_ADDRESS: &str = "0x8bb8edcd4cdbcb132cc5e88ff90ba48cebf11cbd";

/// Gross per-block LAND emission in each era (human units).
///
/// Updated tokenomics: Era 1 starts at 34 LAND per block and halves each era
/// resulting in 34 / 17 / 8.5 / 4.25 emissions for eras 1-4 respectively. The
/// protocol fee remains 2 LAND per block consumed from the emission (so miner
/// gets emission - protocol_fee).
pub const ERA1_REWARD_LAND: f64 = 34.0;
pub const ERA2_REWARD_LAND: f64 = 17.0;
pub const ERA3_REWARD_LAND: f64 = 8.5;
pub const ERA4_REWARD_LAND: f64 = 4.25;

/// Protocol fee in LAND tokens
pub const PROTOCOL_FEE_LAND: f64 = 2.0;

/// Staking reward (same as ERA4 emission) paid from Vault after mining ends
pub const STAKING_REWARD_LAND: f64 = ERA4_REWARD_LAND;

/// Number of decimal places for the LAND asset
pub const LAND_DECIMALS: u32 = 8;

/// Chain phase enum - mining vs staking
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ChainPhase {
    Mining,
    Staking,
}

impl ChainPhase {
    pub fn from_height(height: u64) -> Self {
        if height >= MAX_MINING_BLOCK {
            ChainPhase::Staking
        } else {
            ChainPhase::Mining
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self {
            ChainPhase::Mining => "mining",
            ChainPhase::Staking => "staking",
        }
    }
}

/// Helper function to convert human LAND amounts (f64) into integer base units
pub fn land_amount(units: f64) -> u128 {
    let factor: u128 = 10u128.pow(LAND_DECIMALS);
    // Multiply using float then round to nearest integer to handle fractional LAND
    (units * factor as f64).round() as u128
}

/// Returns the per-block LAND emission for a given height, handling eras
/// 
/// Emission schedule:
/// - Era 1 (blocks 0-15,767,999): 34 LAND/block
/// - Era 2 (blocks 15,768,000-31,535,999): 17 LAND/block  
/// - Era 3 (blocks 31,536,000-47,303,999): 8.5 LAND/block
/// - Era 4 (blocks 47,304,000-63,071,999): 4.25 LAND/block
/// - After block 63,072,000: 0 LAND/block (mining ended)
pub fn land_block_reward(height: u64) -> u128 {
    // After max mining block, emission is 0 forever
    if height >= MAX_MINING_BLOCK {
        return 0;
    }
    
    // Calculate which era we're in (0-indexed)
    let era = height / BLOCKS_PER_ERA;
    
    match era {
        0 => land_amount(ERA1_REWARD_LAND),  // 34 LAND
        1 => land_amount(ERA2_REWARD_LAND),  // 17 LAND
        2 => land_amount(ERA3_REWARD_LAND),  // 8.5 LAND
        3 => land_amount(ERA4_REWARD_LAND),  // 4.25 LAND
        _ => 0,  // Should never reach here given MAX_MINING_BLOCK check above
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    // Test Era 1: blocks 0 to 15,767,999 = 34 LAND
    #[test]
    fn test_era1_emission_34_land() {
        assert_eq!(land_block_reward(0), land_amount(34.0));
        assert_eq!(land_block_reward(1), land_amount(34.0));
        assert_eq!(land_block_reward(BLOCKS_PER_ERA - 1), land_amount(34.0));
    }
    
    // Test Era 2: blocks 15,768,000 to 31,535,999 = 17 LAND
    #[test]
    fn test_era2_emission_17_land() {
        assert_eq!(land_block_reward(BLOCKS_PER_ERA), land_amount(17.0));
        assert_eq!(land_block_reward(BLOCKS_PER_ERA + 1), land_amount(17.0));
        assert_eq!(land_block_reward(2 * BLOCKS_PER_ERA - 1), land_amount(17.0));
    }
    
    // Test Era 3: blocks 31,536,000 to 47,303,999 = 8.5 LAND
    #[test]
    fn test_era3_emission_8_5_land() {
        assert_eq!(land_block_reward(2 * BLOCKS_PER_ERA), land_amount(8.5));
        assert_eq!(land_block_reward(2 * BLOCKS_PER_ERA + 1), land_amount(8.5));
        assert_eq!(land_block_reward(3 * BLOCKS_PER_ERA - 1), land_amount(8.5));
    }
    
    // Test Era 4: blocks 47,304,000 to 63,071,999 = 4.25 LAND
    #[test]
    fn test_era4_emission_4_25_land() {
        assert_eq!(land_block_reward(3 * BLOCKS_PER_ERA), land_amount(4.25));
        assert_eq!(land_block_reward(3 * BLOCKS_PER_ERA + 1), land_amount(4.25));
        assert_eq!(land_block_reward(MAX_MINING_BLOCK - 1), land_amount(4.25));
    }
    
    // Test emission ends at MAX_MINING_BLOCK = 63,072,000
    #[test]
    fn test_emission_ends_at_max_mining_block() {
        assert_eq!(land_block_reward(MAX_MINING_BLOCK), 0);
        assert_eq!(land_block_reward(MAX_MINING_BLOCK + 1), 0);
        assert_eq!(land_block_reward(MAX_MINING_BLOCK + 1000000), 0);
    }
    
    // Test protocol fee constant
    #[test]
    fn test_protocol_fee_is_2_land() {
        assert_eq!(land_amount(PROTOCOL_FEE_LAND), land_amount(2.0));
    }
    
    // Test total supply calculation over all 4 eras
    #[test]
    fn test_total_emission_calculation() {
        // Era 1: 15,768,000 blocks * 34 LAND = 536,112,000 LAND
        let era1_total = BLOCKS_PER_ERA * 34;
        assert_eq!(era1_total, 536_112_000);
        
        // Era 2: 15,768,000 blocks * 17 LAND = 268,056,000 LAND
        let era2_total = BLOCKS_PER_ERA * 17;
        assert_eq!(era2_total, 268_056_000);
        
        // Era 3: 15,768,000 blocks * 8.5 LAND = 134,028,000 LAND
        // Using integer math: 15,768,000 * 85 / 10
        let era3_total = (BLOCKS_PER_ERA * 85) / 10;
        assert_eq!(era3_total, 134_028_000);
        
        // Era 4: 15,768,000 blocks * 4.25 LAND = 67,014,000 LAND
        // Using integer math: 15,768,000 * 425 / 100
        let era4_total = (BLOCKS_PER_ERA * 425) / 100;
        assert_eq!(era4_total, 67_014_000);
        
        // Total emission: 1,005,210,000 LAND
        let total_emission = era1_total + era2_total + era3_total + era4_total;
        assert_eq!(total_emission, 1_005_210_000);
    }
    
    // Test land_amount helper precision
    #[test]
    fn test_land_amount_precision() {
        // 34 LAND = 3,400,000,000 base units (8 decimals)
        assert_eq!(land_amount(34.0), 3_400_000_000);
        // 17 LAND = 1,700,000,000 base units
        assert_eq!(land_amount(17.0), 1_700_000_000);
        // 8.5 LAND = 850,000,000 base units
        assert_eq!(land_amount(8.5), 850_000_000);
        // 4.25 LAND = 425,000,000 base units
        assert_eq!(land_amount(4.25), 425_000_000);
        // 2.0 LAND (protocol fee) = 200,000,000 base units
        assert_eq!(land_amount(2.0), 200_000_000);
    }
    
    // Test chain phase detection
    #[test]
    fn test_chain_phase_mining_vs_staking() {
        assert_eq!(ChainPhase::from_height(0), ChainPhase::Mining);
        assert_eq!(ChainPhase::from_height(MAX_MINING_BLOCK - 1), ChainPhase::Mining);
        assert_eq!(ChainPhase::from_height(MAX_MINING_BLOCK), ChainPhase::Staking);
        assert_eq!(ChainPhase::from_height(MAX_MINING_BLOCK + 1), ChainPhase::Staking);
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Network {
    Mainnet,
    Testnet,
    Local,
}

impl Network {
    pub fn from_env() -> Self {
        match std::env::var("VISION_NETWORK").ok().as_deref() {
            Some("mainnet") | Some("main") => Network::Mainnet,
            Some("local") => Network::Local,
            _ => Network::Testnet,
        }
    }
    pub fn as_str(&self) -> &'static str {
        match self {
            Network::Mainnet => "vision-mainnet1",
            Network::Testnet => "vision-testnet2",
            Network::Local => "vision-local-1",
        }
    }
}

pub const PROTOCOL_VERSION_LITE: u32 = 1;
pub const PROTOCOL_VERSION_FULL: u32 = 2;

// Genesis hashes (placeholder strings - operators can set proper values)
// Defaults for TESTNET/MAINNET genesis pow_hash strings. Operators
// should set either the constants here or prefer to set the runtime env
// vars: VISION_GENESIS_HASH_TESTNET and VISION_GENESIS_HASH_MAINNET.
// The default for local/test builds remains the zero-hash (64 hex zeros)
// so that dev and test suites continue to work unless overridden.
// Genesis hash - dynamically mined on first startup (difficulty 1)
// This hash was generated from the genesis block with the current parameters
pub const GENESIS_HASH_TESTNET: &str = "04444bf09e542279da648f770e1b8de80efd81e390e805bdf8304a6c28b13758";
pub const GENESIS_HASH_MAINNET: &str = "<MAINNET_GENESIS_HASH>";

/// Return the allowed testnet genesis pow_hash (runtime override allowed)
pub fn allowed_genesis_testnet() -> String {
    std::env::var("VISION_GENESIS_HASH_TESTNET").unwrap_or_else(|_| GENESIS_HASH_TESTNET.to_string())
}

/// Return the allowed mainnet genesis pow_hash (runtime override allowed)
pub fn allowed_genesis_mainnet() -> String {
    std::env::var("VISION_GENESIS_HASH_MAINNET").unwrap_or_else(|_| GENESIS_HASH_MAINNET.to_string())
}

// Prefix/key constants moved from main.rs to be available across modules
pub const LAND_DEED_PREFIX: &str = "land:deed:"; // land:deed:<id> -> owner address
pub const META_LAND_GENESIS_DONE: &str = "meta:land_genesis_done"; // bool flag when genesis minted
/// DB keys for supply metrics
pub const SUPPLY_TOTAL_KEY: &str = "supply:total"; // u128 BE
pub const SUPPLY_VAULT_KEY: &str = "supply:vault"; // u128 BE
pub const SUPPLY_FOUNDER_KEY: &str = "supply:founder"; // u128 BE
pub const SUPPLY_OPS_KEY: &str = "supply:ops"; // u128 BE

// =================== Testnet 48h v0.8.0 Reward Shares ===================

/// Reward distribution for block rewards
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct RewardShares {
    pub miner: u128,
    pub staker: u128,
}

/// Compute reward shares for a given network, height, and base reward
/// 
/// For Testnet48hV080:
/// - Phase 1 (Mining): 100% miner, 0% staker
/// - Phase 2 (Hybrid): 50% miner, 50% staker  
/// - Phase 3 (Staking-only): 0% miner, 100% staker
/// 
/// For all other networks: 100% miner (existing behavior)
pub fn compute_reward_shares(
    network: crate::network_config::NetworkType,
    height: u64,
    base_reward: u128,
    genesis_height: u64,
) -> RewardShares {
    use crate::network_config::{is_testnet_48h_v080, testnet_48h_bounds};
    
    if is_testnet_48h_v080(network) {
        let (start, mid, end) = testnet_48h_bounds(genesis_height);
        
        if height < mid {
            // Phase 1: Full mining
            RewardShares {
                miner: base_reward,
                staker: 0,
            }
        } else if height < end {
            // Phase 2: Hybrid 50/50
            let half = base_reward / 2;
            RewardShares {
                miner: half,
                staker: base_reward - half, // Handle odd amounts
            }
        } else {
            // Phase 3: Staking only
            RewardShares {
                miner: 0,
                staker: base_reward,
            }
        }
    } else {
        // All other networks: 100% miner (existing behavior)
        RewardShares {
            miner: base_reward,
            staker: 0,
        }
    }
}