use crate::treasury::vault;
use axum::{response::IntoResponse, routing::get, Json, Router};
use std::sync::Arc;

use crate::metrics;

#[derive(Clone)]
pub struct AppState {
    pub dbctx: Arc<metrics::DbCtx>,
    pub metrics: Arc<metrics::Metrics>,
}

pub fn router() -> Router {
    Router::new()
        .route("/vault", get(get_stats))
        .route("/vault/history", get(get_history))
        .route("/vault/epoch", get(get_epoch))
}

async fn get_stats() -> Json<serde_json::Value> {
    let s = vault::stats();
    Json(serde_json::json!({
        "ok": true,
        "split": { "vault": s.split.vault, "ops": s.split.ops, "founders": s.split.founders },
        "totals": {
            "LAND": { "vault": s.totals_land.0, "ops": s.totals_land.1, "founders": s.totals_land.2 },
            "CASH": { "vault": s.totals_cash.0, "ops": s.totals_cash.1, "founders": s.totals_cash.2 }
        },
        "last_10": s.last_10
    }))
}

async fn get_history() -> Json<serde_json::Value> {
    let s = vault::stats();
    Json(serde_json::json!({
        "ok": true,
        "events": s.last_10, // keep it small; expand later with paging
    }))
}

async fn get_epoch() -> impl IntoResponse {
    // Note: This is a simplified version that doesn't access actual state
    // In production, pass DbCtx and metrics via State
    Json(serde_json::json!({
        "epoch_index": 0,
        "last_payout_height": 0,
        "next_payout_height": 180,
        "last_payout_at_ms": 0,
        "vault_balance": "0",
        "total_weight": "0",
        "due": false,
        "note": "Full implementation requires State integration"
    }))
}
