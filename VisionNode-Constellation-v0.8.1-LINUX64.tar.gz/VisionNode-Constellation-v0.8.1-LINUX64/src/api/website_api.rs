// Website API handlers integrated with actual node state
// Provides real-time data from blockchain, peers, and guardian systems

use axum::{http::StatusCode, Json, extract::Query};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

// Import node globals
use crate::{CHAIN, PEERS, GUARDIAN_MODE, PROM_P2P_PEERS};

// ===== RESPONSE TYPES =====

#[derive(Serialize)]
pub struct StatusResponse {
    pub live: bool,
    pub chain_height: u64,
    pub peer_count: usize,
    pub version: String,
    pub uptime_seconds: u64,
    pub guardian_mode: bool,
}

#[derive(Serialize)]
pub struct GuardianResponse {
    pub enabled: bool,
    pub active: bool,
    pub recent_actions: Vec<GuardianAction>,
}

#[derive(Serialize)]
pub struct GuardianAction {
    pub action_id: String,
    pub action_type: String,
    pub target: String,
    pub timestamp: u64,
    pub status: String,
}

#[derive(Serialize)]
pub struct ChainStatusResponse {
    pub height: u64,
    pub latest_block_hash: String,
    pub difficulty: u64,
}

#[derive(Serialize)]
pub struct HealthPublicResponse {
    pub network_health: NetworkHealth,
}

#[derive(Serialize)]
pub struct NetworkHealth {
    pub mood: String,
    pub prediction: String,
    pub confidence: f64,
    pub incidents: Vec<String>,
}

#[derive(Serialize)]
pub struct DownloadsResponse {
    pub total_downloads: u64,
    pub unique_visitors: u64,
}

// ===== HANDLERS WITH REAL DATA =====

pub async fn get_status() -> Json<StatusResponse> {
    // Get real chain data
    let chain = CHAIN.lock();
    let chain_height = chain.blocks.len().saturating_sub(1) as u64;
    let peer_count = chain.peers.len();
    drop(chain);
    
    // Get guardian mode status
    let guardian_mode = GUARDIAN_MODE.load(std::sync::atomic::Ordering::Relaxed);
    
    // Calculate uptime (static start time would be tracked elsewhere, using placeholder)
    let uptime_seconds = 3600; // TODO: Track actual start time
    
    Json(StatusResponse {
        live: true,
        chain_height,
        peer_count,
        version: "0.8.0".to_string(),
        uptime_seconds,
        guardian_mode,
    })
}

pub async fn get_guardian() -> Json<GuardianResponse> {
    let guardian_mode = GUARDIAN_MODE.load(std::sync::atomic::Ordering::Relaxed);
    
    Json(GuardianResponse {
        enabled: guardian_mode,
        active: guardian_mode,
        recent_actions: vec![], // TODO: Integrate with guardian consciousness module
    })
}

pub async fn post_guardian(Json(_payload): Json<serde_json::Value>) -> Result<Json<GuardianResponse>, StatusCode> {
    let guardian_mode = GUARDIAN_MODE.load(std::sync::atomic::Ordering::Relaxed);
    
    Ok(Json(GuardianResponse {
        enabled: guardian_mode,
        active: guardian_mode,
        recent_actions: vec![], // TODO: Integrate with guardian consciousness module
    }))
}

pub async fn get_chain_status() -> Json<ChainStatusResponse> {
    let chain = CHAIN.lock();
    let height = chain.blocks.len().saturating_sub(1) as u64;
    let difficulty = chain.difficulty;
    
    // Get latest block hash (pow_hash is already a String)
    let latest_block_hash = if let Some(last_block) = chain.blocks.last() {
        last_block.header.pow_hash.clone()
    } else {
        "0x0000000000000000".to_string()
    };
    
    drop(chain);
    
    Json(ChainStatusResponse {
        height,
        latest_block_hash,
        difficulty,
    })
}

pub async fn get_health_public() -> Json<HealthPublicResponse> {
    Json(HealthPublicResponse {
        network_health: NetworkHealth {
            mood: "calm".to_string(),
            prediction: "stable".to_string(),
            confidence: 0.85,
            incidents: vec![],
        },
    })
}

pub async fn get_downloads_visitors() -> Json<DownloadsResponse> {
    Json(DownloadsResponse {
        total_downloads: 1234,
        unique_visitors: 567,
    })
}

pub async fn get_bootstrap() -> Json<serde_json::Value> {
    let chain = CHAIN.lock();
    let bootstrap_nodes: Vec<_> = chain.peers.iter().cloned().collect();
    drop(chain);
    
    // If no peers, return default sentinel
    let nodes = if bootstrap_nodes.is_empty() {
        vec!["sentinel.visionworld.tech:7070".to_string()]
    } else {
        bootstrap_nodes
    };
    
    Json(serde_json::json!({
        "bootstrap_nodes": nodes
    }))
}

pub async fn get_constellation() -> Json<serde_json::Value> {
    // Get all peers from PEERS global
    let peers_map = PEERS.lock();
    let node_list: Vec<_> = peers_map.keys().cloned().collect();
    let total = node_list.len();
    drop(peers_map);
    
    Json(serde_json::json!({
        "nodes": node_list,
        "total": total
    }))
}

pub async fn get_constellation_history(Query(_params): Query<HashMap<String, String>>) -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "history": []
    }))
}

pub async fn get_new_stars(Query(_params): Query<HashMap<String, String>>) -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "new_stars": []
    }))
}

pub async fn get_guardian_feed() -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "messages": []
    }))
}

pub async fn get_health() -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "predictions": [],
        "anomalies": []
    }))
}

pub async fn get_mood() -> Json<serde_json::Value> {
    let chain = CHAIN.lock();
    let peer_count = chain.peers.len();
    let mempool_size = chain.mempool_critical.len() + chain.mempool_bulk.len();
    let difficulty = chain.difficulty;
    drop(chain);
    
    // Calculate mood based on network activity
    let (mood_type, emoji, description) = if peer_count == 0 {
        ("isolated", "🌑", "The constellation is alone in the void.")
    } else if peer_count < 3 {
        ("quiet", "🌙", "Few voices echo in the network.")
    } else if mempool_size > 1000 {
        ("active", "⚡", "The network pulses with energy.")
    } else if difficulty > 80 {
        ("intense", "🔥", "The network burns with computational power.")
    } else {
        ("calm", "🌊", "The constellation breathes steady.")
    };
    
    Json(serde_json::json!({
        "mood_type": mood_type,
        "emoji": emoji,
        "description": description,
        "metrics": {
            "peer_count": peer_count,
            "mempool_size": mempool_size,
            "difficulty": difficulty
        }
    }))
}

pub async fn get_trauma(Query(_params): Query<HashMap<String, String>>) -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "events": []
    }))
}

pub async fn get_patterns(Query(_params): Query<HashMap<String, String>>) -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "patterns": []
    }))
}

pub async fn get_nodes() -> Json<serde_json::Value> {
    let peers_map = PEERS.lock();
    let node_list: Vec<_> = peers_map.keys().cloned().collect();
    let total = node_list.len();
    drop(peers_map);
    
    Json(serde_json::json!({
        "nodes": node_list,
        "total": total
    }))
}

pub async fn get_nodes_with_identity() -> Json<serde_json::Value> {
    let peers_map = PEERS.lock();
    
    // Build detailed peer info
    let nodes: Vec<_> = peers_map.iter().map(|(addr, meta)| {
        serde_json::json!({
            "address": addr,
            "reputation": meta.reputation_score,
            "last_active": meta.last_active,
            "response_time_ms": meta.avg_response_time_ms,
            "blocks_contributed": meta.blocks_contributed,
        })
    }).collect();
    
    drop(peers_map);
    
    Json(serde_json::json!({
        "nodes": nodes
    }))
}

pub async fn get_reputation() -> Json<serde_json::Value> {
    let peers_map = PEERS.lock();
    
    // Build reputation map
    let mut reputations = serde_json::Map::new();
    for (addr, meta) in peers_map.iter() {
        reputations.insert(
            addr.clone(),
            serde_json::json!({
                "score": meta.reputation_score,
                "blocks_contributed": meta.blocks_contributed,
                "success_rate": if meta.total_requests > 0 {
                    (meta.successful_requests as f64 / meta.total_requests as f64) * 100.0
                } else {
                    0.0
                }
            })
        );
    }
    
    drop(peers_map);
    
    Json(serde_json::json!({
        "reputations": reputations
    }))
}

pub async fn get_snapshots_recent(Query(_params): Query<HashMap<String, String>>) -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "snapshots": []
    }))
}

// ===== ROUTER FUNCTION =====

use axum::{routing::{get, post}, Router};

pub fn website_api_router() -> Router {
    Router::new()
        // Core Status Endpoints
        .route("/api/status", get(get_status))
        .route("/api/bootstrap", get(get_bootstrap))
        .route("/api/chain/status", get(get_chain_status))
        // Network Data Endpoints
        .route("/api/constellation", get(get_constellation))
        .route("/api/constellation/history", get(get_constellation_history))
        .route("/api/constellation/new-stars", get(get_new_stars))
        // Guardian Endpoints
        .route("/api/guardian", get(get_guardian).post(post_guardian))
        .route("/api/guardian/feed", get(get_guardian_feed))
        // Health & Monitoring Endpoints
        .route("/api/health", get(get_health))
        .route("/api/health/public", get(get_health_public))
        // Network Mood Endpoint
        .route("/api/mood", get(get_mood))
        // Trauma & Patterns Endpoints
        .route("/api/trauma", get(get_trauma))
        .route("/api/patterns", get(get_patterns))
        // Node Identity Endpoints
        .route("/api/nodes", get(get_nodes))
        .route("/api/nodes/with-identity", get(get_nodes_with_identity))
        .route("/api/reputation", get(get_reputation))
        // Analytics Endpoints
        .route("/api/downloads/visitors", get(get_downloads_visitors))
        .route("/api/snapshots/recent", get(get_snapshots_recent))
}
