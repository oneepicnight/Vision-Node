﻿pub mod vault_routes;
pub mod snapshot;
pub mod website_api;
pub mod discord_oauth;

// Re-export website API router for easy access
pub use website_api::website_api_router;
pub use discord_oauth::{DiscordOAuthState, discord_login, discord_callback, discord_status, init_discord_links_db};
