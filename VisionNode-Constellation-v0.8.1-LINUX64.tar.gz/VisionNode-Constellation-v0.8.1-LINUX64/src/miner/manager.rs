//! Enhanced miner manager with active mining loop
//!
//! Manages mining workers, distributes work, and submits found blocks.

use crate::consensus_pow::{BlockBuilder, MineableBlock, BlockSubmitter, DifficultyTracker, DifficultyConfig};
use crate::pow::visionx::{VisionXMiner, VisionXParams, PowJob, PowSolution};
use crate::miner_manager::{MinerCfg, MinerSpeed};
use std::sync::{Arc, Mutex, atomic::{AtomicU64, AtomicBool, Ordering}};
use std::thread;
use std::time::{Duration, Instant};
use std::collections::VecDeque;

const BATCH_SIZE: u32 = 1000; // Nonces to try per batch

/// Active miner with worker threads
pub struct ActiveMiner {
    inner: Arc<MinerInner>,
    workers: Mutex<Vec<thread::JoinHandle<()>>>,
}

struct MinerInner {
    // Configuration
    params: VisionXParams,
    target_threads: AtomicU64,
    enabled: AtomicBool,
    
    // Mining state
    current_job: Mutex<Option<MiningJob>>,
    nonce_counter: AtomicU64,
    
    // VisionX engine (rebuilt when epoch changes)
    engine: Mutex<Arc<VisionXMiner>>,
    
    // Block building
    block_builder: BlockBuilder,
    submitter: Arc<BlockSubmitter>,
    difficulty_tracker: Mutex<DifficultyTracker>,
    
    // Statistics
    hash_samples: Mutex<VecDeque<(Instant, u64)>>,
    sample_window: Duration,
}

#[derive(Clone)]
struct MiningJob {
    block: MineableBlock,
    pow_job: PowJob,
    started_at: Instant,
    epoch_seed: [u8; 32], // Seed hash for this epoch's dataset
    epoch: u64,           // Which epoch this block belongs to
}

impl ActiveMiner {
    pub fn new(
        params: VisionXParams,
        difficulty_config: DifficultyConfig,
        initial_difficulty: u64,
        found_block_callback: Option<tokio::sync::mpsc::UnboundedSender<crate::consensus_pow::MineableBlock>>,
    ) -> Self {
        let prev_hash = [0u8; 32]; // Genesis
        let epoch = 0;
        
        let engine = Mutex::new(Arc::new(VisionXMiner::new(params, &prev_hash, epoch)));
        let submitter = Arc::new(BlockSubmitter::new(params, found_block_callback));
        let difficulty_tracker = DifficultyTracker::new(difficulty_config, initial_difficulty);
        
        let inner = Arc::new(MinerInner {
            params,
            target_threads: AtomicU64::new(num_cpus::get() as u64),
            enabled: AtomicBool::new(false),
            current_job: Mutex::new(None),
            nonce_counter: AtomicU64::new(0),
            engine,
            block_builder: BlockBuilder::new(),
            submitter,
            difficulty_tracker: Mutex::new(difficulty_tracker),
            hash_samples: Mutex::new(VecDeque::with_capacity(120)),
            sample_window: Duration::from_secs(120),
        });
        
        Self {
            inner,
            workers: Mutex::new(Vec::new()),
        }
    }

    /// Create an ActiveMiner that uses a minimal dataset so it's cheap to construct
    /// This is intended for test environments where mining is not required.
    pub fn new_disabled(
        params: VisionXParams,
        difficulty_config: DifficultyConfig,
        initial_difficulty: u64,
        found_block_callback: Option<tokio::sync::mpsc::UnboundedSender<crate::consensus_pow::MineableBlock>>,
    ) -> Self {
        let prev_hash = [0u8; 32]; // Genesis
        let engine = Mutex::new(Arc::new(VisionXMiner::new_disabled(params)));
        let submitter = Arc::new(BlockSubmitter::new(params, found_block_callback));
        let difficulty_tracker = DifficultyTracker::new(difficulty_config, initial_difficulty);

        let inner = Arc::new(MinerInner {
            params,
            target_threads: AtomicU64::new(0),
            enabled: AtomicBool::new(false),
            current_job: Mutex::new(None),
            nonce_counter: AtomicU64::new(0),
            engine,
            block_builder: BlockBuilder::new(),
            submitter,
            difficulty_tracker: Mutex::new(difficulty_tracker),
            hash_samples: Mutex::new(VecDeque::with_capacity(120)),
            sample_window: Duration::from_secs(120),
        });

        Self {
            inner,
            workers: Mutex::new(Vec::new()),
        }
    }
    
    /// Start mining with specified number of threads
    pub fn start(&self, threads: usize) {
        self.inner.enabled.store(true, Ordering::Relaxed);
        self.set_threads(threads);
    }
    
    /// Stop all mining threads
    pub fn stop(&self) {
        self.inner.enabled.store(false, Ordering::Relaxed);
        self.inner.target_threads.store(0, Ordering::Relaxed);
        
        // Wait for workers to finish
        let mut workers = self.workers.lock().unwrap();
        while let Some(handle) = workers.pop() {
            let _ = handle.join();
        }
    }
    
    /// Set number of mining threads
    pub fn set_threads(&self, threads: usize) {
        let max_threads = num_cpus::get() * 2;
        let threads = threads.min(max_threads).max(0);
        
        // Set enabled state based on thread count
        if threads > 0 {
            self.inner.enabled.store(true, Ordering::Relaxed);
        } else {
            self.inner.enabled.store(false, Ordering::Relaxed);
        }
        
        self.inner.target_threads.store(threads as u64, Ordering::Relaxed);
        
        // Adjust worker count
        let mut workers = self.workers.lock().unwrap();
        
        // Clean up finished workers first
        workers.retain(|h| !h.is_finished());
        
        // If we need more threads, spawn them starting from 0
        // (old workers will exit when they see worker_id >= target_threads)
        if threads > 0 {
            // Clear out all old workers and start fresh
            workers.clear();
            
            // Spawn workers with IDs 0 to threads-1
            for worker_id in 0..threads {
                let inner = self.inner.clone();
                let handle = thread::spawn(move || {
                    Self::worker_loop(inner, worker_id);
                });
                workers.push(handle);
            }
            eprintln!("⛏️  Started {} mining threads", threads);
        } else {
            // threads == 0, just clear everything
            workers.clear();
            eprintln!("⏸️  Stopped all mining threads");
        }
    }
    
    /// Get current thread count
    pub fn get_threads(&self) -> usize {
        self.inner.target_threads.load(Ordering::Relaxed) as usize
    }
    
    /// Update mining job (call when new block arrives or difficulty changes)
    pub fn update_job(&self, height: u64, prev_hash: [u8; 32], transactions: Vec<crate::consensus_pow::Transaction>, epoch_seed: [u8; 32]) {
        let difficulty = self.inner.difficulty_tracker.lock().unwrap().current_difficulty();
        let target = self.inner.difficulty_tracker.lock().unwrap().current_target();
        
        // Calculate epoch
        let epoch = height / self.inner.params.epoch_blocks as u64;
        
        // Check if we need to rebuild the dataset (epoch changed)
        let current_job = self.inner.current_job.lock().unwrap();
        let needs_rebuild = if let Some(ref job) = *current_job {
            job.epoch != epoch
        } else {
            true // First job
        };
        drop(current_job);
        
        if needs_rebuild {
            eprintln!("🔄 Rebuilding VisionX dataset for epoch {} with seed {:02x}{:02x}...", 
                epoch, epoch_seed[0], epoch_seed[1]);
            
            // Rebuild engine with new epoch seed
            // Note: This is expensive (64MB dataset rebuild) but only happens every ~10 blocks
            let new_engine = Arc::new(VisionXMiner::new(self.inner.params, &epoch_seed, epoch));
            *self.inner.engine.lock().unwrap() = new_engine;
        }
        
        eprintln!("🎯 Mining block #{} with epoch_seed={:02x}{:02x}..., epoch={}", 
            height, epoch_seed[0], epoch_seed[1], epoch);
        
        // Build new block template
        let block = self.inner.block_builder.build_block(height, prev_hash, difficulty, transactions);
        let pow_job = self.inner.block_builder.create_pow_job(&block, target);
        
        // Update job
        let job = MiningJob {
            block,
            pow_job,
            started_at: Instant::now(),
            epoch_seed,
            epoch,
        };
        
        *self.inner.current_job.lock().unwrap() = Some(job);
        self.inner.nonce_counter.store(0, Ordering::Relaxed);
        
        // Enhanced logging with full target for debugging
        eprintln!(
            "🎯 New mining job: height={}, difficulty={}, target={}",
            height,
            difficulty,
            hex::encode(target)
        );
        eprintln!(
            "   Target (first 8 bytes): {:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
            target[0], target[1], target[2], target[3], target[4], target[5], target[6], target[7]
        );
    }
    
    /// Get mining statistics
    pub fn stats(&self) -> MinerSpeed {
        let now = Instant::now();
        let mut samples = self.inner.hash_samples.lock().unwrap();
        
        // Remove old samples
        let cutoff = now - self.inner.sample_window;
        while let Some((ts, _)) = samples.front() {
            if *ts < cutoff {
                samples.pop_front();
            } else {
                break;
            }
        }
        
        // Calculate statistics
        let total_hashes: u64 = samples.iter().map(|(_, count)| count).sum();
        let (current_hashrate, average_hashrate) = if let (Some((oldest_ts, _)), Some((newest_ts, _))) = 
            (samples.front(), samples.back()) {
            let duration_secs = newest_ts.duration_since(*oldest_ts).as_secs_f64().max(1.0);
            let avg = total_hashes as f64 / duration_secs;
            
            // Current hashrate (last 5 seconds)
            let recent_cutoff = now - Duration::from_secs(5);
            let recent_hashes: u64 = samples.iter()
                .filter(|(ts, _)| *ts >= recent_cutoff)
                .map(|(_, count)| count)
                .sum();
            let current = recent_hashes as f64 / 5.0;
            
            (current, avg)
        } else {
            (0.0, 0.0)
        };
        
        // Build history
        let mut history = Vec::with_capacity(120);
        for i in (0..120).rev() {
            let bucket_start = now - Duration::from_secs(i + 1);
            let bucket_end = now - Duration::from_secs(i);
            
            let bucket_hashes: u64 = samples.iter()
                .filter(|(ts, _)| *ts >= bucket_start && *ts < bucket_end)
                .map(|(_, count)| count)
                .sum();
            
            history.push(bucket_hashes as f64);
        }
        
        MinerSpeed {
            current_hashrate,
            average_hashrate,
            history,
            threads: self.get_threads(),
        }
    }
    
    /// Get mining configuration
    pub fn config(&self) -> MinerCfg {
        MinerCfg {
            threads: self.get_threads(),
            enabled: self.inner.enabled.load(Ordering::Relaxed),
        }
    }
    
    /// Check if mining is enabled
    pub fn is_enabled(&self) -> bool {
        self.inner.enabled.load(Ordering::Relaxed)
    }
    
    /// Get mining stats (blocks found, rewards, etc.)
    pub fn mining_stats(&self) -> crate::consensus_pow::MiningStats {
        self.inner.submitter.stats()
    }
    
    /// Get mining stats in API response format
    pub fn get_stats(&self) -> crate::routes::miner::MiningStatsResponse {
        let stats = self.mining_stats();
        
        // Calculate average block time from recent blocks
        let average_block_time = if stats.recent_blocks.len() >= 2 {
            let times: Vec<u64> = stats.recent_blocks
                .iter()
                .zip(stats.recent_blocks.iter().skip(1))
                .map(|(prev, curr)| curr.timestamp.saturating_sub(prev.timestamp))
                .collect();
            
            if !times.is_empty() {
                Some((times.iter().sum::<u64>() as f64) / (times.len() as f64))
            } else {
                None
            }
        } else {
            None
        };
        
        crate::routes::miner::MiningStatsResponse {
            blocks_found: stats.blocks_found,
            blocks_accepted: stats.blocks_accepted,
            blocks_rejected: stats.blocks_rejected,
            last_block_time: stats.last_block_time,
            last_block_height: stats.last_block_height,
            total_rewards: stats.total_rewards,
            average_block_time,
        }
    }
    
    /// Worker thread main loop
    fn worker_loop(inner: Arc<MinerInner>, worker_id: usize) {
        eprintln!("⛏️  Worker #{} started", worker_id);
        
        loop {
            // Check if we should exit
            let target_threads = inner.target_threads.load(Ordering::Relaxed) as usize;
            if !inner.enabled.load(Ordering::Relaxed) || worker_id >= target_threads {
                eprintln!("⏸️  Worker #{} stopping", worker_id);
                break;
            }
            
            // Get current job
            let job = {
                let job_lock = inner.current_job.lock().unwrap();
                job_lock.clone()
            };
            
            if let Some(job) = job {
                // Get nonce range for this batch
                let start_nonce = inner.nonce_counter.fetch_add(BATCH_SIZE as u64, Ordering::Relaxed);
                
                // Get current engine (may change when epoch changes)
                let engine = inner.engine.lock().unwrap().clone();
                
                // Mine batch
                let (solutions, hashes_done) = engine.mine_batch(&job.pow_job, start_nonce, BATCH_SIZE);
                
                // Record hashes for statistics
                {
                    let mut samples = inner.hash_samples.lock().unwrap();
                    samples.push_back((Instant::now(), hashes_done as u64));
                }
                
                // If solution found, submit block
                if let Some(solution) = solutions.first() {
                    let finalized_block = inner.block_builder.finalize_block(
                        job.block.clone(),
                        solution.nonce,
                    );
                    
                    let result = inner.submitter.submit_block(finalized_block.clone(), solution.digest, job.pow_job.target, job.epoch_seed);
                    
                    match result {
                        crate::consensus_pow::SubmitResult::Accepted { height, hash } => {
                            let new_difficulty = inner.difficulty_tracker.lock().unwrap().current_difficulty();
                            eprintln!(
                                "🎉 Worker #{} found block #{}! Hash: {}",
                                worker_id, height, hex::encode(hash)
                            );
                            eprintln!(
                                "   Digest: {}", hex::encode(solution.digest)
                            );
                            eprintln!(
                                "   Target: {}", hex::encode(job.pow_job.target)
                            );
                            eprintln!(
                                "   Difficulty updated: {} -> {}", 
                                job.block.header.difficulty, new_difficulty
                            );
                            
                            // Record block time for difficulty adjustment
                            let timestamp = finalized_block.header.timestamp;
                            inner.difficulty_tracker.lock().unwrap().record_block(timestamp);
                            
                            // Clear current job (will get new one from coordinator)
                            *inner.current_job.lock().unwrap() = None;
                        }
                        crate::consensus_pow::SubmitResult::Rejected { reason } => {
                            eprintln!("❌ Worker #{} block rejected: {}", worker_id, reason);
                            eprintln!(
                                "   Digest: {}", hex::encode(solution.digest)
                            );
                            eprintln!(
                                "   Target: {}", hex::encode(job.pow_job.target)
                            );
                            eprintln!(
                                "   Height: {}, Difficulty: {}", 
                                job.block.header.height, job.block.header.difficulty
                            );
                        }
                        crate::consensus_pow::SubmitResult::Duplicate => {
                            eprintln!("⚠️  Worker #{} found duplicate block", worker_id);
                        }
                    }
                }
            } else {
                // No job available, sleep briefly
                thread::sleep(Duration::from_millis(100));
            }
        }
    }
}

impl Drop for ActiveMiner {
    fn drop(&mut self) {
        self.stop();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_active_miner_creation() {
        let params = VisionXParams::default();
        let difficulty_config = DifficultyConfig::default();
        let miner = ActiveMiner::new(params, difficulty_config, 10000, None);

        assert_eq!(miner.get_threads(), num_cpus::get());
        assert!(!miner.config().enabled);
    }
    
    #[test]
    fn test_thread_adjustment() {
        let params = VisionXParams::default();
        let difficulty_config = DifficultyConfig::default();
        let miner = ActiveMiner::new(params, difficulty_config, 10000, None);

        miner.set_threads(4);
        assert_eq!(miner.get_threads(), 4);

        miner.set_threads(0);
        assert_eq!(miner.get_threads(), 0);
    }
}
