//! Active mining module with worker threads and VisionX PoW
//!
//! Provides the ActiveMiner struct for managing mining operations

pub mod manager;
pub use manager::ActiveMiner;
