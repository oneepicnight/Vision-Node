# Vision Node v3.0.0 - TESTER INSTRUCTIONS

## 🎯 Pure Lottery Testnet - 11 Days (475,200 blocks)

This testnet runs a **pure lottery system** - NO PoW REQUIRED for rewards!

---

## 📥 Setup Instructions

### 1. Download & Extract
Download and extract the `VisionNode-Constellation-v3.0.0-WIN64.zip` package

### 2. Configure Your Node
Rename `.env.tester` to `.env`

**That's it!** The configuration is already set up to connect to the genesis seed.

### 3. Launch Your Node
Double-click: `START-PUBLIC-NODE.bat`

Your node will:
- ✅ Connect to genesis seed: **209.78.232.167:7072**
- ✅ Sync the chain automatically
- ✅ Start participating in the lottery when synced

---

## 🎰 How The Lottery Works

### NO PROOF-OF-WORK REQUIRED!

To participate in block rewards:
1. **Link your wallet** to the node via the miner panel
2. **Stay synced** within 2 blocks of the network tip
3. **Maintain 1+ peer connection**

That's it! Block rewards are randomly distributed to eligible nodes every 2 seconds.

### Optional: "Make Fans Go Brr" Mining Button
- This is **satisfaction only** - doesn't affect rewards!
- Rewards come from the lottery, not mining
- Feel free to click it for fun 😄

---

## 🌐 Web Interface

Once your node is running, open:
- **Miner Panel**: http://localhost:7070/panel.html
- **Wallet**: http://localhost:7070/app
- **P2P Status**: http://localhost:7070/api/p2p/status

---

## 🔗 Wallet Setup

### Create or Restore Wallet
1. Open http://localhost:7070/app
2. Create new wallet OR restore with seed phrase
3. Your wallet uses **Ed25519 signing** (secure & native)

### Link Wallet to Node
1. Open miner panel: http://localhost:7070/panel.html
2. Click "Link Wallet" button
3. Your node can now receive lottery rewards!

---

## 📊 Check Your Status

### Are you synced?
- Panel shows: **"Synced: ✅"** when within 2 blocks
- P2P Status: http://localhost:7070/api/p2p/status

### Are you eligible for lottery?
Requirements:
- ✅ Wallet linked
- ✅ Synced within 2 blocks
- ✅ 1+ peer connection

---

## ⏱️ Testnet Duration

- **Start**: Block 10 (launch)
- **End**: Block 475,210
- **Duration**: ~11 days (2 seconds per block)

After sunset, the node stops producing blocks but you can still view your balance and chain history.

---

## 🛠️ Troubleshooting

### Node won't connect?
- Wait 30-60 seconds for bootstrap
- Check firewall isn't blocking port 7072
- Verify internet connection

### Panel not loading?
- Wait 10 seconds after starting node
- Try: http://127.0.0.1:7070/panel.html
- Check node console for errors

### Not receiving rewards?
- Verify wallet is linked (panel shows your address)
- Confirm you're synced (within 2 blocks)
- Check peer count (need 1+)
- Lottery is random - keep your node synced!

---

## 🌟 Genesis Seed Info

**Genesis Node**: 209.78.232.167:7072

This node:
- Produces blocks every 2 seconds
- Distributes lottery rewards
- Serves the chain to all testers
- No wallet linked (pure block producer)

---

## 📞 Support

If you encounter issues:
1. Check the troubleshooting section above
2. Share your node logs (console output)
3. Report bugs with details

---

## 🎉 Have Fun!

This is a testnet - experiment, test features, and help us find bugs!

Remember: **NO PoW REQUIRED** - just stay synced and you're eligible for lottery rewards!

---

**Happy Testing! 🚀**
