#!/usr/bin/env bash
#
# Vision Node v0.8.6 - Constellation Mode Launcher
# =================================================

echo "🌟 Starting Vision Node v0.8.6 (Constellation mode)..."
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Set environment variables
export VISION_PUBLIC_DIR="$SCRIPT_DIR/public"
export VISION_WALLET_DIR="$SCRIPT_DIR/wallet/dist"
export BEACON_ENDPOINT="https://visionworld.tech"

echo "Guardian Beacon: $BEACON_ENDPOINT"
echo ""

# Check if binary exists
if [ ! -f "./vision-node" ]; then
    if [ -f "./target/release/vision-node" ]; then
        echo "Using freshly built binary from target/release/"
        cd "$SCRIPT_DIR"
        exec ./target/release/vision-node --role constellation
    else
        echo "❌ ERROR: vision-node binary not found!"
        echo ""
        echo "Please build the node first:"
        echo "  cargo build --release"
        echo ""
        echo "Or if you have the binary, place it in this directory."
        exit 1
    fi
fi

# Run the node in constellation mode
exec ./vision-node --role constellation
