// Restore vault-related addresses (replace with your real addrs)
pub const FOUNDATION_ADDR: &str =
    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
pub const VAULT_ADDR: &str = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
pub const OPS_ADDR: &str = "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc";
pub const FOUNDERS_ADDR: &str = "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd";
