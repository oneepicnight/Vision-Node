﻿Vision Node v0.1.2 - Testnet Release
=====================================

WHAT'S NEW IN v0.1.2:
- Fixed dashboard block hashes (no more double-encoding)
- Real-time network hashrate calculation
- Wallet import feature (restore from seed phrase)
- Removed manual mining buttons from panel
- Updated emissions: 32 LAND + 2 LAND tithe per block

QUICK START:
1. Run: START-VISION-NODE.bat
2. Wallet: http://127.0.0.1:7070/app
3. Panel: http://127.0.0.1:7070/panel.html
4. Dashboard: http://127.0.0.1:7070/dashboard.html

Default miner address: Treasury (0xdf7a79291bb96e9dd1c77da089933767999eabf0)
Configure with: POST /api/miner/configure {"address":"0x..."}
